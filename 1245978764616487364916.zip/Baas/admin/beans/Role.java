package admin.beans;

import java.util.List;

/**
 * 角色
 * @author luofei
 *
 */
public class Role {
	/**
	 * 角色id
	 */
	private String id;
	/**
	 * 角色编码
	 */
	private String code;
	/**
	 * 角色名
	 */
	private String name;
	/**
	 * 角色类型
	 */
	private String kind;
	/**
	 * 角色权限
	 */
	//private List<RolePermission> permissions;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	/*
	public List<RolePermission> getPermissions() {
		return permissions;
	}
	public void setPermissions(List<RolePermission> permissions) {
		this.permissions = permissions;
	}*/
}
