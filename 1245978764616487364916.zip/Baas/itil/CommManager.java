package itil;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.IOUtils;

import admin.utils.SystemInit;

import com.alibaba.fastjson.JSONObject;
import com.justep.baas.action.ActionContext;
import com.justep.baas.data.sql.SQLException;

public class CommManager {

	public static final String BASE_URL = "http://10.76.1.31:8890";
	static OkHttpClient mOkHttpClient = null;
	static {
		mOkHttpClient = new OkHttpClient();
	}

	public static JSONObject service(JSONObject params, ActionContext context) throws ServletException, IOException, SQLException, NamingException {
		HttpServletRequest request = (HttpServletRequest) context.get(ActionContext.REQUEST);
		HttpServletResponse response = (HttpServletResponse) context.get(ActionContext.RESPONSE);
		doPost(request, response);
		return null;
	}

	/**
	 * post为上传
	 **/
	protected static void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String contentType = request.getContentType();
		if (StringUtils.isEmpty(contentType)) {
			return;
		}
		JSONObject jsonobj = new JSONObject();
		try {
			if ("application/octet-stream".equals(contentType)) {
				storeOctStreamFile(request, response);
			} else if (!StringUtils.isEmpty(contentType) && contentType.startsWith("multipart/")) {
				jsonobj = storeFile(request, response);
			} else {
				throw new RuntimeException("not supported contentType");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new IOException("storeFile异常");
		}
		request.getSession().setAttribute("file", jsonobj);
	}

	private static void storeOctStreamFile(HttpServletRequest request, HttpServletResponse response) throws IOException, SQLException {
		InputStream in = null;
		FileOutputStream storeStream = null;
		try {

		} finally {
			IOUtils.closeQuietly(in);
			IOUtils.closeQuietly(storeStream);
		}
	}

	public static List<FileItem> parseMultipartRequest(HttpServletRequest request) throws FileUploadException {
		DiskFileItemFactory factory = new DiskFileItemFactory();
		ServletContext servletContext = request.getSession().getServletContext();
		File repository = (File) servletContext.getAttribute("javax.servlet.context.tempdir");
		factory.setRepository(repository);
		ServletFileUpload upload = new ServletFileUpload(factory);
		@SuppressWarnings("unchecked")
		List<FileItem> items = upload.parseRequest(request);
		return items;
	}

	private static JSONObject storeFile(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HashMap<String, String> params = new HashMap<String, String>();
		List<FileItem> items = parseMultipartRequest(request);
		Iterator<FileItem> iter = items.iterator();
		FileItem fileItem = null;
		while (iter.hasNext()) {
			FileItem item = iter.next();
			if (item.isFormField()) {
				String name = item.getFieldName();
				String value = item.getString();
				params.put(name, value);
			} else {
				fileItem = item;
			}
		}
		String filePath = SystemInit.sysConfig.get("itilAttach") + params.get("storeFileName");
		fileItem.write(new File(filePath));
		JSONObject jsonobj = new JSONObject();
		jsonobj.put("fileName", params.get("storeFileName"));
		return jsonobj;
	}

	public static JSONObject upload(JSONObject params, ActionContext context) throws ServletException, IOException, SQLException, NamingException {
		String userId = params.getString("userId");
		String taskId = params.getString("taskId");
		String field = params.getString("field");
		String filePath = params.getString("filePath");
		String fileName = params.getString("fileName");
		System.out.println("=====fileName=========="+fileName);
		String[] filePaths = filePath.split(",");
		String[] fileNames = fileName.split(",");
		String msg="";
		for (int i = 0; i < filePaths.length; i++) {
			File file = new File(SystemInit.sysConfig.get("itilAttach") + filePaths[i]);
			HashMap<String, Object> paramsMap = new HashMap();
			paramsMap.put("taskId", taskId);
			paramsMap.put("field", field);
			paramsMap.put("userId", userId);
			paramsMap.put("attach", file);
		    msg = upLoadFile(BASE_URL+"/itsm/rest/api/v2/itsm/attach/ticket/upload", paramsMap, fileNames[i]);
			if (file.exists()) {
				file.delete();
			}
		}

		return JSONObject.parseObject(msg);
	}

	/**
	 * 上传文件
	 * 
	 * @param actionUrl
	 *            接口地址
	 * @param paramsMap
	 *            参数
	 * @param callBack
	 *            回调
	 * @param <T>
	 */
	static String upLoadFile(String actionUrl, HashMap<String, Object> paramsMap, String fileName) {
		try {
			// 补全请求地址
			String requestUrl = actionUrl;
			MultipartBody.Builder builder = new MultipartBody.Builder();
			// 设置类型
			builder.setType(MultipartBody.FORM);
			
			// 追加参数
			for (String key : paramsMap.keySet()) {
				Object object = paramsMap.get(key);
				if (!(object instanceof File)) {
					builder.addFormDataPart(key, object.toString());
				} else {
					File file = (File) object;
					//System.out.println("=========fileName==========" + fileName);
					//builder.addFormDataPart(key, new String(fileName.getBytes(),"GBK"), RequestBody.create(null, file));
					SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
					//builder.addFormDataPart(key, fileName, RequestBody.create(null, file));
					builder.addFormDataPart(key, sdf.format(new Date())+StringUtils.getSuffix(fileName), RequestBody.create(null, file));
					//builder.addFormDataPart(key,fileName, RequestBody.create(null, file));
					//builder.addFormDataPart("params","plans.xml",RequestBody.create(null, file));
				}
			}
			// 创建RequestBody
			RequestBody body = builder.build();
			//System.out.println("==========contentype==============="+body.contentType().toString());
			// 创建Request
			final Request request = new Request.Builder().url(requestUrl).post(body).build();
			Response response = mOkHttpClient.newCall(request).execute();
			ResponseBody resp = response.body();
			String str = resp.string();
			System.out.println("===================" + str);
			return str;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "{attach:[]}";
	}

	public static void main(String[] args) throws Exception {
		/*
		 * FileInputStream fin = new FileInputStream(new
		 * File("D:/attachment/notice/qhse需求模板.doc")); //
		 * uploadMultiFile(IOUtils.toByteArray(fin), "qhse需求模板.doc", "230909",
		 * // "admin", "attachFile");; HashMap<String, Object> paramsMap = new
		 * HashMap(); paramsMap.put("taskId", "230909"); paramsMap.put("field",
		 * "attachFile"); paramsMap.put("userId", "admin");
		 * paramsMap.put("attach", new
		 * File("D:/attachment/notice/qhse需求模板.doc")); paramsMap.put("attach",
		 * "qhse需求模板.doc"); upLoadFile(
		 * "http://10.76.1.45:8890/itsm/rest/api/v2/itsm/attach/ticket/upload",
		 * paramsMap);
		 */
		System.out.println(JSONObject.parse("{attach:[]}"));
	}

	/**
	 * 加载文档
	 * 
	 * @param params
	 * @param context
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 * @throws SQLException
	 * @throws NamingException
	 * @throws java.sql.SQLException
	 */
	public static JSONObject downLoadFromLocal(JSONObject params, ActionContext context) throws ServletException, IOException, SQLException, NamingException, java.sql.SQLException {
		HttpServletResponse response = (HttpServletResponse) context.get(ActionContext.RESPONSE);
		HttpServletRequest request = (HttpServletRequest) context.get(ActionContext.REQUEST);
		String path = request.getParameter("path");
		String operateType = request.getParameter("operateType");
		String filePath = "";
		response.setHeader("Cache-Control", "pre-check=0, post-check=0, max-age=0");
		FileInputStream fis = new FileInputStream(SystemInit.sysConfig.get("itilAttach") + path);
		String fileNameKey = "filename";
		if ("download".equals(operateType)) {
			response.addHeader("Content-Disposition", "attachment; " + fileNameKey + "=\"" + StringUtils.getFileName(filePath) + "\"");
		} else {
			response.addHeader("Content-Disposition", "inline; " + fileNameKey + "=\"" + StringUtils.getFileName(filePath) + "\"");
		}
		OutputStream out = response.getOutputStream();
		try {
			int read = 0;
			while ((read = fis.read()) != -1) {
				out.write(read);
			}
		} finally {
			fis.close();
			out.close();
		}
		return null;
	}

	/**
	 * 附件下载
	 * 
	 * @param params
	 * @param context
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 * @throws SQLException
	 * @throws NamingException
	 * @throws java.sql.SQLException
	 */
	public static JSONObject downLoad(JSONObject params, ActionContext context) throws ServletException, IOException, SQLException, NamingException, java.sql.SQLException {
		HttpServletResponse response = (HttpServletResponse) context.get(ActionContext.RESPONSE);
		HttpServletRequest request = (HttpServletRequest) context.get(ActionContext.REQUEST);
		String uri = request.getParameter("uri");
		String name = request.getParameter("name");
		String operateType = request.getParameter("operateType");
		URL reqUrl = new URL(BASE_URL + uri);
		System.out.println(BASE_URL + uri);
		HttpURLConnection conn = (HttpURLConnection) reqUrl.openConnection();
		conn.connect();
		InputStream ins = conn.getInputStream();
		response.setHeader("Cache-Control", "pre-check=0, post-check=0, max-age=0");
		String fileNameKey = "filename";
		if ("download".equals(operateType)) {
			response.addHeader("Content-Disposition", "attachment; " + fileNameKey + "=\"" + name + "\"");
		} else {
			response.addHeader("Content-Disposition", "inline; " + fileNameKey + "=\"" + name + "\"");
		}
		OutputStream out = response.getOutputStream();
		try {
			int read = 0;
			while ((read = ins.read()) != -1) {
				out.write(read);
			}
		} finally {
			ins.close();
			out.close();
			conn.disconnect();
		}
		return null;
	}

	public static JSONObject deleteFile(JSONObject params, ActionContext context) throws ServletException, IOException, SQLException, NamingException, java.sql.SQLException {
		String path = params.getString("path");
		File file = new File(SystemInit.sysConfig.get("itilAttach") + path);
		if (file.exists()) {
			file.delete();
		}

		return null;
	}

}
