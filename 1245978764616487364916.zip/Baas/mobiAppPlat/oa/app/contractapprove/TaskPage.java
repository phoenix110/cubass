package mobiAppPlat.oa.app.contractapprove;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import mobiAppPlat.oa.system.OASystemInit;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.RequestEntity;
import org.apache.commons.httpclient.methods.multipart.FilePart;
import org.apache.commons.httpclient.methods.multipart.MultipartRequestEntity;
import org.apache.commons.httpclient.methods.multipart.Part;
import org.apache.commons.httpclient.methods.multipart.StringPart;
import org.apache.commons.httpclient.protocol.Protocol;
import org.apache.commons.httpclient.protocol.ProtocolSocketFactory;
import org.jsoup.nodes.Document;

import com.justep.baas.action.ActionContext;

import forNet.net.HtmlParser;
import forNet.net.NetSecureProtocolSocketFactory;
import forNet.net.ReqObj;
import forNet.net.RespObj;
import forNet.net.SslNetServer;
import forNet.net.pages.ActionResult;
import forNet.net.util.Utils;

public class TaskPage {

	public static Map<String, String> getTaskDetailUrl(HttpClient httpClient,String taskUrl, Map<String, String> cookies, ActionContext context) {
		ReqObj req = new ReqObj();
		HttpServletRequest request = (HttpServletRequest) context.get(ActionContext.REQUEST);
		HttpSession session = request.getSession(true);
		//req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept", "Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		// req.addHeader("Accept-Encoding", "gzip, deflate, sdch"); //不压缩
		req.addHeader("Accept-Language", "zh-CN,zh;q=0.8");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		req.addHeader("Pragma", "no-cache");
		req.addHeader("Upgrade-Insecure-Requests", "1");
		req.addHeader("Referer", String.valueOf(session.getAttribute("taskListUrl")));
		req.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.4 Safari/537.36");
		req.setMethod("get");
		req.setUrl(OASystemInit.sysConfig.get("contractHost") + taskUrl.replace("\\", "/"));
		RespObj tasks = SslNetServer.service(httpClient,req, new TaskDetailGetUrlCallback());
		Map<String, String> data = (Map<String, String>) tasks.getResponseBody();
		return data;
	}

	public static ActionResult load(HttpClient httpClient,String taskUrl,String module, Map<String, String> cookies, ActionContext context) {
		
		Map<String, String> postParam = getTaskDetailUrl(httpClient,taskUrl, cookies, context);
		String detailUrl = OASystemInit.sysConfig.get("contractHost") + postParam.get("postSrc");
		postParam.remove("postSrc");
		postParam.remove("flag");
		HttpServletRequest request = (HttpServletRequest) context.get(ActionContext.REQUEST);
		HttpSession session = request.getSession(true);
		session.setAttribute("postParam", postParam);
		
		ActionResult ar = new ActionResult(true, "");
		ReqObj req = new ReqObj();
		//req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Referer", OASystemInit.sysConfig.get("contractHost")+taskUrl);
		req.setMethod("get");
		detailUrl = detailUrl.replace("\\", "/");
		req.setUrl(detailUrl);
		//获取详细信息
		RespObj tasks = null;
		System.out.println("##########:===="+module);
		if(module.equals("付款")){
			tasks = SslNetServer.service(httpClient,req, new TaskPageLoadCallbackFK());
		}else if(module.equals("合同申报")){
			
			tasks = SslNetServer.service(httpClient,req, new TaskPageLoadCallback());
		}
		ar.addCookies(tasks.getCookies());
		Map<String, Object> body = (Map<String, Object>) tasks.getResponseBody();
		ar.setData(body);
		ar.addCookies(tasks.getCookies());
		if(module.equals("合同申报")){
		//获取审批信息
			SslNetServer.service(httpClient,req, new TaskPageLoadCallback());
		}
		
		return ar;
	}
	
	//获取审批信息
   public static ActionResult loadAuditInfo(HttpClient httpClient,String taskUrl, Map<String, String> cookies, ActionContext context) {
	    System.out.println("auditUrl:"+OASystemInit.sysConfig.get("contractHost")+taskUrl);
		ActionResult ar = new ActionResult(true, "");
		ReqObj req = new ReqObj();
		//req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Referer", OASystemInit.sysConfig.get("contractHost")+taskUrl);
		req.setMethod("get");
		req.setUrl(OASystemInit.sysConfig.get("contractHost")+taskUrl);
		RespObj tasks = SslNetServer.service(httpClient,req, new TaskAuditInfoCallback());
		ar.addCookies(tasks.getCookies());
		Map<String, Object> body = (Map<String, Object>) tasks.getResponseBody();
		ar.setData(body);
		ar.addCookies(tasks.getCookies());
		
		return ar;
	}

	public static Map<String, String> getReturnPage(HttpClient httpClient,String taskUrl, Map<String, String> cookies) {
		ActionResult ar = new ActionResult(true, "");
		ReqObj req = new ReqObj();
		//req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept",
				"application/x-ms-application, image/jpeg, application/xaml+xml, image/gif, image/pjpeg, application/x-ms-xbap, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*");
		req.addHeader("Accept-Encoding", "gzip, deflate"); // 不压缩
		req.addHeader("Accept-Language", "zh-CN");
		// req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		req.addHeader("Referer", taskUrl);
		req.addHeader("User-Agent",
				"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/4.0; chromeframe/30.0.1599.69; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.3)");
		req.setMethod("get");
		req.setUrl(OASystemInit.sysConfig.get("contractHost") + taskUrl);
		RespObj tasks = SslNetServer.service(httpClient,req, new TaskListGetReturnPageCallback());
		;
		ar.addCookies(tasks.getCookies());
		Map<String, String> body = (Map<String, String>) tasks.getResponseBody();
		ar.setData(body);
		ar.addCookies(tasks.getCookies());
		return body;
	}

	public static Map<String, String> getDoReturnPage(HttpClient httpClient,String taskUrl, Map<String, String> cookies) {
		ActionResult ar = new ActionResult(true, "");
		ReqObj req = new ReqObj();
		//req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept",
				"application/x-ms-application, image/jpeg, application/xaml+xml, image/gif, image/pjpeg, application/x-ms-xbap, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*");
		req.addHeader("Accept-Encoding", "gzip, deflate"); // 不压缩
		req.addHeader("Accept-Language", "zh-CN");
		// req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		req.addHeader("Referer", taskUrl);
		req.addHeader("User-Agent",
				"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/4.0; chromeframe/30.0.1599.69; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.3)");
		req.setMethod("get");
		req.setUrl(OASystemInit.sysConfig.get("contractHost") + taskUrl);
		System.out.println("detailUrl:" + OASystemInit.sysConfig.get("contractHost") + taskUrl);
		RespObj tasks = SslNetServer.service(httpClient,req, new TaskListDoReturnCallback());
		ar.addCookies(tasks.getCookies());
		Map<String, String> body = (Map<String, String>) tasks.getResponseBody();
		ar.setData(body);
		ar.addCookies(tasks.getCookies());
		return body;
	}

	public static ActionResult goReturnPage(HttpClient httpClient,String taskUrl, Map<String, String> cookies) throws HttpException, IOException {
		HttpClient httpclient = new HttpClient();
		Map<String, String> params = getReturnPage(httpClient,taskUrl, cookies);
		String hostName = OASystemInit.sysConfig.get("contractHost") + taskUrl;
		PostMethod post = new PostMethod(hostName);
		post.setRequestHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		post.setRequestHeader("Accept-Language", "zh-CN,zh;q=0.8");
		post.setRequestHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36");
		// post.setRequestHeader("Content-Type", "multipart/form-data");
		post.setRequestHeader("Accept-Encoding", "gzip, deflate");
		// post.setRequestHeader("Host", "10.27.102.38");
		// post.setRequestHeader("Host", "expense.cnpc");
		post.setRequestHeader("Connection", "keep-alive");
		post.setRequestHeader("Cache-Control", "max-age=0");
		post.setRequestHeader("Upgrade-Insecure-Requests", "1");
		post.setRequestHeader("Cookie", Utils.map2String(cookies));
		
		ActionResult ar = new ActionResult(true, "");

		int i = 0;
		Part[] parts = new Part[params.size()];
		for (String key : params.keySet()) {
			if (key.indexOf("fileUpper") > 0) {
				File file = null;
				parts[i] = new FilePart(key, file);
			} else {
				parts[i] = new StringPart(key, params.get(key), "GB2312");
			}
			i++;
		}
		post.getParams().setContentCharset("GB2312");
		RequestEntity requestEntity = new MultipartRequestEntity(parts, post.getParams());
		post.setRequestEntity(requestEntity);
		httpclient.executeMethod(post);
		Document doc = HtmlParser.parser(post.getResponseBodyAsStream(), null);
		Map<String, Object> tagetData = PageUtils.getReturnTarget(doc);
		ActionResult result = new ActionResult(true, "");
		result.setFlag(true);
		result.setData(tagetData);
		post.releaseConnection();
		return result;
	}

	public static ActionResult doTask(String taskUrl, Map<String, String> cookies, Map<String, String> params) throws HttpException, IOException {
		ProtocolSocketFactory fcty = new NetSecureProtocolSocketFactory();
		Protocol.registerProtocol("https", new Protocol("https", fcty, 443));
		HttpClient httpClient = new HttpClient();
		String hostName = OASystemInit.sysConfig.get("contractHost") + taskUrl;
		PostMethod post = new PostMethod(hostName);
		post.setRequestHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		post.setRequestHeader("Accept-Language", "zh-CN,zh;q=0.8");
		post.setRequestHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36");
		post.setRequestHeader("Accept-Encoding", "gzip, deflate");
		post.setRequestHeader("Referer", hostName);
		post.setRequestHeader("Connection", "keep-alive");
		post.setRequestHeader("Cache-Control", "max-age=0");
		post.setRequestHeader("Upgrade-Insecure-Requests", "1");
		post.setRequestHeader("Cookie", Utils.map2String(cookies));

		int i = 0;
		Part[] parts = new Part[params.size()];
		for (String key : params.keySet()) {
			if (key.indexOf("fileUpper") > 0 || key.indexOf("postFile") > 0) {
				File file = null;
				parts[i] = new FilePart(key, file);
			} else {
				parts[i] = new StringPart(key, params.get(key), "utf-8");
			}
			i++;
		}
		post.getParams().setContentCharset("utf-8");
		RequestEntity requestEntity = new MultipartRequestEntity(parts, post.getParams());
		post.setRequestEntity(requestEntity);
		httpClient.executeMethod(post);
		post.releaseConnection();
		ActionResult result = new ActionResult(true, "");
		result.setFlag(true);
		return result;
	   }

	public static ActionResult doReturn(HttpClient httpClient,String taskUrl, Map<String, String> cookies, Map<String, String> params) throws HttpException, IOException {
		ReqObj req = new ReqObj();
		req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept",
				"application/x-ms-application, image/jpeg, application/xaml+xml, image/gif, image/pjpeg, application/x-ms-xbap, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*");
		req.addHeader("Accept-Encoding", "gzip, deflate");
		req.addHeader("Content-Type", "multipart/form-data");
		req.addHeader("Accept-Language", "zh-CN");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "Keep-Alive");
		req.addHeader("Pragma", "no-cache");
		req.addHeader("Upgrade-Insecure-Requests", "1");
		req.addHeader("Referer", OASystemInit.sysConfig.get("contractHost") + taskUrl);
		req.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.4 Safari/537.36");
		req.setMethod("post");
		req.setUrl(OASystemInit.sysConfig.get("contractHost") + taskUrl);
		req.getParams().putAll(params);
		RespObj resp = SslNetServer.service(httpClient,req, new TaskPageDoReturnCallback());
		ActionResult result = new ActionResult(true, resp.getResponseBody());
		result.addCookies(resp.getCookies());
		return result;
	}

	public static void main(String[] args) {
		String url = "http://10.27.102.38/CMSTrainingV2\\CtrDeclaration\\CtrInfoView.aspx?OULabel=025&ObjectID=2001388966&AccessMode=ReadOnly&FileMode=None";
		System.out.println(url.replace("\\", "/"));
	}

}
