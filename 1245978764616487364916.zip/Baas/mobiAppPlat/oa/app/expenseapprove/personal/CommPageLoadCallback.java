package mobiAppPlat.oa.app.expenseapprove.personal;

import java.io.InputStream;

import mobiAppPlat.oa.app.expenseapprove.beans.CommExpense;
import mobiAppPlat.oa.app.expenseapprove.utils.CommPageUtils;

import org.jsoup.nodes.Document;

import com.alibaba.fastjson.JSONObject;

import forNet.net.HtmlParser;
import forNet.net.RespCallback;
import forNet.net.pages.CheckUserOnline;

public class CommPageLoadCallback implements RespCallback {

	public Object execute(InputStream body) {
		
		JSONObject result = new JSONObject();
		Document doc = HtmlParser.parser(body, null);
		CheckUserOnline.checkOnline(doc);
		CommExpense commExpense = new CommExpense();
		//获取请求信息
		CommPageUtils.getPostInfo(doc, commExpense);
		//获取基本信息
		CommPageUtils.getBaseInfo(doc, commExpense);
		//附件
		CommPageUtils.getAttaDetail(doc, commExpense);
		//单据
		CommPageUtils.getListDetail(doc, commExpense);
		//获取历史审批信息
		CommPageUtils.getReviewIdea(doc, commExpense);
		//设置请求URL
		String postUrl=doc.getElementById("aspnetForm").attr("action");
		commExpense.setPostUrl(postUrl);
		//暂时只设置福利费
		/*
		if(postUrl.indexOf("SheetTypeID="+OASystemInit.sysConfig.get("travelListTypeCode"))>0){
			commExpense.setListType("2");
		}*/
		result.put("result", commExpense);
		System.out.println("result:"+result);
		return result;
	}

	public static void main(String[] args) {
		InputStream in = HtmlParser.class.getResourceAsStream("/mobiAppPlat/oa/app/expenseapprove/personal/commDetail.txt");
		Document doc = HtmlParser.parser(in, null);
		//CommPageUtils.getListDetail(doc, new CommExpense());
		//String s="./GlobalCommonSheet.aspx?action=3&amp;sheetid=26150801&amp;activityinstanceid=c4103d63-e0a5-4a1a-877c-1c3591bd9d9f&amp;SheetTypeID=61";
		//System.out.println(s.indexOf("SheetTypeID=61"));
	}

}
