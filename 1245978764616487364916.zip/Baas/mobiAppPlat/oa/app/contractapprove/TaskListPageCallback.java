package mobiAppPlat.oa.app.contractapprove;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.GZIPInputStream;

import mobiAppPlat.oa.app.contractapprove.beans.ContractTask;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import com.alibaba.fastjson.JSONObject;

import forNet.net.HtmlParser;
import forNet.net.RespCallback;
import forNet.net.pages.CheckUserOnline;

public class TaskListPageCallback implements RespCallback {

	public static void main(String[] args){
		InputStream in = HtmlParser.class.getResourceAsStream("/mobiAppPlat/oa/app/contractapprove/taskList.txt");
		RespCallback cb = new TaskListPageCallback();
		cb.execute(in);
		//Map<String, String> result = (Map<String, String>)cb.execute(in);
		//System.out.println(result);
	}
	
	public Object execute(InputStream body) {
		JSONObject jsob = new JSONObject();
		List<ContractTask> result = new ArrayList<ContractTask>();
		Document doc=null;
		try {
			//gizp方式进行解码 
			doc = HtmlParser.parser(new GZIPInputStream(body), null);
		} catch (IOException e1) {
			//发生异常,以普通方式进行解码
			doc = HtmlParser.parser(body, null);
			e1.printStackTrace();
		}
		//System.out.println("taskListHtml:"+doc.html());
		CheckUserOnline.checkOnline(doc);
			Element e = doc.getElementById("dgWaitWorksCase");
			int j=0;
			if (e != null) {
				for (Element tr : e.getElementsByTag("tr")) {
					int i = 0;
					j++;
					if(j==1){
						continue;
					}
					ContractTask task = new ContractTask();
					for (Element td : tr.getElementsByTag("td")) {
						if (i == 0) {
							//task.setName(td.html());
							Element url = td.getElementsByTag("a").get(0);
							task.setName(url.attr("title"));
							task.setDetailUrl(url.attr("href"));
						} else if (i == 1) {
							task.setModuleName(td.html());
						} else if (i == 2) {
							task.setFlowName(td.html());
						} else if (i == 3) {
							task.setTaskName(td.html());
						} else if (i == 4) {
							task.setStatusName(td.html());
						} else if (i == 5) {
							task.setCreateTime(td.html());
						} else if (i == 6) {
							Element url = td.getElementsByTag("a").get(0);
							task.setDeptName(url.attr("title"));
						} else if (i == 7) {
							task.setUserName(td.html());
						} else if (i == 8) {
							task.setDeputeName(td.html());
						}else if (i == 9) {
							task.setValidStatus(td.html());
						}else if (i == 10) {
							Element url = td.getElementsByTag("a").get(0);
							task.setProgress(url.attr("href"));
						}
						i++;
					}
					//第一阶段和最后阶段不处理
//				if(!"填报".equals(task.getStatusName())&&!"工作交接".equals(task.getTaskName())){
//				if(!"履行选择".equals(task.getTaskName())&&!"工作交接".equals(task.getTaskName())&&!"退回".equals(task.getTaskName())&&!"填报".equals(task.getTaskName())){
						 result.add(task);
//					}
					
				}
			}
		  jsob.put("result", result);
		  return result;
	}
}
