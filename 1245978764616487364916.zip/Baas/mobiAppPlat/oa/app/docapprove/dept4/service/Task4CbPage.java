package mobiAppPlat.oa.app.docapprove.dept4.service;

import java.util.Map;

import mobiAppPlat.oa.app.docapprove.bean.ActionResult;
import mobiAppPlat.oa.app.docapprove.bean.NetServer;
import mobiAppPlat.oa.app.docapprove.bean.ReqObj;
import mobiAppPlat.oa.app.docapprove.bean.RespObj;
import mobiAppPlat.oa.app.docapprove.dept4.service.Task4CbPageLoadCallback;
import mobiAppPlat.oa.app.docapprove.dept4.service.Task4ZcbPageDoTaskCallback;
import mobiAppPlat.oa.app.docapprove.utils.Utils;

public class Task4CbPage {

	public static ActionResult load(String id, String type, String status, Map<String, String> cookies){
		String url = Utils.getOaUrl("TaskDetailUrl");
		ActionResult ar = new ActionResult(true, "");
		//TODO 当前只支持“人事处处室收文和信息中心科室收文”
//		if (!status.equals("承办")){
//			throw new RuntimeException("暂不支持当前环节使用环节！");
//		}
		
		ReqObj req = new ReqObj();
		req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept", "Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		//req.addHeader("Accept-Encoding", "gzip, deflate, sdch"); //不压缩
		req.addHeader("Accept-Language", "zh-CN,zh;q=0.8");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		req.addHeader("Host", "oatraining.petrochina");
		req.addHeader("Pragma", "no-cache");
		req.addHeader("Upgrade-Insecure-Requests", "1");
		req.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.4 Safari/537.36");
		req.setMethod("get");
		req.setUrl(url + id);
		RespObj tasks = NetServer.service(req, new Task4CbPageLoadCallback());
		ar.addCookies(tasks.getCookies());
		Map<String, Object> body = (Map<String, Object>)tasks.getResponseBody();
		Map<String, String> task = (Map<String, String>)body.get("task");
		task.put("id", id);
		ar.setData(body);
		ar.addCookies(tasks.getCookies());
		return ar;
	}

	public static ActionResult doZcbTask(String id, Map<String, String> cookies, Map<String, String> params) {
		String url = Utils.getOaUrl("TaskDetailUrl");
		
		ReqObj req = new ReqObj();
		req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept", "image/jpeg, application/x-ms-application, image/gif, application/xaml+xml, image/pjpeg, application/x-ms-xbap, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*");
		req.addHeader("Accept-Encoding", "gzip, deflate");
		req.addHeader("Accept-Language", "zh-CN");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "Keep-Alive");
		req.addHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
		req.addHeader("Host", "oatraining.petrochina");
		req.addHeader("DNT", "1");
		
		req.addHeader("Referer", url + id);
		req.addHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.3; WOW64; Trident/7.0; .NET4.0E; .NET4.0C; .NET CLR 3.5.30729; .NET CLR 2.0.50727; .NET CLR 3.0.30729; InfoPath.2; Tablet PC 2.0; LCJB)");
		req.setMethod("post");
		req.setUrl(url + id);
		
		req.getParams().putAll(params);
		
		RespObj resp = NetServer.service(req, new Task4ZcbPageDoTaskCallback());
		ActionResult result = new ActionResult(true, resp.getResponseBody());
		result.addCookies(resp.getCookies());
		return result;
	}

	public static ActionResult doCssbTask(String id, Map<String, String> cookies, Map<String, String> params) {
		String url = Utils.getOaUrl("TaskDetailUrl");
		
		ReqObj req = new ReqObj();
		req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept", "image/jpeg, application/x-ms-application, image/gif, application/xaml+xml, image/pjpeg, application/x-ms-xbap, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*");
		req.addHeader("Accept-Encoding", "gzip, deflate");
		req.addHeader("Accept-Language", "zh-CN");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "Keep-Alive");
		req.addHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
		req.addHeader("Host", "oatraining.petrochina");
		req.addHeader("DNT", "1");
		
		req.addHeader("Referer", url + id);
		req.addHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.3; WOW64; Trident/7.0; .NET4.0E; .NET4.0C; .NET CLR 3.5.30729; .NET CLR 2.0.50727; .NET CLR 3.0.30729; InfoPath.2; Tablet PC 2.0; LCJB)");
		req.setMethod("post");
		req.setUrl(url + id);
		
		req.getParams().putAll(params);
		
		RespObj resp = NetServer.service(req, new Task4ZcbPageDoTaskCallback());
		ActionResult result = new ActionResult(true, resp.getResponseBody());
		result.addCookies(resp.getCookies());
		return result;
	}

}
