package mobiAppPlat.oa.app.docapprove;

import java.util.Map;

import mobiAppPlat.oa.app.docapprove.bean.ActionResult;
import mobiAppPlat.oa.app.docapprove.center1.service.Task1BgsdjPage;
import mobiAppPlat.oa.app.docapprove.center2.service.Task2BgsnbPage;
import mobiAppPlat.oa.app.docapprove.center3.service.Task3ZxldpsPage;
import mobiAppPlat.oa.app.docapprove.center4.service.Task4SpsPage;
import mobiAppPlat.oa.app.docapprove.dept1.service.Task1KsdjPage;
import mobiAppPlat.oa.app.docapprove.dept2.service.Task2KssbPage;
import mobiAppPlat.oa.app.docapprove.dept3.service.Task3KspbPage;
import mobiAppPlat.oa.app.docapprove.dept4.service.Task4CbPage;
import mobiAppPlat.oa.app.docapprove.utils.CookiesUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.justep.baas.action.ActionContext;


public class LoadTask {
	
	private static final String COOKIE_ID = CookiesUtils.getCookiesID();
	
	//加载（处室收文）流程的（科室登记）环节
	public static JSONObject load1KsdjTask(JSONObject params, ActionContext context){
		boolean flag = true;
		String msg = null;
		Object data = null;
		try{
			String id = params.getString("id");
			String type = params.getString("type");
			String status = params.getString("status");
			Map<String, String> cookies = CookiesUtils.getCookies(context,COOKIE_ID);
			ActionResult ar = Task1KsdjPage.load(id, type, status, cookies);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
				data = new JSONArray();
				//返回的结果是：Map<String, Map<String, String>>
				Map<String, Object> resp = (Map<String, Object>)ar.getData();
				data = new JSONObject();
				for (String key : resp.keySet()){
					JSONObject obj = new JSONObject();
					((JSONObject)data).put(key, obj);
					Object value = resp.get(key);
					obj.put(key,value);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		result.put("data", data);
		return result;
	}
	
	
	//加载（处室收文）流程的（科室送办）环节
	public static JSONObject load2KssbTask(JSONObject params, ActionContext context){
		boolean flag = true;
		String msg = null;
		Object data = null;
		try{
			String id = params.getString("id");
			String type = params.getString("type");
			String status = params.getString("status");
			Map<String, String> cookies = CookiesUtils.getCookies(context,COOKIE_ID);
			ActionResult ar = Task2KssbPage.load(id, type, status, cookies);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
				data = new JSONArray();
				//返回的结果是：Map<String, Map<String, String>>
				Map<String, Object> resp = (Map<String, Object>)ar.getData();
				data = new JSONObject();
				for (String key : resp.keySet()){
					JSONObject obj = new JSONObject();
					((JSONObject)data).put(key, obj);
					Object value = resp.get(key);
					obj.put(key,value);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		result.put("data", data);
		return result;
	}
	
	//加载（处室收文）流程的（科室批办）环节
	public static JSONObject load3KspbTask(JSONObject params, ActionContext context){
		boolean flag = true;
		String msg = null;
		Object data = null;
		try{
			String id = params.getString("id");
			String type = params.getString("type");
			String status = params.getString("status");
			Map<String, String> cookies = CookiesUtils.getCookies(context,COOKIE_ID);
			ActionResult ar = Task3KspbPage.load(id, type, status, cookies);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{ 
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
				//返回的结果是：Map<String, Map<String, String>>
				Map<String, Object> resp = (Map<String, Object>)ar.getData();
				data = new JSONObject();
				
				for (String key : resp.keySet()){
					JSONObject obj = new JSONObject();
					((JSONObject)data).put(key, obj);
					Object value = resp.get(key);
					obj.put(key, value);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		result.put("data", data);
		return result;
		
	}
	
	//加载(处室收文)流程的（承办）环节
	public static JSONObject load4CbTask(JSONObject params, ActionContext context){
		boolean flag = true;
		String msg = null;
		Object data = null;
		try{
			String id = params.getString("id");
			String type = params.getString("type");
			String status = params.getString("status");
			Map<String, String> cookies = CookiesUtils.getCookies(context,COOKIE_ID);
			ActionResult ar = Task4CbPage.load(id, type, status, cookies);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{ 
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
				//返回的结果是：Map<String, Map<String, String>>
				Map<String, Object> resp = (Map<String, Object>)ar.getData();
				data = new JSONObject();
				
				for (String key : resp.keySet()){
					JSONObject obj = new JSONObject();
					((JSONObject)data).put(key, obj);
					Object value = resp.get(key);
					obj.put(key, value);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		result.put("data", data);
		return result;
	}
	
	//加载（中心收文）流程的（办公室登记）环节
	public static JSONObject load1BgsdjTask(JSONObject params, ActionContext context){
		boolean flag = true;
		String msg = null;
		Object data = null;
		try{
			String id = params.getString("id");
			String type = params.getString("type");
			String status = params.getString("status");
			Map<String, String> cookies = CookiesUtils.getCookies(context,COOKIE_ID);
			ActionResult ar = Task1BgsdjPage.load(id, type, status, cookies);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
				data = new JSONArray();
				//返回的结果是：Map<String, Map<String, String>>
				Map<String, Object> resp = (Map<String, Object>)ar.getData();
				data = new JSONObject();
				for (String key : resp.keySet()){
					JSONObject obj = new JSONObject();
					((JSONObject)data).put(key, obj);
					Object value = resp.get(key);
					obj.put(key, value);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		result.put("data", data);
		return result;
	}
	
	//加载（中心收文）流程的（办公室拟办）环节
	public static JSONObject load2BgsnbTask(JSONObject params, ActionContext context){
		boolean flag = true;
		String msg = null;
		Object data = null;
		try{
			String id = params.getString("id");
			String type = params.getString("type");
			String status = params.getString("status");
			Map<String, String> cookies = CookiesUtils.getCookies(context,COOKIE_ID);
			ActionResult ar = Task2BgsnbPage.load(id, type, status, cookies);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
				data = new JSONArray();
				//返回的结果是：Map<String, Map<String, String>>
				Map<String, Object> resp = (Map<String, Object>)ar.getData();
				data = new JSONObject();
				for (String key : resp.keySet()){
					JSONObject obj = new JSONObject();
					((JSONObject)data).put(key, obj);
					Object value = resp.get(key);
					obj.put(key, value);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		result.put("data", data);
		return result;
	}
	
	//加载（中心收文）流程的（中心领导批示）环节
	public static JSONObject load3ZxldpsTask(JSONObject params, ActionContext context){
		boolean flag = true;
		String msg = null;
		Object data = null;
		try{
			String id = params.getString("id");
			String type = params.getString("type");
			String status = params.getString("status");
			Map<String, String> cookies = CookiesUtils.getCookies(context,COOKIE_ID);
			ActionResult ar = Task3ZxldpsPage.load(id, type, status, cookies);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
				data = new JSONArray();
				//返回的结果是：Map<String, Map<String, String>>
				Map<String, Object> resp = (Map<String, Object>)ar.getData();
				data = new JSONObject();
				for (String key : resp.keySet()){
					JSONObject obj = new JSONObject();
					((JSONObject)data).put(key, obj);
					Object value = resp.get(key);
					obj.put(key, value);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		result.put("data", data);
		return result;
	}
	
	//加载（公司收文）流程的（送批示）环节load4SpsTask
	public static JSONObject load4SpsTask(JSONObject params, ActionContext context){
		boolean flag = true;
		String msg = null;
		Object data = null;
		try{
			String id = params.getString("id");
			String type = params.getString("type");
			String status = params.getString("status");
			Map<String, String> cookies = CookiesUtils.getCookies(context,COOKIE_ID);
			ActionResult ar = Task4SpsPage.load(id, type, status, cookies);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
				data = new JSONArray();
				//返回的结果是：Map<String, Map<String, String>>
				Map<String, Object> resp = (Map<String, Object>)ar.getData();
				data = new JSONObject();
				for (String key : resp.keySet()){
					JSONObject obj = new JSONObject();
					((JSONObject)data).put(key, obj);
					Object value = resp.get(key);
					obj.put(key, value);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		result.put("data", data);
		return result;
	}
	

	// 加载经办公文或者传阅件
	public static JSONObject loadDeal(JSONObject params, ActionContext context) {
		boolean flag = true;
		String msg = null;
		Object data = null;
		try {
			String taskUrl = params.getString("taskUrl");
			Map<String, String> cookies = CookiesUtils.getCookies(context, COOKIE_ID);
			ActionResult ar = DealTaskPage.load(taskUrl, cookies);
			if (!ar.isFlag()) {
				flag = false;
				msg = ar.getData() + "";
			} else {
				CookiesUtils.updateCookies(context, ar.getCookies(), COOKIE_ID);
				data = new JSONArray();
				// 返回的结果是：Map<String, Map<String, String>>
				// Map<String, Object> resp = (Map<String, Object>)
				// ar.getData();
				data = ar.getData();
				/*
				 * for (String key : resp.keySet()) { JSONObject obj = new
				 * JSONObject(); ((JSONObject) data).put(key, obj); Object value
				 * = resp.get(key); obj.put(key, value); }
				 */
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		result.put("data", data);
		return result;
	}
	
}
