package mobiAppPlat.oa.app.docapprove;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import mobiAppPlat.oa.app.docapprove.bean.ActionResult;
import mobiAppPlat.oa.app.docapprove.bean.Task;
import mobiAppPlat.oa.app.docapprove.service.TaskListPage;
import mobiAppPlat.oa.app.docapprove.utils.CookiesUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.justep.baas.action.ActionContext;


public class TaskList {
	
	private static final String COOKIE_ID = CookiesUtils.getCookiesID();
	public static JSONObject getTasksList(JSONObject params, ActionContext context){
		HttpServletRequest request = (HttpServletRequest) context.get(ActionContext.REQUEST);

		boolean flag = true;
		String msg = null;
		Object data = null;
		Integer total = 0;
		Integer offset = params.getInteger("offset");
		String listType =params.getString("listType");

		try{
			Map<String, String> cookies = CookiesUtils.getCookies(context,COOKIE_ID);
			if (null != cookies) {
				System.out.println("获取到cookie："+cookies);
			}else {
				System.out.println("cookie为空！");
			}
			ActionResult ar = null;
			if("2".equals(listType)){
				ar=TaskListPage.loadDealed(cookies,offset,listType, request);
			}else{
				ar=TaskListPage.load(cookies,offset,listType,request);
			}
			
			total = ar.getTotal();
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
				data = ar.getData();
				JSONObject jsonObj = (JSONObject)JSONObject.toJSON(data);
				request.getSession().setAttribute("__VIEWSTATE", jsonObj.getString("__VIEWSTATE"));
				request.getSession().setAttribute("__EVENTVALIDATION", jsonObj.getString("__EVENTVALIDATION"));
				
				if("1".equals(listType)){
					total=jsonObj.getInteger("taskLiskCount");
				}else{
					total=jsonObj.getInteger("dealTaskLiskCount");
				}
			}
		}catch(Exception e){
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		result.put("data", data);
		result.put("total", total);
		
		return result;
	}
	

	public static JSONObject getCirculateTasksList(JSONObject params, ActionContext context){
		boolean flag = true;
		String msg = null;
		Object data = null;
		Integer total = 0;	
				Integer offset = params.getInteger("offset");
		String taskUrl =params.getString("taskUrl");
		try{
			Map<String, String> cookies = CookiesUtils.getCookies(context,COOKIE_ID);
			if (null != cookies) {
				System.out.println("获取到cookie："+cookies);
			}else {
				System.out.println("cookie为空！");
			}
			ActionResult ar = TaskListPage.loadCirculate(cookies,offset,taskUrl);
			//total = ar.getTotal();
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
				data = ar.getData();
				JSONObject jsonObj = (JSONObject)JSONObject.toJSON(data);
				total=jsonObj.getInteger("recordCount");
			}
		}catch(Exception e){
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		result.put("data", data);
		result.put("total", total);
		
		return result;
	}

}
