package mobiAppPlat.oa.app.expenseapprove.personal;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import mobiAppPlat.oa.app.expenseapprove.beans.ExpenseTask;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import com.alibaba.fastjson.JSONObject;

import forNet.net.HtmlParser;
import forNet.net.RespCallback;
import forNet.net.pages.CheckUserOnline;

public class TaskListPageCallback implements RespCallback {

	public Object execute(InputStream body) {
		JSONObject jsob = new JSONObject();
		List<ExpenseTask> result = new ArrayList<ExpenseTask>();
		Document doc = HtmlParser.parser(body, null);
		CheckUserOnline.checkOnline(doc);
		if (doc.getElementsByAttributeValueEnding("id", "CtrEmptyDataTemplate1_Label1").size() <= 0) {
			Element e = doc.getElementById("ctl00_h_GridFormList");
			if (e != null) {
				for (Element tr : e.getElementsByTag("tr")) {
					int i = 0;
					ExpenseTask task = new ExpenseTask();
					for (Element td : tr.getElementsByTag("td")) {
						if (i == 0) {
							task.setStatus(td.html());
						} else if (i == 1) {
							Element sibling = td.child(0);
							task.setDetailUrl(sibling.attr("href"));
							task.setReason(sibling.html());
						} else if (i == 2) {
							task.setApplyDeptName(td.html());
						} else if (i == 3) {
							task.setApplyUserName(td.html());
						} else if (i == 4) {
							task.setCurrency(td.html());
						} else if (i == 5) {
							task.setAmount(td.html());
						} else if (i == 6) {
							task.setListNo(td.html());
						} else if (i == 7) {
							task.setListType(td.html());
						} else if (i == 8) {
							task.setListTime(td.html());
						}
						i++;
					}
					result.add(task);
				}
			}
		}
		jsob.put("result", result);
		return result;
	}
}
