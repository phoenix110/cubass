package mobiAppPlat.oa.app.docapprove.bean;

import com.alibaba.fastjson.JSONObject;

public class Task {
	public String name = "";
	public String time = "";
	public String status = "";
	public String type = "";
	public String id = "";
	public String detailUrl = "";
	public String listType = "";
	public String wordFlowId;
	
	
	public String toString(){
		return toJson().toJSONString();
	}
	
	public JSONObject toJson(){
		JSONObject obj = new JSONObject();
		obj.put("id", id);
		obj.put("name", name);
		obj.put("time", time);
		obj.put("status", status);
		obj.put("type", type);
		obj.put("detailUrl", detailUrl);
		obj.put("listType", listType);
		obj.put("wordFlowId", wordFlowId);
		
		
		return obj;
	}
}
