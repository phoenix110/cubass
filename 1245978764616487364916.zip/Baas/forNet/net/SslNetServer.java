package forNet.net;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.net.ssl.SSLContext;

import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.SimpleHttpConnectionManager;
import org.apache.commons.httpclient.methods.DeleteMethod;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.InputStreamRequestEntity;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.PutMethod;
import org.apache.commons.httpclient.methods.multipart.MultipartRequestEntity;
import org.apache.commons.httpclient.methods.multipart.Part;
import org.apache.commons.httpclient.params.HttpClientParams;
import org.apache.commons.httpclient.protocol.Protocol;
import org.apache.commons.httpclient.protocol.ProtocolSocketFactory;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContexts;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

public class SslNetServer {

	public static void main(String[] args) {
		ReqObj req = new ReqObj();
		req.setUrl("https://cms.petrochina/CMSProduction/Login/Login.aspx?ReturnUrl=%2fCMSProduction%2fDefault.aspx");
		// req.setUrl("https://www.baidu.com/");
		req.setMethod("get");
		//SslNetServer.service(httpClient,req, null);
	}

	/**
	 * 
	 * @param req
	 * @param callback
	 * @return
	 */
	public static RespObj service(HttpClient httpClient,ReqObj req, RespCallback callback) {
		HttpMethod httpMethod = null;
		try {

			// httpClient = new HttpClient();
			httpMethod = getHttpMethod(req.getUrl(), req.getMethod());
			if ((httpMethod instanceof PostMethod) || (httpMethod instanceof PutMethod)) {
				Object postBody = req.getPostBody();
				if (httpMethod instanceof PostMethod && null != postBody) {
					if (postBody instanceof Part[]) {
						System.out.println("multipart requst...............");
						((PostMethod) httpMethod).setRequestEntity(new MultipartRequestEntity((Part[]) postBody, httpMethod.getParams()));
					} else if (postBody instanceof InputStream) {
						((PostMethod) httpMethod).setRequestEntity(new InputStreamRequestEntity((InputStream) postBody));
					}

				}

				Map<String, String> params = req.getParams();
				if (httpMethod instanceof PostMethod && null != params) {
					NameValuePair[] parametersBody = new NameValuePair[params.size()];
					int index = 0;
					for (String key : params.keySet()) {
						parametersBody[index++] = new NameValuePair(key, params.get(key));

					}
					((PostMethod) httpMethod).setRequestBody(parametersBody);
				}
			}

			Map<String, String> headers = req.getHeaders();
			for (String name : headers.keySet()) {
				httpMethod.addRequestHeader(name, headers.get(name));
			}
			int statusCode = httpClient.executeMethod(httpMethod);
			if ((statusCode != HttpStatus.SC_OK) && (statusCode != HttpStatus.SC_MOVED_TEMPORARILY)) {
				throw new RuntimeException("请求" + req.getUrl() + "出错！statusCode: " + statusCode);
			}

			RespObj resp = toRespObj(httpMethod, callback);
			return resp;
		} catch (Exception e) {
			throw new RuntimeException("请求" + req.getUrl() + "出错! " + e.getMessage(), e);
		} finally {
			// 释放连接
			if (httpMethod != null) {
				 httpMethod.releaseConnection();
			}
		}

	}

	/**
	 * 
	 * @param req
	 * @param callback
	 * @return
	 */
	public static RespObj doGet(ReqObj req, RespCallback callback) {
		CloseableHttpResponse response = null;
		CloseableHttpClient httpClient = null;
		try {
			httpClient = createSSLClientDefault(true);
			HttpGet httpGet = new HttpGet(req.getUrl());
			Map<String, String> headers = req.getHeaders();
			for (String name : headers.keySet()) {
				httpGet.setHeader(name, headers.get(name));
			}
			response = httpClient.execute(httpGet);

			int statusCode = response.getStatusLine().getStatusCode();
			if ((statusCode != HttpStatus.SC_OK) && (statusCode != HttpStatus.SC_MOVED_TEMPORARILY)) {
				throw new RuntimeException("请求" + req.getUrl() + "出错！statusCode: " + statusCode);
			}
			RespObj resp = toRespObj(httpGet, response, callback);
			return resp;
		} catch (Exception e) {
			throw new RuntimeException("请求" + req.getUrl() + "出错! " + e.getMessage(), e);
		} finally {
			// 释放连接
			try {
				if (response != null) {
					response.close();
				}
				if (httpClient != null) {
					httpClient.close();
				}

			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * 
	 * @param req
	 * @param callback
	 * @return
	 */
	public static RespObj doPost(ReqObj req, RespCallback callback) {
		CloseableHttpResponse response = null;
		CloseableHttpClient httpClient = null;
		try {
			httpClient = createSSLClientDefault(true);
			HttpPost httppost = new HttpPost(req.getUrl());
			Map<String, String> headers = req.getHeaders();
			for (String name : headers.keySet()) {
				httppost.setHeader(name, headers.get(name));
			}

			Map<String, String> params = req.getParams();
			// NameValuePair[] parametersBody = new
			// NameValuePair[params.size()];
			List parametersBody = new ArrayList<org.apache.http.NameValuePair>();
			int index = 0;
			for (String key : params.keySet()) {
				parametersBody.add(new org.apache.http.message.BasicNameValuePair(key, params.get(key)));
				// parametersBody[index++] = new NameValuePair(key,
				// params.get(key));
			}
			httppost.setEntity(new UrlEncodedFormEntity(parametersBody, "GBK"));

			response = httpClient.execute(httppost);

			int statusCode = response.getStatusLine().getStatusCode();
			if ((statusCode != HttpStatus.SC_OK) && (statusCode != HttpStatus.SC_MOVED_TEMPORARILY)) {
				throw new RuntimeException("请求" + req.getUrl() + "出错！statusCode: " + statusCode);
			}

			RespObj resp = toRespObj(httppost, response, callback);
			return resp;
		} catch (Exception e) {
			throw new RuntimeException("请求" + req.getUrl() + "出错! " + e.getMessage(), e);
		} finally {
			// 释放连接
			try {
				if (response != null) {
					response.close();
				}
				if (httpClient != null) {
					httpClient.close();
				}

			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	private static RespObj toRespObj(HttpMethod httpMethod, RespCallback callback) {
		RespObj resp = new RespObj();
		Header[] cookies = httpMethod.getResponseHeaders("Set-Cookie");
		if (cookies != null) {
			for (int i = cookies.length - 1; i >= 0; i--) {
				Header cookie = cookies[i];
				if (cookie != null) {
					String value = cookie.getValue();
					String first = value.split(";")[0];
					if (first.contains("=")) {
						String[] items = first.split("=");
						if (items.length == 2) {
							resp.addCookie(items[0], items[1]);
						}
					}

				}
			}
		}
		try {
			if (callback != null) {
				Object result = callback.execute(httpMethod.getResponseBodyAsStream());
				resp.setResponseBody(result);
			}
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage() + "", e);
		}
		return resp;
	}

	private static RespObj toRespObj(HttpRequestBase request, HttpResponse response, RespCallback callback) {
		RespObj resp = new RespObj();
		org.apache.http.Header[] cookies = response.getHeaders("Set-Cookie");
		if (cookies != null) {
			for (int i = cookies.length - 1; i >= 0; i--) {
				org.apache.http.Header cookie = cookies[i];
				if (cookie != null) {
					String value = cookie.getValue();
					System.out.println("cookie.getValue():" + cookie.getValue());
					String first = value.split(";")[0];
					if (first.contains("=")) {
						String[] items = first.split("=");
						if (items.length == 2) {
							resp.addCookie(items[0], items[1]);
						}
					}

				}
			}
		}
		try {
			HttpEntity entity = response.getEntity();
			if (callback != null) {
				Object result = callback.execute(new ByteArrayInputStream(EntityUtils.toByteArray(entity)));
				resp.setResponseBody(result);
			}
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage() + "", e);
		}
		return resp;
	}

	private static HttpMethod getHttpMethod(String url, String method) {
		if ("delete".equals(method)) {
			return new DeleteMethod(url);

		} else if ("get".equals(method)) {
			return new GetMethod(url);

		} else if ("post".equals(method)) {
			return new PostMethod(url);

		} else if ("put".equals(method)) {
			return new PutMethod(url);

		} else {
			throw new RuntimeException("不支持请求：" + method);
		}
	}

	/**
	 * 
	 * httpclient
	 * 
	 * @return
	 */
	private static CloseableHttpClient createSSLClientDefault(boolean isSSL) {
		CloseableHttpClient httpclient = null;

		try {
			if (!isSSL) {
				httpclient = HttpClients.createDefault();
			} else {
				// 测试
				String TRUSTSTORE_FILE = "d:/dgyt/trust.keystore";
				String KEYSTORE_PASSWORD = "123456";
				KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
				FileInputStream instream = new FileInputStream(new File(TRUSTSTORE_FILE));
				try {
					trustStore.load(instream, KEYSTORE_PASSWORD.toCharArray());
				} finally {
					instream.close();
				}
				// SSLContext context =
				// SSLContexts.custom().loadKeyMaterial(trustStore,
				// KEYSTORE_PASSWORD.toCharArray()).build();
				SSLContext context = SSLContexts.custom().loadKeyMaterial(trustStore, KEYSTORE_PASSWORD.toCharArray()).loadTrustMaterial(trustStore, new TrustSelfSignedStrategy()).build();

				SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(context, new String[] { "TLSv1" }, null, SSLConnectionSocketFactory.BROWSER_COMPATIBLE_HOSTNAME_VERIFIER);
				HttpClientBuilder builder = HttpClients.custom();
				httpclient = builder.setSSLSocketFactory(sslsf).build();
			}

			return httpclient;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return HttpClients.createDefault();
	}

}
