package admin.org;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 机构类型
 * 
 * @author luofei
 * 
 */
public class OrgKinds {

	private static OrgKinds instance = null;
	 private List<Map<String, Object>> orgKinds = null;
	 private OrgKinds() {
		initByConfig();
	}

	public static OrgKinds getInstance() {
		if (instance == null)
			instance = new OrgKinds();
		return instance;
	}

	@SuppressWarnings("rawtypes")
	private void initByConfig() {
		List orgKindList = new ArrayList();
		initBaseOrgKind(orgKindList, "ogn", "机构", "ogn", "false", "true", "01");
		initBaseOrgKind(orgKindList, "dpt", "部门", "ogn,dpt", "false", "false", "02");
		initBaseOrgKind(orgKindList, "pos", "岗位", "ogn,dpt", "false", "false", "03");
		initBaseOrgKind(orgKindList, "psm", "人员", "ogn,dpt,pos", "false", "false", "04");
		this.orgKinds = orgKindList;
	}
	
	@SuppressWarnings("unchecked")
	private static void initBaseOrgKind(List<Map<String, Object>> paramList, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5,
			String paramString6) {
		Map itemMap = new HashMap();
		itemMap.put("id", paramString1);
		Map dataMap = new HashMap();
		dataMap.put("zh_CN", paramString2);
		itemMap.put("labels", dataMap);
		itemMap.put("parents", paramString3);
		itemMap.put("virtual", paramString4);
		itemMap.put("root", paramString5);
		itemMap.put("sequence", paramString6);
		paramList.add(itemMap);
	}

	public List<Map<String, Object>> getOrgKinds() {
		return orgKinds;
	}
	public void setOrgKinds(List<Map<String, Object>> orgKinds) {
		this.orgKinds = orgKinds;
	}
	
}
