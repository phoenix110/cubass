package mobiAppPlat.oa.system;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.sql.DataSource;

import com.justep.baas.data.DataUtils;
import com.justep.baas.data.Row;
import com.justep.baas.data.Table;

import admin.utils.SystemConfigUtil;
import admin.utils.TelnetOperator;

import mobiAppPlat.oa.utils.ConfigUtil;

public class OASystemInit implements ServletContextListener {
	public static Map<String, String> sysConfig = null;

	public void contextDestroyed(ServletContextEvent event) {
		// TODO 自动生成的方法存根

	}

	public void contextInitialized(ServletContextEvent event) {

		System.out.println("门户开始初始化......");
		sysConfig = new HashMap<String, String>();
		sysConfig.put("dsOa",           ConfigUtil.getConfigValue("dsOa"));
		sysConfig.put("uploadBaseDir",  ConfigUtil.getConfigValue("uploadBaseDir"));
		sysConfig.put("portalBaseUrl",  ConfigUtil.getConfigValue("portalBaseUrl"));
		sysConfig.put("isCompress",     ConfigUtil.getConfigValue("isCompress"));
		sysConfig.put("minPixel",       ConfigUtil.getConfigValue("minPixel"));
		sysConfig.put("portalSiteName", ConfigUtil.getConfigValue("portalSiteName"));
		sysConfig.put("expenseLoginUrl", ConfigUtil.getConfigValue("expenseLoginUrl"));
		sysConfig.put("expenseTaskList", ConfigUtil.getConfigValue("expenseTaskList"));
		sysConfig.put("expenseBaseUrl", ConfigUtil.getConfigValue("expenseBaseUrl"));
		sysConfig.put("expenseIndex",   ConfigUtil.getConfigValue("expenseIndex"));
		sysConfig.put("porTalUrl",      ConfigUtil.getConfigValue("porTalUrl"));
		
		
		sysConfig.put("contractHost",      ConfigUtil.getConfigValue("contractHost"));
		sysConfig.put("contractBaseUrl",      ConfigUtil.getConfigValue("contractBaseUrl"));
		sysConfig.put("contractLoginUrl",      ConfigUtil.getConfigValue("contractLoginUrl"));
		sysConfig.put("contractTaskList",      ConfigUtil.getConfigValue("contractTaskList"));
		sysConfig.put("contractIndex",        ConfigUtil.getConfigValue("contractIndex"));
		sysConfig.put("contractDoLogin",        ConfigUtil.getConfigValue("contractDoLogin"));
		System.out.println("门户初始化完成......");
		
	}


}
