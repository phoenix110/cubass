package mobiAppPlat.oa.app.docapprove.utils;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.justep.baas.action.ActionContext;

public class CookiesUtils {
	public static void updateCookies(ActionContext ac, Map<String, String> cookies,String cookie_id){
		if (cookies == null) return;
		HttpServletRequest request = (HttpServletRequest)ac.get(ActionContext.REQUEST);
		HttpSession session = request.getSession(true);
		Map<String, String> container = (Map<String, String>)session.getAttribute(cookie_id); 
		if (container == null){
			container = new ConcurrentHashMap<String, String>();
			session.setAttribute(cookie_id, container);
		}
		container.putAll(cookies);
	}
	
	public static Map<String, String> getCookies(ActionContext ac,String cookie_id){
		HttpServletRequest request = (HttpServletRequest)ac.get(ActionContext.REQUEST);
		HttpSession session = request.getSession(true);
		Map<String, String> container = (Map<String, String>)session.getAttribute(cookie_id); 
		if (container == null){
			container = new ConcurrentHashMap<String, String>();
		}
		return container;
	}
	
	public static String getCookiesID(){
		return "server.docapprove.cookie";
	}
}
