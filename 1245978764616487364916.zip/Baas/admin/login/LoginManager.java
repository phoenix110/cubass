package admin.login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import admin.beans.Role;
import admin.beans.User;
import admin.beans.UserPermission;
import admin.login.service.DomainLogin;
import admin.login.service.ILoginStrategy;
import admin.login.service.LocalLogin;
import admin.utils.StringUtil;
import admin.utils.SystemInit;

import com.alibaba.fastjson.JSONObject;
import com.justep.baas.action.ActionContext;
import com.justep.baas.data.DataUtils;
import com.justep.baas.data.Row;
import com.justep.baas.data.Table;

/**
 * 用户管理
 * 
 * @author luofei
 * 
 */
public class LoginManager {
	/**
	 * 登录
	 * 
	 * @param params
	 * @param context
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws IOException
	 */
	public static JSONObject excute(JSONObject params, ActionContext context) throws SQLException, NamingException, IOException {
		HttpServletResponse response = (HttpServletResponse) context.get(ActionContext.RESPONSE);
//		String loginName = params.getString("loginName");
//		Connection conn = context.getConnection(SystemInit.sysConfig.get("dsSys"));
//		List<Object> sqlParams = new ArrayList<Object>();
//		sqlParams.add(loginName);
//		PreparedStatement stmt = conn
//				.prepareStatement("select a.sUserType userType from sa_opperson a,SA_OPOrg b where a.sMainOrgID=b.sID and  a.sValidState=1 and a.sLoginName=?");
//		stmt.setString(1, loginName);
//		ResultSet rs = stmt.executeQuery();
//		String userType = "0";
//		if(rs.next()){
//			userType = rs.getString("userType");
//		}
//		System.out.println("userType ====== : "+userType );
//		ILoginStrategy login = null;
//		if (userType .equals("0")) {
//			// 域账号登录
//			login = new DomainLogin();
//		} else {
//			login = new LocalLogin();
//		}
		
		// 本地登录
		ILoginStrategy login = null;
		if ("1".equals(SystemInit.sysConfig.get("loginMode"))) {
			// 域账号登录
			login = new DomainLogin();
		} else {
			login = new LocalLogin();
		}
		
		JSONObject loginMsg = login.login(params, context);
		if (1 == loginMsg.getIntValue("msg")) {
			new LoginManager().loadUserContext(params, context);
		} else {
			DataUtils.writeJsonToResponse(response, loginMsg);
		}
		return null;
	}

	/**
	 * 加载用户信息(包含用户基本信息、组织信息、角色信息、权限信息)
	 * 
	 * @param params
	 * @param context
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws IOException
	 */
	private void loadUserContext(JSONObject params, ActionContext context) throws SQLException, NamingException, IOException {
		JSONObject jsonObj = new JSONObject();
		HttpServletResponse response = (HttpServletResponse) context.get(ActionContext.RESPONSE);
		HttpServletRequest request = (HttpServletRequest) context.get(ActionContext.REQUEST);

		String loginName = params.getString("loginName");
		String client = params.getString("client");
		Connection conn = context.getConnection(SystemInit.sysConfig.get("dsSys"));
		List<Object> sqlParams = new ArrayList<Object>();
		sqlParams.add(loginName);
		PreparedStatement stmt = conn
				.prepareStatement("select a.sID,a.sName,a.sCode,a.sLoginName,a.sPassword,a.sPhoto,a.sUserType userType,b.sID orgId,b.sName orgName,b.sCode orgCode,b.sFID orgFId,b.sFCode orgFCode,b.sFName orgFName,sMobilePhone,sOfficePhone,sMail,sFamilyAddress,sParent from sa_opperson a,SA_OPOrg b where a.sMainOrgID=b.sID and  a.sValidState=1 and a.sLoginName=?");
		stmt.setString(1, loginName);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			User user = new User();
			user.setId(rs.getString("sID"));
			user.setCode(rs.getString("sCode"));
			user.setName(rs.getString("sName"));
			user.setLoginName(rs.getString("sLoginName"));
			user.setOrgId(rs.getString("orgId"));
			user.setOrgCode(rs.getString("orgCode"));
			user.setOrgName(rs.getString("orgName"));
			user.setOrgFId(rs.getString("orgFId"));
			user.setOrgFCode(rs.getString("orgFCode"));
			user.setOrgFName(rs.getString("orgFName"));
			user.setPassword(rs.getString("sPassword"));
			user.setAddress(rs.getString("sFamilyAddress"));
			user.setMail(rs.getString("sMail"));
			user.setPhone(rs.getString("sMobilePhone"));
			user.setOficePhone(rs.getString("sMobilePhone"));
			user.setParentId(rs.getString("sParent"));
			user.setUserType(rs.getInt("userType"));
			//后台登录时一次性加载角色和权限
			if ("admin".equals(client)) {
				List<Role> roleList = this.getRoles(conn, user.getOrgFId());
				user.setRoles(roleList);
				user.setPermissions(this.getUserPermisions(conn, roleList, client));
				request.getSession().setAttribute("userInfo", user);
			}
			jsonObj.put("user", user);
		}
		DataUtils.writeJsonToResponse(response, jsonObj);
	}
	private List<Role> getRoles(Connection conn, String orgFId) {
		List<Object> sqlParams = new ArrayList<Object>();
		sqlParams.add(orgFId);
		Table table = DataUtils.queryData(conn, "select distinct b.sID,b.sCode,b.sName,b.sRoleKind from sa_opauthorize a,SA_OPRole b where a.sAuthorizeRoleID=b.sID and  charindex(a.sOrgID ,?)>0",
				sqlParams, null, null, null);
		List<Role> roleList = new ArrayList<Role>();
		List<Row> rows = table.getRows();
		for (Row row : rows) {
			Role role = new Role();
			role.setId(row.getString("sID"));
			role.setCode(row.getString("sCode"));
			role.setName(row.getString("sName"));
			role.setKind(row.getString("sRoleKind"));
			roleList.add(role);
		}
		return roleList;
	}

	/**
	 * 获取用户的权限(用户的角色的权限去重)
	 * 
	 * @param roleId
	 * @return
	 * @throws SQLException
	 */
	private List<UserPermission> getUserPermisions(Connection conn, List<Role> roleList, String client) throws SQLException {
		Map<String, UserPermission> permissionMap = new HashMap<String, UserPermission>();
		for (Role role : roleList) {
			String sql = "select b.sID,b.sCode,b.sName,b.sFID,b.sFCode,b.sFName,b.sUrl,sParent,b.sKind,b.sIcon from SA_OPPermission a,SA_OPFunction b where a.sFuncId=b.sID and sPermissionRoleID=?";
			if ("admin".equals(client)) {
				sql = sql + " and b.sKind=1";
			} else {
				sql = sql + " and b.sKind=2";
			}

			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1, role.getId());
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				UserPermission userPermission = new UserPermission();
				userPermission.setId(rs.getString("sID"));
				userPermission.setCode(rs.getString("sCode"));
				userPermission.setName(rs.getString("sName"));
				userPermission.setFullId(rs.getString("sFID"));
				userPermission.setFullCode(rs.getString("sFCode"));
				userPermission.setFullName(rs.getString("sFName"));
				userPermission.setUrl(rs.getString("sUrl"));
				userPermission.setKind(rs.getInt("sKind"));
				userPermission.setParentId(rs.getString("sParent"));
				userPermission.setIcon(StringUtil.getBase64String(rs.getBinaryStream("sIcon")));
				permissionMap.put(rs.getString("sID"), userPermission);
			}
		}
		return new ArrayList<UserPermission>(permissionMap.values());
	}
	
	/**
	 * 获取服务列表
	 * @param roleId
	 * @return
	 * @throws SQLException 
	 * @throws NamingException 
	 * @throws IOException 
	 */
	public static JSONObject getAppServs(JSONObject params, ActionContext context) throws SQLException, NamingException, IOException {
		JSONObject jsonObj = new JSONObject();
		HttpServletResponse response = (HttpServletResponse) context.get(ActionContext.RESPONSE);
		List<UserPermission> permissions = new ArrayList<UserPermission>();
		Connection conn = context.getConnection(SystemInit.sysConfig.get("dsSys"));
			String sql = "select  c.sID,c.sCode,c.sName,c.sFID,c.sFCode,c.sFName,c.sUrl,c.sParent,c.sKind,c.sIcon from SA_OPFunction c where c.sKind=3 order by c.sSequence";
			PreparedStatement stmt = conn
					.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			String funcId="";
			while (rs.next()) {
				UserPermission userPermission = new UserPermission();
				userPermission.setId(rs.getString("sID"));
				userPermission.setCode(rs.getString("sCode"));
				userPermission.setName(rs.getString("sName"));
				userPermission.setFullId(rs.getString("sFID"));
				userPermission.setFullCode(rs.getString("sFCode"));
				userPermission.setFullName(rs.getString("sFName"));
				userPermission.setUrl(rs.getString("sUrl"));
				userPermission.setKind(rs.getInt("sKind"));
				userPermission.setParentId(rs.getString("sParent"));
				userPermission.setIcon(StringUtil.getBase64String(rs.getBinaryStream("sIcon")));
				if(!rs.getString("sID").equals(funcId)){
					permissions.add(userPermission);
				}
				funcId=rs.getString("sID");
			}
			jsonObj.put("permissions", permissions);
			DataUtils.writeJsonToResponse(response, jsonObj);
		return null; 
	   }

}
