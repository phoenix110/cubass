package mobiAppPlat.oa.app.docapprove.bean;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

import mobiAppPlat.oa.app.docapprove.bean.ReqObj;
import mobiAppPlat.oa.app.docapprove.bean.RespCallback;
import mobiAppPlat.oa.app.docapprove.bean.RespObj;

import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.SimpleHttpConnectionManager;
import org.apache.commons.httpclient.methods.DeleteMethod;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.InputStreamRequestEntity;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.PutMethod;
import org.apache.commons.httpclient.methods.multipart.MultipartRequestEntity;
import org.apache.commons.httpclient.methods.multipart.Part;
import org.apache.commons.httpclient.params.HttpClientParams;

public class NetServer {
	public static RespObj service(ReqObj req, RespCallback callback){
		HttpMethod httpMethod = null;
		try {
			HttpClient httpClient = new HttpClient(new HttpClientParams(), new SimpleHttpConnectionManager(true)); //hcr 测试关闭连接  //new HttpClient();
			
			httpMethod = getHttpMethod(req.getUrl(), req.getMethod());
			
			if ((httpMethod instanceof PostMethod) || (httpMethod instanceof PutMethod)) {
				
				/*
				if (null != data)
					((EntityEnclosingMethod) httpMethod).setRequestEntity(new ByteArrayRequestEntity(data));
				*/
				Object postBody = req.getPostBody();
				if (httpMethod instanceof PostMethod && null != postBody){
					if (postBody instanceof Part[]){
						((PostMethod) httpMethod).setRequestEntity(new MultipartRequestEntity((Part[])postBody, httpMethod.getParams()));	
					}else if (postBody instanceof InputStream){
						((PostMethod) httpMethod).setRequestEntity(new InputStreamRequestEntity((InputStream)postBody));
					}
					
				}
				
				Map<String, String> params = req.getParams();
				if (httpMethod instanceof PostMethod && null != params){
					NameValuePair[] parametersBody = new NameValuePair[params.size()];
					int index = 0;
					for (String key : params.keySet()){
						parametersBody[index++] = new NameValuePair(key, params.get(key));
						
					}
					((PostMethod) httpMethod).setRequestBody(parametersBody);
					//String body = "__VIEWSTATE=%2FwEPDwUKMTE0NTAwNjkxNGRkY88%2BL%2Fl1ndiZap4Re0gDRnoUgHM%3D&__VIEWSTATEGENERATOR=2BF08017&__EVENTVALIDATION=%2FwEWBAKurozdBQKG87HkBgK1qbSRCwKC3IeGDD8sl2cAkxki7U%2FSurMDRt6hS7zL&txtLogin=ptr%5Cdg_liuqing18&txtPassword=6599&btnLogin=%E7%99%BB%E5%BD%95";
					//((PostMethod) httpMethod).setRequestBody(body);
					//((PostMethod) httpMethod).setRequestEntity(new ByteArrayRequestEntity(body.getBytes("UTF-8"), "UTF-8"));
					
				}
				
			}

			Map<String, String> headers = req.getHeaders();
			for (String name : headers.keySet()){
				httpMethod.addRequestHeader(name, headers.get(name));
			}
			int statusCode = httpClient.executeMethod(httpMethod);
			if ((statusCode != HttpStatus.SC_OK) && (statusCode != HttpStatus.SC_MOVED_TEMPORARILY )) {
				throw new RuntimeException("请求" + req.getUrl() + "出错！statusCode: " + statusCode);
			}
			
			RespObj resp = toRespObj(httpMethod, callback);
			return resp;
		} catch (Exception e) {
			throw new RuntimeException("请求" + req.getUrl() + "出错! " + e.getMessage(), e);
		} finally {
			// 释放连接
			if (httpMethod != null){
				httpMethod.releaseConnection();
			}
		}
	}
	
	
	
	private static RespObj toRespObj(HttpMethod httpMethod, RespCallback callback){
		RespObj resp = new RespObj();
		Header[] cookies = httpMethod.getResponseHeaders("Set-Cookie");
		if (cookies != null){
			for (int i=cookies.length-1; i>=0; i--){
				Header cookie = cookies[i]; 
				if (cookie != null) {
					String value = cookie.getValue();
					String first = value.split(";")[0];
					if (first.contains("=")){
						String[] items = first.split("=");
						if (items.length==2){
							resp.addCookie(items[0], items[1]);
						}
					}
					
				}
			}
		}
		try {
			if (callback != null){
				//System.out.println(httpMethod.getPath());
				Object result = callback.execute(httpMethod.getResponseBodyAsStream());
				resp.setResponseBody(result);
			}
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage()+"", e);
		}
		return resp;
		/*
		contentType = null != httpMethod.getResponseHeader("Content-Type") ? httpMethod.getResponseHeader("Content-Type").getValue() : accept;
		if (bsessionID == null) {
			Header[] cookies = httpMethod.getResponseHeaders("Set-Cookie");
			if (cookies != null){
				for (int i=cookies.length-1; i>=0; i--){
					Header cookie = cookies[i]; //解决webshpere的问题，取最后一个为准
					if (cookie != null) {
						bsessionID = cookie.getValue();
						if (bsessionID.startsWith("JSESSIONID=")){
							bsessionID = bsessionID.substring(bsessionID.indexOf("=") + 1);
						}
						
						if (bsessionID.contains(";")){
							bsessionID = bsessionID.substring(0, bsessionID.indexOf(";"));
						}
						
						if ((bsessionID!=null) && !bsessionID.equals("")){
							break;
						}
					}
				}
			}
			
		}
		InputStream o = httpMethod.getResponseBodyAsStream();
		if (callback != null){
			callback.execute(o, contentType, bsessionID);
			return null;
		}else{
			return new ActionResult(o, contentType, bsessionID);
		}
		*/			
	}
	
	private static HttpMethod getHttpMethod(String url, String method) {
		if ("delete".equals(method)) {
			return new DeleteMethod(url);

		} else if ("get".equals(method)) {
			return new GetMethod(url);

		} else if ("post".equals(method)) {
			return new PostMethod(url);

		} else if ("put".equals(method)) {
			return new PutMethod(url);

		} else {
			throw new RuntimeException("不支持请求：" + method);
		}
	}
	
}
