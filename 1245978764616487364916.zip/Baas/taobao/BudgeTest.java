package taobao;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;

import javax.xml.namespace.QName;
import javax.xml.rpc.ServiceException;

//import org.codehaus.xfire.client.Client;


public class BudgeTest {
	public static Object invokeService(String namespace, String address, String operation, Object[] params) throws MalformedURLException, RemoteException, ServiceException {
		// 调用WebService
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		org.apache.axis.client.Call call = (org.apache.axis.client.Call) service.createCall();
		call.setOperationName(new QName(namespace, operation));
		call.setTargetEndpointAddress(new java.net.URL(address));

		return call.invoke(params);
	}
//	public static void main(String arg[]) throws MalformedURLException, RemoteException, ServiceException{
//		String xmlStr = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><DATA><REQUESTDATA>xml字符串数据</REQUESTDATA>";
//		xmlStr += "<DATAINFOS>";
//		Object[] testParams = {"<?xml version=\"1.0\" encoding=\"UTF-8\"?><DATA><REQUESTDATA>xml字符串数据</REQUESTDATA>"};
//		Object testResult = invokeService("http://10.254.1.163:51/ServiceBIF.asmx?wsdl", "http://microsoft.com/webservices/", "UpdateBudgetRevisionResult", testParams);
//		System.out.println(testResult.toString());
//	}
	public static void main(String[] args) throws MalformedURLException, Exception {   
        // TODO Auto-generated method stub   
//        String xmlStr = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><DATA><REQUESTDATA>xml字符串数据</REQUESTDATA>";
//		xmlStr += "<DATAINFOS>";
//		xmlStr += "<FLOWID>yb0Ud9qH5aRcI8scSyL</FLOWID>";
//		xmlStr += "<MAINID>D90A45A6-8FFC-4C32-B8B3-DE6A770F72F3</MAINID>";
//		xmlStr += "<APPROVE>不通过</APPROVE>";
//		xmlStr += "<ATTACHMENT></ATTACHMENT>";
//		xmlStr += "</DATAINFOS>";
//		xmlStr += "</DATA>";
               
		//远程调用.net开发的webservice   
//		Client c=new Client(new URL("http://10.254.1.163:51/ServiceBIF.asmx?wsdl"));   
//		Object[] o=c.invoke("UpdateBudgetRevisionResult", new String[]{xmlStr});   
		    
		URL url = new URL("http://10.76.19.159/CommonServices/CommonService.asmx/GetDataBySql?strUserName=fengqi172@163.com&strPassword=1qaz2wsx&modename=PCDM97&systemName=移动应用平台&subSystemUser=夏鑫&sql=select RQ from dks02 where RZSL ='99830'");
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("GET");
		conn.setConnectTimeout(5 * 1000);
		conn.connect();
		InputStream ins = conn.getInputStream();
		BufferedReader reader = new BufferedReader(new InputStreamReader(ins, "utf-8"));
		StringBuffer sb = new StringBuffer();
		String line = null;
		while ((line = reader.readLine()) != null) {
			sb.append(line + "\n");
		}
		ins.close();
		System.out.println(sb.toString());
		
		//		Object[] params = new Object[] {
//				"fengqi172@163.com",
//				"1qaz2wsx",
//				"PCDM97",
//				"移动应用平台",
//				"夏鑫",
//				"select RQ from dks02 where BZRBH='-7161'"
//				};
//		//远程调用.net开发的webservice   
//		Client c=new Client(new URL("http://10.76.19.159/CommonServices/CommonService"));   
//		Object[] o=c.invoke("GetDataBySql", params);
//		System.out.println(o[0].toString());
		
		
		
//		//调用.net本机开发的webservice   
//		Client c1=new Client(new URL("http://localhost/zj/Service.asmx?wsdl"));   
//		Object[] o1=c1.invoke("HelloWorld",new String[]{}); 
	}
	
}
