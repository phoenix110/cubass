package mobiAppPlat.oa.home;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletResponse;

import mobiAppPlat.oa.system.OASystemInit;
import mobiAppPlat.oa.utils.ConfigUtil;
import mobiAppPlat.oa.utils.ImgCompress;
import net.coobird.thumbnailator.Thumbnails;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.poi.hslf.blip.Bitmap;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import admin.utils.StringUtil;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.zxing.common.BitMatrix;
import com.justep.baas.action.ActionContext;
import com.justep.baas.data.DataUtils;
import com.justep.baas.data.Table;
import com.justep.baas.data.Transform;

/**
 * 新闻门户
 * 
 * @author luofei
 * 
 */
public class NewsPortals {

	/**
	 * 获取新闻信息
	 * 
	 * @param params
	 * @param context
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws IOException
	 * @throws URISyntaxException
	 */
	public static JSONObject getNews(JSONObject params, ActionContext context) throws SQLException, NamingException, IOException, URISyntaxException {
		// 获取参数
		Object columns = params.get("columns");
		Integer limit = params.getInteger("limit");
		Integer offset = params.getInteger("offset");
		int tpId = params.getInteger("id");
		String listId = params.getString("listId");
		int rowOrdinal = params.getInteger("rowOrdinal");
		List<Object> sqlParams = new ArrayList<Object>();

		sqlParams.add(tpId);
		sqlParams.add(listId);
		sqlParams.add(rowOrdinal);
		Table table = null;
		Connection conn = context.getConnection(OASystemInit.sysConfig.get("dsOa"));
		StringBuffer bf = new StringBuffer(" select a.nvarchar7 title,a.ntext6 content,a.ntext3 img,b.DirName,b.LeafName,CONVERT(varchar(100), DATEADD(hh, 8 ,datetime1),120)  createTime,0 readCount "
				+ " from  AllUserData a ").append(" inner join AllDocs b on a.tp_DocId=b.Id").append(" where a.tp_ID=? and a.tp_listId=? and a.tp_RowOrdinal=?")
				.append("and a.tp_IsCurrent= 1 and a.tp_DeleteTransactionId=0 ").append("and a.tp_IsCurrentVersion=1 and a.tp_ModerationStatus=0 and a.ntext6 is not null");
		try {

			long start = System.currentTimeMillis();
			table = DataUtils.queryData(conn, bf.toString(), sqlParams, columns, offset, limit);
			long end = System.currentTimeMillis();
			System.out.println("end-start:" + (end - start));
			// 图片路径列表
			List<String> imgList = new ArrayList<String>();
			JSONObject jsonObj = Transform.tableToJson(table);
			JSONArray arr = jsonObj.getJSONArray("rows");
			JSONObject content = null;
			for (int i = 0; i < arr.size(); i++) {
				JSONObject obj = arr.getJSONObject(i);
				content = obj.getJSONObject("content");
				Document doc = Jsoup.parse(content.getString("value"));
				Elements list = doc.select("img");
				for (Element element : list) {
					Element parent = element.parent();
					// 附件
					if ("a".equals(parent.tagName())) {
						/*
						parent.attr("url", parent.attr("href"));
						parent.attr("href", "#");
						element.attr("src", element.attr("src"));
						imgList.add(element.attr("src"));
						element.removeAttr("class");
						element.addClass("imgClass");
						parent.addClass("attaClass");
						*/
						parent.remove();
					} else {
						imgList.add(element.attr("src"));
						// 先放一个默认的图片,之后再异步加载
						element.attr("src", "./home/img/default.png");
						// 设置一个默认的样式方便识别图片标签
						element.addClass("imgClass");
						// 宽度100%,高度默认设置成200px
						// element.attr("style",
						// "margin:5px;width:100%;height:200px");
						element.attr("style", "margin:5px;width:100%;height:auto");
					}
				}

				// 把第一个<p></p>去掉
				list = doc.select("p:eq(0)");
				for (Element element : list) {
					String html = element.html();
					if ("%3F".equals(URLEncoder.encode(html, "ISO8859-1"))) {
						element.remove();
					}
				}
				content.put("value", doc.html());
			}

			// 把图片列表放到List中并传到前台
			content.put("imgList", imgList);
			long finish = System.currentTimeMillis();

			System.out.println("finish-end:" + (finish - end));
			return jsonObj;

		} finally {
			conn.close();
		}
	}

	/**
	 * 获取图片流(同时进行压缩)
	 * 
	 * @param params
	 * @param context
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws IOException
	 */
	public static JSONObject getImageStream(JSONObject params, ActionContext context) throws SQLException, NamingException, IOException {
		HttpServletResponse response = (HttpServletResponse) context.get(ActionContext.RESPONSE);
		//String imgUrl = java.net.URLDecoder.decode( params.getString("imgUrl"),"utf-8");
		String imgUrl = params.getString("imgUrl");
		System.out.println("==========imgUrl=========="+imgUrl);
		String attaName = params.getString("attaName");
		if(!StringUtil.isEmpty(attaName)){
			response.addHeader("Content-Disposition", "inline; filename=\"" + 
		    java.net.URLEncoder.encode(attaName, "UTF-8") + "\"");
		}
		String isCompress = params.getString("isCompress");
		InputStream ins = ConfigUtil.getImageStream(OASystemInit.sysConfig.get("portalBaseUrl")+imgUrl);
		int tmpi = 0;
		OutputStream out = response.getOutputStream();
	
		// 如果压缩开关打开,则压缩
		if ("1".equals(OASystemInit.sysConfig.get("isCompress")) && "1".equals(isCompress)) {
			/*
			ImgCompress imgCom = new ImgCompress(ins);
			while ((tmpi = ins.read()) != -1) {
				out.write(tmpi);
			}
			int size = Integer.parseInt(String.valueOf(OASystemInit.sysConfig.get("minPixel")));
			imgCom.resizeFix(size, size, out);
			*/
			Thumbnails.of(ins).scale(1f).outputQuality(0.5f).toOutputStream(out);
		} else {
			while ((tmpi = ins.read()) != -1) {
				out.write(tmpi);
			}
		}
		ins.close();
		out.flush();
		out.close();
		return null;
	}

	@SuppressWarnings("deprecation")
	public static JSONObject getReadCount(JSONObject params, ActionContext context) throws URISyntaxException, ClientProtocolException, IOException {

		HttpServletResponse resp = (HttpServletResponse) context.get(ActionContext.RESPONSE);
		String SiteName = (String) OASystemInit.sysConfig.get("portalSiteName");
		String url = OASystemInit.sysConfig.get("portalBaseUrl") + "/CounterPage/ClientInfo2012.ashx?jsoncallback=readCount&SiteName=" + SiteName;
		String LeafName = params.getString("LeafName");
		String ChannelPath = java.net.URLEncoder.encode("/" + params.getString("DirName")) + "/";
		String PageUrl = OASystemInit.sysConfig.get("portalBaseUrl") + ChannelPath + LeafName;
		PageUrl = java.net.URLEncoder.encode(PageUrl, "UTF-8");
		String depSize = java.net.URLEncoder.encode("1366,768");
		String PageTitle = java.net.URLEncoder.encode(params.getString("title"), "UTF-8");
		PageTitle = java.net.URLEncoder.encode(PageTitle, "UTF-8");
		String PageName = LeafName;
		url = url + "&UpSiteName=" + "&ChannelPath=" + ChannelPath + "&PageTitle=" + PageTitle + "&depSize=" + depSize + "&PageName=" + PageName + "&PageUrl=" + PageUrl
				+ "&ShowName=PageUrl&Numlong=8";
		CloseableHttpClient httpClient = HttpClients.createDefault();
		HttpGet request = new HttpGet();
		request.setURI(new URI(url));
		HttpResponse response = httpClient.execute(request);
		HttpEntity entity = response.getEntity();
		String content = EntityUtils.toString(entity).replace("(", "").replace(")", "").replace("readCount", "");
		JSONObject readCountJson = JSONObject.parseObject(content);
		resp.getWriter().write(readCountJson.toJSONString());
		httpClient.close();
		return null;
	}
}
