package forNet.net;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.KeyStore;

import javax.net.ssl.SSLContext;

import org.apache.commons.httpclient.ConnectTimeoutException;
import org.apache.commons.httpclient.HttpClientError;
import org.apache.commons.httpclient.params.HttpConnectionParams;
import org.apache.commons.httpclient.protocol.ControllerThreadSocketFactory;
import org.apache.commons.httpclient.protocol.SecureProtocolSocketFactory;
import org.apache.http.conn.ssl.SSLContexts;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;

/**
 * 加载证书的方式
 * @author luofei
 *
 */
public class NetSecureProtocolSocketFactory implements SecureProtocolSocketFactory {
	
    private SSLContext sslContext = null;
    private final static String TRUSTSTORE_FILE = "d:/dgyt/trust.keystore";
	private final static String KEYSTORE_PASSWORD = "123456";
    /**
     * Constructor for MySecureProtocolSocketFactory.
     */
    public NetSecureProtocolSocketFactory() {
    }
 
    /**
     * @return
     */
    private static SSLContext createEasySSLContext() {
        try {
        	
        	// load the trusted certs :
    		KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
    		FileInputStream instream1 = new FileInputStream(new File(TRUSTSTORE_FILE));
    		try {
    			trustStore.load(instream1, KEYSTORE_PASSWORD.toCharArray());
    		} finally {
    			instream1.close();
    		}
        	
             SSLContext context  = SSLContexts.custom()
            	        .loadKeyMaterial(trustStore, KEYSTORE_PASSWORD.toCharArray())
            	        .loadTrustMaterial(trustStore, new TrustSelfSignedStrategy())
            	        .build();
              return context;
        } catch (Exception e) {
            throw new HttpClientError(e.toString());
        }
    }
 
    /**
     * @return
     */
    private SSLContext getSSLContext() {
        if (this.sslContext == null) {
            this.sslContext = createEasySSLContext();
        }
        return this.sslContext;
    }
 
    /*
     * (non-Javadoc)
     * @see
     * org.apache.commons.httpclient.protocol.ProtocolSocketFactory#createSocket(java.lang.String,
     * int, java.net.InetAddress, int)
     */
    public Socket createSocket(String host, int port, InetAddress clientHost, int clientPort) throws IOException,
        UnknownHostException {
 
        return getSSLContext().getSocketFactory().createSocket(host, port, clientHost, clientPort);
    }
 
    /*
     * (non-Javadoc)
     * @see
     * org.apache.commons.httpclient.protocol.ProtocolSocketFactory#createSocket(java.lang.String,
     * int, java.net.InetAddress, int, org.apache.commons.httpclient.params.HttpConnectionParams)
     */
    public Socket createSocket(final String host, final int port, final InetAddress localAddress, final int localPort,
            final HttpConnectionParams params) throws IOException, UnknownHostException, ConnectTimeoutException {
        if (params == null) {
            throw new IllegalArgumentException("Parameters may not be null");
        }
        int timeout = params.getConnectionTimeout();
        if (timeout == 0) {
            return createSocket(host, port, localAddress, localPort);
        } else {
            return ControllerThreadSocketFactory.createSocket(this, host, port, localAddress, localPort, timeout);
        }
    }
 
    /*
     * (non-Javadoc)
     * @see SecureProtocolSocketFactory#createSocket(java.lang.String,int)
     */
    public Socket createSocket(String host, int port) throws IOException, UnknownHostException {
        return getSSLContext().getSocketFactory().createSocket(host, port);
    }
 
    /*
     * (non-Javadoc)
     * @see SecureProtocolSocketFactory#createSocket(java.net.Socket,java.lang.String,int,boolean)
     */
    public Socket createSocket(Socket socket, String host, int port, boolean autoClose) throws IOException,
        UnknownHostException {
        return getSSLContext().getSocketFactory().createSocket(socket, host, port, autoClose);
    }
}