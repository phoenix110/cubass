package mobiAppPlat.oa.app.org;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import mobiAppPlat.oa.app.docapprove.bean.ActionResult;
import mobiAppPlat.oa.app.docapprove.utils.CookiesUtils;
import mobiAppPlat.oa.app.org.servce.OrgPage;

import com.alibaba.fastjson.JSONObject;
import com.justep.baas.action.ActionContext;
import com.justep.baas.data.ColumnValue;
import com.justep.baas.data.DataType;
import com.justep.baas.data.Row;
import com.justep.baas.data.RowState;
import com.justep.baas.data.Table;
import com.justep.baas.data.Transform;

public class Org {

	private static final String COOKIE_ID = CookiesUtils.getCookiesID();
	
	public static JSONObject loadDeptPerson(JSONObject params, ActionContext context){
		boolean flag = true;
		String msg = null;
		Table table = null;
		String paramsData = params.getString("paramsData");
		JSONObject jsob = new JSONObject();
		jsob = jsob.parseObject(paramsData);
		String type = params.getString("type");
		try{
			Map<String, String> cookies = CookiesUtils.getCookies(context,COOKIE_ID);
			ActionResult ar = OrgPage.loadDeptPerson(cookies,type,jsob);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
				//返回的结果是：Map<String, Map<String, String>>
				Map<String, Object> resp = (Map<String, Object>)ar.getData();
				
				Map<String, DataType> columns = new LinkedHashMap<String, DataType>();
				columns.put("id", DataType.STRING);
				columns.put("name", DataType.STRING);
				columns.put("parent", DataType.STRING);
				table = new Table(columns);
				
				
				for (String key : resp.keySet()){
					Map<String, ColumnValue> column = new HashMap<String, ColumnValue>();
					column.put("name", new ColumnValue(key));
					column.put("id", new ColumnValue((((Map<String, String>)resp.get(key)).entrySet().iterator().next().getKey())));
					column.put("parent", new ColumnValue(((Map<String, String>)resp.get(key)).entrySet().iterator().next().getValue()));
					Row row = new Row(column, RowState.NEW);
					table.appendRow(row);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		//加工data的数据格式
		
		
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		result.put("data", Transform.tableToJson(table));
		return result;
	}
	
	public static JSONObject loadAllPerson(JSONObject params, ActionContext context){
		boolean flag = true;
		String msg = null;
		Table table = null;
		String paramsData = params.getString("paramsData");
		JSONObject jsob = new JSONObject();
		jsob = jsob.parseObject(paramsData);
		Integer count = params.getInteger("count");
		String type = params.getString("type");
		try{
			Map<String, String> cookies = CookiesUtils.getCookies(context,COOKIE_ID);
			ActionResult ar = OrgPage.loadAllPerson(cookies,count,type,jsob);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
				//返回的结果是：Map<String, Map<String, String>>
				Map<String, Object> resp = (Map<String, Object>)ar.getData();
				Map<String, Object> data = (Map<String, Object>)resp.get("data");
				Map<String, Object> orgType = (Map<String, Object>)resp.get("orgType");
				
				Map<String, DataType> columns = new LinkedHashMap<String, DataType>();
				columns.put("id", DataType.STRING);
				columns.put("name", DataType.STRING);
				columns.put("parent", DataType.STRING);
				columns.put("fid", DataType.STRING);
				columns.put("type", DataType.STRING);
				table = new Table(columns);
				for (String key : data.keySet()){
					Map<String, ColumnValue> column = new HashMap<String, ColumnValue>();
					column.put("name", new ColumnValue(key));
					column.put("id", new ColumnValue((((Map<String, String>)data.get(key)).entrySet().iterator().next().getKey())));
					column.put("parent", new ColumnValue(((Map<String, String>)data.get(key)).entrySet().iterator().next().getValue()));
					column.put("fid", new ColumnValue("".equals(jsob.getString("fid"))?"/"+(((Map<String, String>)data.get(key)).entrySet().iterator().next().getKey()):jsob.getString("fid")+"/"+(((Map<String, String>)data.get(key)).entrySet().iterator().next().getKey())));
					column.put("type", new ColumnValue(orgType.get((((Map<String, String>)data.get(key)).entrySet().iterator().next().getKey()))));
					Row row = new Row(column, RowState.NEW);
					table.appendRow(row);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		//加工data的数据格式
		
		
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		result.put("data", Transform.tableToJson(table));
		return result;
	}
	
	public static JSONObject loadAllOrg(JSONObject params, ActionContext context){
		boolean flag = true;
		String msg = null;
		Object data = null;
		String paramsData = params.getString("paramsData");
		JSONObject jsob = new JSONObject();
		jsob = jsob.parseObject(paramsData);
		try{
			Map<String, String> cookies = CookiesUtils.getCookies(context,COOKIE_ID);
			ActionResult ar = OrgPage.loadAllOrg(cookies,jsob);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
				//返回的结果是：Map<String, Map<String, String>>
				data = ar.getData();
				
			}
		}catch(Exception e){
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		//加工data的数据格式
		
		
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		result.put("data", data);
		return result;
	}
	
	
}
