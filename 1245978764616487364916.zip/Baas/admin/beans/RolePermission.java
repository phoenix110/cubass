package admin.beans;

/**
 * 角色的权限
 * 
 * @author luofei
 * 
 */
public class RolePermission {
	/**
	 * 角色id
	 */
	private String roleId;
	/**
	 * 权限id
	 */
	private String funcId;
	/**
	 * 权限编码
	 */
	private String funcCode;
	/**
	 * 权限名称
	 */
	private String funcName;
	/**
	 * 权限full ID
	 */
	private String funcFId;
	/**
	 * 权限full 编码
	 */
	private String funcFCode;
	/**
	 * 权限full 名称
	 */
	private String funcFName;
	/**
	 * 权限路径
	 */
	private String funcUrl;
	/**
	 * 权限类型
	 */
	private Integer kind; 

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public String getFuncId() {
		return funcId;
	}

	public void setFuncId(String funcId) {
		this.funcId = funcId;
	}

	public String getFuncCode() {
		return funcCode;
	}

	public void setFuncCode(String funcCode) {
		this.funcCode = funcCode;
	}

	public String getFuncName() {
		return funcName;
	}

	public void setFuncName(String funcName) {
		this.funcName = funcName;
	}

	public String getFuncFId() {
		return funcFId;
	}

	public void setFuncFId(String funcFId) {
		this.funcFId = funcFId;
	}

	public String getFuncFCode() {
		return funcFCode;
	}

	public void setFuncFCode(String funcFCode) {
		this.funcFCode = funcFCode;
	}

	public String getFuncFName() {
		return funcFName;
	}

	public void setFuncFName(String funcFName) {
		this.funcFName = funcFName;
	}

	public String getFuncUrl() {
		return funcUrl;
	}

	public void setFuncUrl(String funcUrl) {
		this.funcUrl = funcUrl;
	}

	public Integer getKind() {
		return kind;
	}

	public void setKind(Integer kind) {
		this.kind = kind;
	}
}
