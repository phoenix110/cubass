package itil;

import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.justep.baas.action.ActionContext;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class NetProxy {
	public static final String BASE_URL = "http://10.76.248.16:8084/baas";
	public static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
	public static OkHttpClient client = null;
	public static final Map<String, String> serviceMap = new HashMap<String, String>();

	static {
		client = new OkHttpClient();
		// 告警 列表
		serviceMap.put("1", "/itil/mainService/queryAlarm");
		// 告警详情
		serviceMap.put("2", "/itil/mainService/loadAlarm");
		// 获取工单表单布局接口
		serviceMap.put("3", "/itil/mainService/queryAlarm");
		// 工单创建接口
		serviceMap.put("4", "/itil/mainService/createWorkOrder");
		// 待办工单查询接口
		serviceMap.put("5", "/itil/mainService/queryWorkOrder");
		// 待办工单详情接口
		serviceMap.put("6", "/itil/mainService/loadWorkOrder");
		// 工单处理接口
		serviceMap.put("7", "/itil/mainService/queryAlarm");
		// 上传附件接口
		serviceMap.put("8", "/itil/mainService/queryAlarm");
		// 用户权限
		serviceMap.put("9", "/itil/mainService/queryAlarm");
		// 字典接口
		serviceMap.put("10", "/itil/mainService/queryAlarm");
	}

	public static JSONObject queryAlarm(JSONObject params, ActionContext context) throws Exception {
		AlarmCondition condition = new AlarmCondition();
		String sercieId = params.getString("sercieId");
		condition.setId(params.getString("id"));
		condition.setType(params.getString("type"));
		condition.setServerity(params.getString("serverity"));
		condition.setProcess(params.getInteger("process"));
		AlarmParam alarmParam = new AlarmParam();
		alarmParam.setUserId(params.getString("userId"));
		alarmParam.setCondition(condition);
		RequestBody body = RequestBody.create(JSON, JSONObject.toJSONString(alarmParam));
		Request.Builder requestBuilder = new Request.Builder().url(BASE_URL + serviceMap.get(sercieId));
		requestBuilder.method("POST", body);
		requestBuilder.addHeader("Content-Type", "application/json");
		requestBuilder.addHeader("Accept", "application/json; charset=utf-8");
		requestBuilder.addHeader("sysCode", "COSS");
		Request request = requestBuilder.build();
		ResponseBody resp = null;
		String content = "";
		try {
			Response response = client.newCall(request).execute();
			resp = response.body();
			content = resp.string();
			System.out.println("===========content==========" + content);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return JSONObject.parseObject(content);
	}

	public static JSONObject alarmForm(JSONObject params, ActionContext context) throws Exception {
		String sercieId = params.getString("sercieId");
		String userId = params.getString("userId");
		String id = params.getString("id");
		Request.Builder requestBuilder = new Request.Builder().url(BASE_URL + serviceMap.get(sercieId) + "?id=" + id + "&userId=" + userId);
		requestBuilder.addHeader("Content-Type", "application/json");
		requestBuilder.addHeader("Accept", "application/json; charset=utf-8");
		requestBuilder.addHeader("sysCode", "COSS");
		Request request = requestBuilder.build();
		ResponseBody resp = null;
		String content = "";
		try {
			Response response = client.newCall(request).execute();
			resp = response.body();
			content = resp.string();
			System.out.println("===========content==========" + content);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return JSONObject.parseObject(content);
	}

	public static JSONObject queryWorkOrder(JSONObject params, ActionContext context) throws Exception {
		String sercieId = params.getString("sercieId");
		String userId = params.getString("userId");
		String moduleId = params.getString("moduleId");
		String querykey = params.getString("querykey");
		String url = BASE_URL + serviceMap.get(sercieId) + "?";
		if (!"".equals(userId)) {
			url = url + "userId=" + userId;
		}
		if (!"".equals(moduleId)) {
			url = url + "&moduleId=" + moduleId;
		}
		if (!"".equals(querykey) && null != querykey) {
			url = url + "&key=" + querykey;
		}
		System.out.println(url);
		Request.Builder requestBuilder = new Request.Builder().url(url);
		requestBuilder.addHeader("Content-Type", "application/json");
		requestBuilder.addHeader("Accept", "application/json; charset=utf-8");
		requestBuilder.addHeader("sysCode", "COSS");
		Request request = requestBuilder.build();
		ResponseBody resp = null;
		String content = "";
		try {
			Response response = client.newCall(request).execute();
			resp = response.body();
			content = resp.string();
			System.out.println("===========content==========" + content);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return JSONObject.parseObject(content);
	}

	public static JSONObject loadWorkOrder(JSONObject params, ActionContext context) throws Exception {
		String sercieId = params.getString("sercieId");
		String userId = params.getString("userId");
		String taskId = params.getString("taskId");
		String dataonly = params.getString("dataonly");
		String url = BASE_URL + serviceMap.get(sercieId) + "?";
		if (!"".equals(userId)) {
			url = url + "userId=" + userId;
		}
		if (!"".equals(taskId)) {
			url = url + "&taskId=" + taskId;
		}
		if (!"".equals(dataonly) && null != dataonly) {
			url = url + "&dataonly=" + dataonly;
		}
		System.out.println(url);
		Request.Builder requestBuilder = new Request.Builder().url(url);
		requestBuilder.addHeader("Content-Type", "application/json");
		requestBuilder.addHeader("Accept", "application/json; charset=utf-8");
		requestBuilder.addHeader("sysCode", "COSS");
		Request request = requestBuilder.build();
		ResponseBody resp = null;
		String content = "";
		try {
			Response response = client.newCall(request).execute();
			resp = response.body();
			content = resp.string();
			System.out.println("===========content==========" + content);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return JSONObject.parseObject(content);
	}

	public static JSONObject createWorkOrder(JSONObject params, ActionContext context) throws Exception {
		String sercieId = params.getString("sercieId");
		String postParams = params.getString("postParams");
		RequestBody body = RequestBody.create(JSON, postParams);
		Request.Builder requestBuilder = new Request.Builder().url(BASE_URL + serviceMap.get(sercieId));
		requestBuilder.method("POST", body);
		requestBuilder.addHeader("Content-Type", "application/json");
		requestBuilder.addHeader("Accept", "application/json; charset=utf-8");
		requestBuilder.addHeader("sysCode", "COSS");
		Request request = requestBuilder.build();
		ResponseBody resp = null;
		String content = "";
		try {
			Response response = client.newCall(request).execute();
			resp = response.body();
			content = resp.string();
			System.out.println("===========content==========" + content);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return JSONObject.parseObject(content);
	}

	public static void main(String[] args) {

		JSONObject.parseObject("{result:{\"success\":false}}");
	}

}
