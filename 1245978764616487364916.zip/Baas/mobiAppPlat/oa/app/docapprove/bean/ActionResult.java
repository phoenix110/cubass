package mobiAppPlat.oa.app.docapprove.bean;

import java.util.HashMap;
import java.util.Map;

public class ActionResult {
	private boolean flag = false;
	private Object data = null;
	private Integer total = 0;
	private Map<String, String> cookies = new HashMap<String, String>();
	
	public ActionResult(boolean flag, Object data){
		this.setFlag(flag);
		this.setData(data);
	}

	public boolean isFlag() {
		return flag;
	}

	public void setFlag(boolean flag) {
		this.flag = flag;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public Map<String, String> getCookies() {
		return cookies;
	}

	public void addCookies(Map<String, String> cookies) {
		if (cookies  != null)
			this.cookies.putAll(cookies);
	}

	public Integer getTotal() {
		return total;
	}

	public void setTotal(Integer total) {
		this.total = total;
	}
	
}
