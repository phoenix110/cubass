package taobao;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.xml.sax.InputSource;

import com.alibaba.fastjson.JSONObject;

public class DgTest {
	public static void main(String args[]) throws Exception{
		
		InputStream iStream = null;
		String result = "";
		Document doc = null;
		JSONObject jsob = new JSONObject();
		try {
			URL url = new URL("http://10.76.19.159/CommonServices/CommonService.asmx/GetDataBySql?strUserName=fengqi172@163.com&strPassword=1qaz2wsx&modename=PCDM97&systemName=%E7%A7%BB%E5%8A%A8%E5%BA%94%E7%94%A8%E5%B9%B3%E5%8F%B0&subSystemUser=%E5%A4%8F%E9%91%AB&sql=select%20*%20from%20dks02%20where%20RZSL%20=%2799830%27");
			URLConnection connection = url.openConnection();
			iStream = connection.getInputStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(iStream, "utf-8"));
			StringBuffer sb = new StringBuffer();
			String line = null;
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
			iStream.close();
			result = sb.toString();
			System.out.println(result);
		} catch (Exception e) {
			e.printStackTrace();
		}
		InputStream stream2 = new ByteArrayInputStream(result.getBytes("UTF-8"));

		SAXReader saxReader = new SAXReader();
		saxReader.setEncoding("UTF-8");
		try {
			doc = (Document) saxReader.read(new InputSource(stream2));
		} catch (DocumentException e1) {
			e1.printStackTrace();
		}
		List<Element> lists = doc.selectNodes("//DocumentElement//data");
		for (Element adds : lists) {
			List<Element> datainfos = adds.elements();
			Node rq = adds.element("RQ");
			Node dwdm = adds.element("DWDM");
			System.out.println(rq.getText());
			System.out.println(dwdm.getText());
			
			jsob.put("DWDM", rq.getText());
			jsob.put("RQ", rq.getText());
			jsob.put("TJLB", rq.getText());
			jsob.put("ZJS", rq.getText());
			jsob.put("SJJS", rq.getText());
			jsob.put("KJS", rq.getText());
			jsob.put("RZSL", rq.getText());
			jsob.put("BZRBH", rq.getText());
			jsob.put("YLJ", rq.getText());
			jsob.put("RBKJS", rq.getText());
			jsob.put("RBGJS", rq.getText());
			jsob.put("TZZJS", rq.getText());
			jsob.put("TZZRZSL", rq.getText());
			jsob.put("SCSJ", rq.getText());
		}
	}

}
