package yqlbb;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.xml.sax.InputSource;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.justep.baas.action.ActionContext;

public class Yqlbb {
	public static  JSONObject geiDate(JSONObject params, ActionContext context) throws UnsupportedEncodingException{
		InputStream iStream = null;
		String result = "";
		Document doc = null;
		JSONArray jsoa = new JSONArray();
		
		String date = params.getString("date");
		try {
			URL url = new URL("http://10.76.19.159/CommonServices/CommonService.asmx/GetDataBySql?strUserName=fengqi172@163.com&" +
					"strPassword=1qaz2wsx&modename=PCDM97&systemName=%E7%A7%BB%E5%8A%A8%E5%BA%94%E7%94%A8%E5%B9%B3%E5%8F%B0&" +
					"subSystemUser=%E5%A4%8F%E9%91%AB&" +
					"sql=select%20*%20from%20dbaa14%20where%20TO_CHAR(RQ,%27YYYY-MM-DD%27)=%27"+date+"%27%20and%20" +
					"(DWDM%20=%20%270%27%20or%20DWDM%20=%20%270Z%27%20or%20DWDM%20=%20%270Y%27)");
			System.out.println("90:=="+url);
			URLConnection connection = url.openConnection();
			iStream = connection.getInputStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(iStream, "utf-8"));
			StringBuffer sb = new StringBuffer();
			String line = null;
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
			iStream.close();
			result = sb.toString();
			System.out.println(result);
		} catch (Exception e) {
			e.printStackTrace();
		}
		InputStream stream2 = new ByteArrayInputStream(result.getBytes("UTF-8"));

		SAXReader saxReader = new SAXReader();
		saxReader.setEncoding("UTF-8");
		try {
			doc = (Document) saxReader.read(new InputSource(stream2));
		} catch (DocumentException e1) {
			e1.printStackTrace();
		}
		List<Element> lists = doc.selectNodes("//DocumentElement//data");
		for (Element adds : lists) {
			JSONObject jsob = new JSONObject();
			List<Element> datainfos = adds.elements();
			Node RQ = adds.element("RQ");
			Node DWDM = adds.element("DWDM");
			Node TJLB = adds.element("TJLB");
			Node SJZS = adds.element("SJZS");
			Node KJS = adds.element("KJS");
			Node YJZS = adds.element("YJZS");
			Node CYJS = adds.element("CYJS");
			Node RCY = adds.element("RCY");
			Node RCQ = adds.element("RCQ");
			Node BZRZY = adds.element("BZRZY");
			Node YCY = adds.element("YCY");
			Node YCQ = adds.element("YCQ");
			Node DJYCY = adds.element("DJYCY");
			Node XJJS = adds.element("XJJS");
			Node XJRCY = adds.element("XJRCY");
			Node XJYCY = adds.element("XJYCY");
			Node DBJJS = adds.element("DBJJS");
			Node DBJRCY = adds.element("DBJRCY");
			Node DBJYCY = adds.element("DBJYCY");
			Node CSJJS = adds.element("CSJJS");
			Node CSJRCY = adds.element("CSJRCY");
			Node CSJYCY = adds.element("CSJYCY");
			Node BZRZQ = adds.element("BZRZQ");
			Node SCSJ = adds.element("SCSJ");
			Node RCY1 = adds.element("RCY1");
			Node BZRZY1 = adds.element("BZRZY1");
			if(DWDM!=null)
			jsob.put("DWDM", DWDM.getText());
			if(RQ!=null)
			jsob.put("RQ", RQ.getText());
			if(TJLB!=null)
			jsob.put("TJLB", TJLB.getText());
			if(SJZS!=null)
			jsob.put("SJZS", SJZS.getText());
			if(KJS!=null)
			jsob.put("KJS", KJS.getText());
			if(YJZS!=null)
			jsob.put("YJZS", YJZS.getText());
			if(CYJS!=null)
			jsob.put("CYJS", CYJS.getText());
			if(RCY!=null)
			jsob.put("RCY", RCY.getText());
			if(RCQ!=null)
			jsob.put("RCQ", RCQ.getText());
			if(BZRZY!=null)
			jsob.put("BZRZY", BZRZY.getText());
			if(YCY!=null)
			jsob.put("YCY", YCY.getText());
			if(YCQ!=null)
			jsob.put("YCQ", YCQ.getText());
			if(DJYCY!=null)
			jsob.put("DJYCY", DJYCY.getText());
			if(XJJS!=null)
			jsob.put("XJJS", XJJS.getText());
			if(XJRCY!=null)
			jsob.put("XJRCY", XJRCY.getText());
			if(XJYCY!=null)
			jsob.put("XJYCY", XJYCY.getText());
			if(DBJJS!=null)
			jsob.put("DBJJS", DBJJS.getText());
			if(DBJRCY!=null)
			jsob.put("DBJRCY", DBJRCY.getText());
			if(DBJYCY!=null)
			jsob.put("DBJYCY", DBJYCY.getText());
			if(CSJJS!=null)
			jsob.put("CSJJS", CSJJS.getText());
			if(CSJRCY!=null)
			jsob.put("CSJRCY", CSJRCY.getText());
			if(CSJYCY!=null)
			jsob.put("CSJYCY", CSJYCY.getText());
			if(BZRZQ!=null)
			jsob.put("BZRZQ", BZRZQ.getText());
			if(SCSJ!=null)
			jsob.put("SCSJ", SCSJ.getText());
			if(RCY1!=null)
			jsob.put("RCY1", RCY1.getText());
			if(BZRZY1!=null)
			jsob.put("BZRZY1", BZRZY1.getText());
			jsoa.add(jsob);
		}
		System.out.println("1"+jsoa.toJSONString());
		JSONObject jsonResult = new JSONObject();
		jsonResult.put("data", jsoa);
		return jsonResult;
	}
	
	
	
	
	public static  JSONObject zxtDate(JSONObject params, ActionContext context) throws UnsupportedEncodingException{
		InputStream iStream = null;
		String result = "";
		Document doc = null;
		JSONArray jsoa = new JSONArray();
		int i =1;
		String date = params.getString("date");
		try {
			URL url = new URL("http://10.76.19.159/CommonServices/CommonService.asmx/GetDataBySql?strUserName=fengqi172@163.com&" +
					"strPassword=1qaz2wsx&modename=PCDM97&systemName=%E7%A7%BB%E5%8A%A8%E5%BA%94%E7%94%A8%E5%B9%B3%E5%8F%B0&" +
					"subSystemUser=%E5%A4%8F%E9%91%AB&" +
					"sql=select%20*%20from%20dbaa14%20where%20TO_CHAR(RQ,%27YYYY-MM%27)=%27"+date+"%27%20and%20(DWDM%20=%20%270%27)");
			URLConnection connection = url.openConnection();
			iStream = connection.getInputStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(iStream, "utf-8"));
			StringBuffer sb = new StringBuffer();
			String line = null;
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
			iStream.close();
			result = sb.toString();
			System.out.println(result);
		} catch (Exception e) {
			e.printStackTrace();
		}
		InputStream stream2 = new ByteArrayInputStream(result.getBytes("UTF-8"));

		SAXReader saxReader = new SAXReader();
		saxReader.setEncoding("UTF-8");
		try {
			doc = (Document) saxReader.read(new InputSource(stream2));
		} catch (DocumentException e1) {
			e1.printStackTrace();
		}
		List<Element> lists = doc.selectNodes("//DocumentElement//data");
		for (Element adds : lists) {
			JSONObject jsob = new JSONObject();
			List<Element> datainfos = adds.elements();
			Node RQ = adds.element("RQ");
			Node DWDM = adds.element("DWDM");
			Node TJLB = adds.element("TJLB");
			Node SJZS = adds.element("SJZS");
			Node KJS = adds.element("KJS");
			Node YJZS = adds.element("YJZS");
			Node CYJS = adds.element("CYJS");
			Node RCY = adds.element("RCY");
			Node RCQ = adds.element("RCQ");
			Node BZRZY = adds.element("BZRZY");
			Node YCY = adds.element("YCY");
			Node YCQ = adds.element("YCQ");
			Node DJYCY = adds.element("DJYCY");
			Node XJJS = adds.element("XJJS");
			Node XJRCY = adds.element("XJRCY");
			Node XJYCY = adds.element("XJYCY");
			Node DBJJS = adds.element("DBJJS");
			Node DBJRCY = adds.element("DBJRCY");
			Node DBJYCY = adds.element("DBJYCY");
			Node CSJJS = adds.element("CSJJS");
			Node CSJRCY = adds.element("CSJRCY");
			Node CSJYCY = adds.element("CSJYCY");
			Node BZRZQ = adds.element("BZRZQ");
			Node SCSJ = adds.element("SCSJ");
			Node RCY1 = adds.element("RCY1");
			Node BZRZY1 = adds.element("BZRZY1");
			if(DWDM!=null)
			jsob.put("DWDM", DWDM.getText());
			if(RQ!=null)
			jsob.put("RQ", RQ.getText());
			if(TJLB!=null)
			jsob.put("TJLB", TJLB.getText());
			if(SJZS!=null)
			jsob.put("SJZS", SJZS.getText());
			if(KJS!=null)
			jsob.put("KJS", KJS.getText());
			if(YJZS!=null)
			jsob.put("YJZS", YJZS.getText());
			if(CYJS!=null)
			jsob.put("CYJS", CYJS.getText());
			if(RCY!=null)
			jsob.put("RCY", RCY.getText());
			if(RCQ!=null)
			jsob.put("RCQ", RCQ.getText());
			if(BZRZY!=null)
			jsob.put("BZRZY", BZRZY.getText());
			if(YCY!=null)
			jsob.put("YCY", YCY.getText());
			if(YCQ!=null)
			jsob.put("YCQ", YCQ.getText());
			if(DJYCY!=null)
			jsob.put("DJYCY", DJYCY.getText());
			if(XJJS!=null)
			jsob.put("XJJS", XJJS.getText());
			if(XJRCY!=null)
			jsob.put("XJRCY", XJRCY.getText());
			if(XJYCY!=null)
			jsob.put("XJYCY", XJYCY.getText());
			if(DBJJS!=null)
			jsob.put("DBJJS", DBJJS.getText());
			if(DBJRCY!=null)
			jsob.put("DBJRCY", DBJRCY.getText());
			if(DBJYCY!=null)
			jsob.put("DBJYCY", DBJYCY.getText());
			if(CSJJS!=null)
			jsob.put("CSJJS", CSJJS.getText());
			if(CSJRCY!=null)
			jsob.put("CSJRCY", CSJRCY.getText());
			if(CSJYCY!=null)
			jsob.put("CSJYCY", CSJYCY.getText());
			if(BZRZQ!=null)
			jsob.put("BZRZQ", BZRZQ.getText());
			if(SCSJ!=null)
			jsob.put("SCSJ", SCSJ.getText());
			if(RCY1!=null)
			jsob.put("RCY1", RCY1.getText());
			if(BZRZY1!=null)
			jsob.put("BZRZY1", BZRZY1.getText());
			jsob.put("No", i);
			i=i+1;
			jsoa.add(jsob);
		}
		System.out.println("1"+jsoa.toJSONString());
		JSONObject jsonResult = new JSONObject();
		jsonResult.put("data", jsoa);
		return jsonResult;
	}
	
	
}
