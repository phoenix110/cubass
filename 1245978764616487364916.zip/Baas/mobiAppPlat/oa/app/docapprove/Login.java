package mobiAppPlat.oa.app.docapprove;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import mobiAppPlat.oa.app.docapprove.bean.ActionResult;
import mobiAppPlat.oa.app.docapprove.bean.NetServer;
import mobiAppPlat.oa.app.docapprove.bean.ReqObj;
import mobiAppPlat.oa.app.docapprove.bean.RespObj;
import mobiAppPlat.oa.app.docapprove.service.LoginPageDoLoginCallback;
import mobiAppPlat.oa.app.docapprove.service.LoginPageGetIndexCallback;
import mobiAppPlat.oa.app.docapprove.service.LoginPageGetLoginCallBack;
import mobiAppPlat.oa.app.docapprove.utils.CookiesUtils;
import mobiAppPlat.oa.app.docapprove.utils.Utils;

import com.alibaba.fastjson.JSONObject;
import com.justep.baas.action.ActionContext;



public class Login {
	
	private static final String LOGIN_URL =Utils.getOaUrl("loginUrl");
	private static final String COOKIE_ID = CookiesUtils.getCookiesID();
	
	//测试账号，登陆功能做好后，改为从缓存中获取数据。
	private static String USERNAME = "";
	private static String PASSWORD = "";
	
	
	public static JSONObject loginForCookie(JSONObject params, ActionContext context){
		boolean flag = true;
		String msg = null;
		try{
			USERNAME = params.getString("username");
			PASSWORD =params.getString("password");
			if (StringUtils.isEmpty(USERNAME) || StringUtils.isEmpty(PASSWORD)) {
				throw new RuntimeException("用户名或密码为空，请重新登录");
			}
			
			ActionResult ar = login(USERNAME, PASSWORD);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
			}
		}catch(Exception e){
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		return result;
	}
	
	public static ActionResult login(String username,String password){
		ActionResult ar = new ActionResult(true, "");
		try{
			Map<String, String> cookies = new HashMap<String, String>();
			RespObj getLoginPageResult = getLoginPage();
			cookies.putAll(getLoginPageResult.getCookies());

			RespObj loginResult = doLogin(username, password, cookies, (Map<String, String>)getLoginPageResult.getResponseBody());
			System.out.println("登陆成功，登陆人："+USERNAME);
			cookies.putAll(loginResult.getCookies());
			
			RespObj indexResult = getIndexPage(cookies);
			
			cookies.putAll(indexResult.getCookies());
			
			Map<String, String> data = (Map<String, String>)indexResult.getResponseBody();
			
			if (!"true".equals(data.get("flag"))){
				ar.setFlag(false);
				ar.setData( data.get("msg")) ;
			}else{
				ar.addCookies(cookies);
			}

		}catch(Exception e){
			e.printStackTrace();
			ar.setFlag(false);
			ar.setData(e.getMessage()) ;
			
		}
		return ar;
	}
	
	private static RespObj getLoginPage(){
		ReqObj req = new ReqObj();
		req.addHeader("Accept", "Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		//req.addHeader("Accept-Encoding", "gzip, deflate, sdch"); //不压缩
		req.addHeader("Accept-Language", "zh-CN,zh;q=0.8");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		req.addHeader("Host", "oatraining.petrochina");
		req.addHeader("Pragma", "no-cache");
		req.addHeader("Upgrade-Insecure-Requests", "1");
		req.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.4 Safari/537.36");
		req.setMethod("get");
		req.setUrl(LOGIN_URL);
		RespObj result = NetServer.service(req, new LoginPageGetLoginCallBack());
		return result;
	}
	
	private static RespObj getIndexPage(Map<String, String> cookies){
		ReqObj req = new ReqObj();
		req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept", "Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		//req.addHeader("Accept-Encoding", "gzip, deflate, sdch"); //不压缩
		req.addHeader("Accept-Language", "zh-CN,zh;q=0.8");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		req.addHeader("Host", "oatraining.petrochina");
		req.addHeader("Pragma", "no-cache");
		req.addHeader("Upgrade-Insecure-Requests", "1");
		req.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.4 Safari/537.36");
		req.setMethod("get");
		req.setUrl("http://oa.petrochina/task%20portal/index.aspx");
		RespObj result = NetServer.service(req, new LoginPageGetIndexCallback());
		return result;
	}
	private static RespObj doLogin(String username, String password, Map<String, String> cookies, Map<String, String> params){
		ReqObj req = new ReqObj();
		req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		req.addHeader("Accept-Encoding", "gzip, deflate");
		req.addHeader("Accept-Language", "zh-CN,zh;q=0.8");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		req.addHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
		req.addHeader("Host", "oatraining.petrochina");
		req.addHeader("Origin", "http://oatraining.petrochina");
		req.addHeader("Pragma", "no-cache");
		req.addHeader("Upgrade-Insecure-Requests", "1");
		req.addHeader("Referer", LOGIN_URL);
		req.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.4 Safari/537.36");
		req.setMethod("post");
		req.setUrl(LOGIN_URL);
		if (params != null){
			req.getParams().putAll(params);
		}
		req.addParam("txtLogin",    username);
		req.addParam("txtPassword", password);
		
		RespObj result = NetServer.service(req, new LoginPageDoLoginCallback());
		return result;
	}

}
