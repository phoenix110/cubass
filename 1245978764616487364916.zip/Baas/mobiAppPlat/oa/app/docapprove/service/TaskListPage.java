package mobiAppPlat.oa.app.docapprove.service;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import mobiAppPlat.oa.app.docapprove.bean.ActionResult;
import mobiAppPlat.oa.app.docapprove.bean.NetServer;
import mobiAppPlat.oa.app.docapprove.bean.ReqObj;
import mobiAppPlat.oa.app.docapprove.bean.RespObj;
import mobiAppPlat.oa.app.docapprove.utils.Utils;


public class TaskListPage {
	public static ActionResult load(Map<String, String> cookies,Integer offset,String listType,HttpServletRequest request){
		String taskList = Utils.getOaUrl("TaskList");
		ActionResult ar = new ActionResult(true, "");
		String method="get";
		if(offset>0){
			method="post";
		}
		ReqObj req = new ReqObj();
		req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept", "Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		//req.addHeader("Accept-Encoding", "gzip, deflate, sdch"); //不压缩
		req.addHeader("Accept-Language", "zh-CN,zh;q=0.8");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		req.addHeader("Host", "oatraining.petrochina");
		req.addHeader("Pragma", "no-cache");
		req.addHeader("Upgrade-Insecure-Requests", "1");
		req.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.4 Safari/537.36");
		req.setMethod(method);
		req.addParam("taskCboPageIndex", (offset/10+1)+"");
		System.out.println("taskCboPageIndex:"+(offset/10+1));
		req.addParam("taskDoneSendCboPageIndex", "1");
		req.addParam("taskDoneReceiveCboPageIndex", "1");
		req.addParam("__EVENTTARGET", "taskCboPageIndex");
		req.addParam("__EVENTARGUMENT", "");
		req.addParam("__LASTFOCUS", "");
		req.addParam("__VIEWSTATE", String.valueOf(request.getSession().getAttribute("__VIEWSTATE")));
		req.addParam("__VIEWSTATEGENERATOR", "A8063AC5");
		req.addParam("__EVENTVALIDATION", String.valueOf(request.getSession().getAttribute("__EVENTVALIDATION")));
		req.setUrl(taskList);
		RespObj tasks = NetServer.service(req, new TaskListPageCallback(listType));
		/*
		RespObj tasks = NetServer.service(req, new TaskListPageCallback());
		RespObj tasksTotal = NetServer.service(req, new TaskTotalCallback());
		*/
		ar.addCookies(tasks.getCookies());
		ar.setData(tasks.getResponseBody());
		//ar.setTotal(Integer.parseInt(tasksTotal.getResponseBody().toString()));
		return ar;
	}
	public static ActionResult loadDealed(Map<String, String> cookies,Integer offset,String listType,HttpServletRequest request){
		String taskList = Utils.getOaUrl("TaskList")+"?reset=true";
		ActionResult ar = new ActionResult(true, "");
		ReqObj req = new ReqObj();
		String method="get";
		if(offset>0){
			method="post";
			req.addParam("taskDoneReceiveCboPageIndex", (offset/5+1)+"");
			System.out.println("taskDoneReceiveCboPageIndex:"+(offset/5+1));
			req.addParam("taskDoneSendCboPageIndex", "1");
			//req.addParam("taskDoneReceiveCboPageIndex", "1");
			req.addParam("__EVENTTARGET", "taskDoneReceiveNextPage");
			req.addParam("__EVENTARGUMENT", "");
			req.addParam("__LASTFOCUS", "");
			req.addParam("__VIEWSTATE", String.valueOf(request.getSession().getAttribute("__VIEWSTATE")));
			req.addParam("__VIEWSTATEGENERATOR", "A8063AC5");
			req.addParam("__EVENTVALIDATION", String.valueOf(request.getSession().getAttribute("__EVENTVALIDATION")));
		
		}
		req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept", "Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		//req.addHeader("Accept-Encoding", "gzip, deflate, sdch"); //不压缩
		req.addHeader("Accept-Language", "zh-CN,zh;q=0.8");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		req.addHeader("Host", "oatraining.petrochina");
		req.addHeader("Pragma", "no-cache");
		req.addHeader("Upgrade-Insecure-Requests", "1");
		req.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.4 Safari/537.36");
		req.setMethod(method);
			req.setUrl(taskList);
		RespObj tasks = NetServer.service(req, new TaskListPageCallback(listType));
		/*
		RespObj tasks = NetServer.service(req, new TaskListPageCallback());
		RespObj tasksTotal = NetServer.service(req, new TaskTotalCallback());
		*/
		ar.addCookies(tasks.getCookies());
		ar.setData(tasks.getResponseBody());
		//ar.setTotal(Integer.parseInt(tasksTotal.getResponseBody().toString()));
		return ar;
		
	}
	public static ActionResult loadCirculate(Map<String, String> cookies, Integer offset,String taskUrl) {
		ActionResult ar = new ActionResult(true, "");
		ReqObj req = new ReqObj();
		String url = Utils.getDomainName()+taskUrl;
		req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept", "Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		req.addHeader("Accept-Encoding", "gzip, deflate"); //不压缩
		req.addHeader("Accept-Language", "zh-CN,zh;q=0.8");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		req.addHeader("Host", "oatraining.petrochina");
		req.addHeader("Pragma", "no-cache");
		req.addHeader("Upgrade-Insecure-Requests", "1");
		req.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.4 Safari/537.36");
		req.setMethod("get");
				req.setUrl(url);
		RespObj tasks = NetServer.service(req, new CirculateListPageCallback());
	    //RespObj tasksTotal = NetServer.service(req, new TaskTotalCallback());
		ar.addCookies(tasks.getCookies());
		ar.setData(tasks.getResponseBody());
		//ar.setTotal(Integer.parseInt(tasksTotal.getResponseBody().toString()));
		return ar;
	}
}
