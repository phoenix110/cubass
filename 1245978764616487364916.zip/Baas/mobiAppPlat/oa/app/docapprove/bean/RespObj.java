package mobiAppPlat.oa.app.docapprove.bean;

import java.util.HashMap;
import java.util.Map;

public class RespObj {
	private Object responseBody = new HashMap<String, String>();
	private Map<String, String> cookies = new HashMap<String, String>();

	public Object getResponseBody() {
		return responseBody;
	}

	public void setResponseBody(Object responseBody) {
		this.responseBody = responseBody;
	}

	public Map<String, String> getCookies() {
		return cookies;
	}

	public void addCookie(String name, String value){
		cookies.put(name, value);
	}
}
