package mobiAppPlat.oa.app.docapprove.service;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import mobiAppPlat.oa.app.docapprove.bean.HtmlParser;
import mobiAppPlat.oa.app.docapprove.bean.RespCallback;
import mobiAppPlat.oa.app.docapprove.service.LoginPageDoLoginCallback;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;




public class LoginPageDoLoginCallback implements RespCallback {

	public static void main(String[] args){
		InputStream in = HtmlParser.class.getResourceAsStream("/com/justep/net/pages/doLogin_error.txt");
		RespCallback cb = new LoginPageDoLoginCallback();
		Map<String, String> result = (Map<String, String>)cb.execute(in);
	}


	
	public Object execute(InputStream body) {
		Document doc = HtmlParser.parser(body, null);
		String flag = "true";
		String msg = "";
		
		for (Element e : doc.getElementsByTag("a")){
			String href = e.attr("href");
			if (href.endsWith("index.aspx")){
				flag = "true";
			}else{
				flag = "false";
				msg = "未知错误";
			}
			break;
		}
		
		Map<String, String> result = new HashMap<String, String>();
		result.put("flag", flag);
		result.put("msg", msg);
		return result;
	}

}
