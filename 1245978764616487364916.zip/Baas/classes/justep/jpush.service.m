<?xml version="1.0" encoding="UTF-8"?>
<model>
	<action xmlns="http://www.w3.org/1999/xhtml" name="push"
		impl="justep.Push.push">
		<public name="registrationId" type="String"></public>
	</action>
</model>