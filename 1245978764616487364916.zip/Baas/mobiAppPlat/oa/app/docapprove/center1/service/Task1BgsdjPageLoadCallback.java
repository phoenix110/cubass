package mobiAppPlat.oa.app.docapprove.center1.service;

import java.io.InputStream;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import mobiAppPlat.oa.app.docapprove.bean.HtmlParser;
import mobiAppPlat.oa.app.docapprove.bean.RespCallback;
import mobiAppPlat.oa.app.docapprove.service.CheckUserOnline;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.justep.baas.data.ColumnValue;
import com.justep.baas.data.DataType;
import com.justep.baas.data.Row;
import com.justep.baas.data.RowState;
import com.justep.baas.data.Table;
import com.justep.baas.data.Transform;

public class Task1BgsdjPageLoadCallback implements RespCallback{
	private static final String[] NAMES = new String[]{
		"__VIEWSTATE",
		"__VIEWSTATEGENERATOR",
		"__EVENTVALIDATION",
		"ctl00$forward_0",
		"ctl00$forward_1",
		"ctl00$forward_2",
		"ctl00$txtforward_0",
		"ctl00$txtforward_1",
		"ctl00$txtforward_2",
		"ctl00$finish_0",
		"ctl00$txtfinish_0",
		"ctl00$txtdistributecompany_0",
		"ctl00$save_0",
		"ctl00$stop_0",
		"ctl00$txtsave_0",
		"ctl00$txtstop_0",
		"ctl00$txtprint_0",
		"Register_00_Current_Ctrl$WordMarkNo",
		"Register_00_Current_Ctrl$DraftUnit",
		"Register_00_Current_Ctrl$RegisterDisplayName",
		"Register_00_Current_Ctrl$RegisterPhoneNo",
		"Register_00_Current_Ctrl$ReceiveDate",
		"Register_00_Current_Ctrl$SourceType",
		"Register_00_Current_Ctrl$SecretLevel",
		"Register_00_Current_Ctrl$SecretLimit",
		"Register_00_Current_Ctrl$UrgentLevel",
		"Register_00_Current_Ctrl$CarrierType",
		"Register_00_Current_Ctrl$ReceiveFileNo",
		"Register_00_Current_Ctrl$CreateDate",
		"Register_00_Current_Ctrl$Amount",
		"Register_00_Current_Ctrl$ReceiveType",
		"Register_00_Current_Ctrl$FileTitle",
		"Register_00_Current_Ctrl$Topic",
		"Register_00_Current_Ctrl$GiveMainUnit",
		"Register_00_Current_Ctrl$GiveCopyUnit",
		"Register_00_Current_Ctrl$Archive",
		"Register_00_Current_Ctrl$TimeLimit",
		"Register_00_Current_Ctrl$Issue",
		"Register_00_Current_Ctrl$ChannelDirectory",
		"Register_00_Current_Ctrl$RegisterDeptID",
		"Register_00_Current_Ctrl$RegisterDept",
		"Register_00_Current_Ctrl$Register",
		"Register_00_Current_Ctrl$GiveMainUnitID",
		"Register_00_Current_Ctrl$GiveCopyUnitID",
		"Register_00_Current_Ctrl$ReceiveTime",
		"Register_00_Current_Ctrl$CreateTime",
		"Register_00_Current_Ctrl$DocID",
		"Register_00_Current_Ctrl$DocWebService",
		"Register_00_Current_Ctrl$Accessory",
		"Register_00_Current_Ctrl$HeadTemplate",
		"Register_00_Current_Ctrl$DrafterIncID",
		"Register_00_Current_Ctrl$DrafterIncName",
		"Register_00_Current_Ctrl$DrafterDeptID",
		"Register_00_Current_Ctrl$DrafterDeptName",
		"Register_00_Current_Ctrl$ReceiveRemark"
	};
	
	
	public Object execute(InputStream body) {
		Document doc = HtmlParser.parser(body, null);
		
		CheckUserOnline.checkOnline(doc);
//		System.out.println("detail:"+doc.html());
		Map<String, Object> result = new HashMap<String, Object>();
		Map<String, String> pageState = new HashMap<String, String>();
		result.put("pageState", pageState);
		for (String name : NAMES){
			Elements es = doc.getElementsByAttributeValue("name", name);
			if (es.size()>=1){
				String value = "";
				Element e = es.get(0);
				if (e.tagName().equals("textarea")){
					value = e.text();
				}else{
					value = es.get(0).attr("value");
				}
				
				pageState.put(name, value);
			}
		}
		
		Map<String, String> task = new HashMap<String, String>();
		for (String column : NAMES){
			task.put(column, pageState.get(column));	
		}
		//定义返回附件数据的table对象
		Map<String, DataType> columns = new LinkedHashMap<String, DataType>();
		columns.put("id", DataType.STRING);
		columns.put("name", DataType.STRING);
		columns.put("docName", DataType.STRING);
		Table table = new Table(columns);
		
		//获取附件数据
		Element attachmentTable = doc.getElementById("Register_00_Current_Ctrl_FileTableCtrl_dgFile");
		if (null != attachmentTable) {
			Elements attachmentTrs = attachmentTable.children().get(0).children();
			for (Element attachmentTr : attachmentTrs) {
				Element attachmentA = attachmentTr.getElementsByTag("a").get(0);
				
				Map<String, ColumnValue> column = new HashMap<String, ColumnValue>();
				column.put("name", new ColumnValue(attachmentA.html()));
				column.put("id", new ColumnValue(attachmentA.attr("onclick").split("=")[1].split("'")[0]));
				column.put("docName", new ColumnValue(attachmentA.attr("title")));
				Row row = new Row(column, RowState.NEW);
				table.appendRow(row);
			}
		}
		result.put("attachment", Transform.tableToJson(table));
		
		//获取审批记录数据 
		JSONArray history = new JSONArray();
		
		Elements elements = doc.getElementsByAttributeValueMatching("id", "^ctl.*_barTD$");
		if (elements.size()>0) {
			for (int i = 0; i < elements.size(); i++) {
				Element element = elements.get(i);
				
				Elements element_spans = element.getElementsByTag("span");
				String title = "";
				for(Element element_span : element_spans){
					if (element_span.getElementsByTag("span").size()==1) {
						title = element_span.html();
					}
				}
				
				if (!"办公室拟办".equals(title) && !"中心领导批示".equals(title)) {
					 continue;
				}
				//定义子历史记录对象
				JSONObject childHistory = new JSONObject();
				history.add(childHistory);
				//定义子历史记录的数据列表
				JSONArray childHistoryDataList = new JSONArray();
				
				childHistory.put("title", title);
				childHistory.put("data", childHistoryDataList);
				
				Element elementTable_parent = element.parent().parent().parent();
				Elements elementTables = elementTable_parent.getElementsByTag("table");
				for (Element elementTable : elementTables) {
					if (elementTable.getElementsByTag("table").size() == 1) {
						JSONObject jsob = new JSONObject();
						String DisplayName = elementTable.getElementsByAttributeValueMatching("id","DisplayName$").get(0).html();
						String DeptName = elementTable.getElementsByAttributeValueMatching("id","DeptName$").get(0).html();
						String Time = elementTable.getElementsByAttributeValueMatching("id","Time$").get(0).html();
						String Idea = elementTable.getElementsByAttributeValueMatching("id","Idea$").get(0).html();
						
						jsob.put("审核人", DisplayName);
						jsob.put("部门", DeptName);
						jsob.put("时间", Time);
						jsob.put("意见", Idea);
						
						childHistoryDataList.add(jsob);
					}
					
				}
				
			}
		}
		
		result.put("history", history);
		result.put("task", task);
		return result;
	}

}
