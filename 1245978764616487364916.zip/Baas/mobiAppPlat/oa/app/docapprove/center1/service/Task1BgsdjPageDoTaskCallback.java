package mobiAppPlat.oa.app.docapprove.center1.service;

import java.io.InputStream;

import mobiAppPlat.oa.app.docapprove.service.CheckUserOnline;
import mobiAppPlat.oa.app.docapprove.bean.HtmlParser;
import mobiAppPlat.oa.app.docapprove.bean.RespCallback;

import org.jsoup.nodes.Document;

public class Task1BgsdjPageDoTaskCallback implements RespCallback {

	public Object execute(InputStream body) {
		Document doc = HtmlParser.parser(body, null);
//		System.out.println("detail:"+doc.html());
		CheckUserOnline.checkOnline(doc);

		return null;
	}

}