package mobiAppPlat.oa.app.docapprove.bean;

import java.io.InputStream;

public interface RespCallback {
	public Object execute(InputStream body);
}
