package mobiAppPlat.oa.app.docapprove;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.xml.namespace.QName;
import javax.xml.rpc.ParameterMode;

import mobiAppPlat.oa.app.docapprove.bean.ActionResult;
import mobiAppPlat.oa.app.docapprove.bean.NetServer;
import mobiAppPlat.oa.app.docapprove.bean.ReqObj;
import mobiAppPlat.oa.app.docapprove.bean.RespObj;
import mobiAppPlat.oa.app.docapprove.service.LoginPageDoLoginCallback;
import mobiAppPlat.oa.app.docapprove.service.LoginPageGetIndexCallback;
import mobiAppPlat.oa.app.docapprove.service.LoginPageGetLoginCallBack;
import mobiAppPlat.oa.app.docapprove.service.RequstDocCallBack;
import mobiAppPlat.oa.app.docapprove.utils.Utils;

import org.apache.axis.client.Call;
import org.apache.axis.client.Service;
import org.apache.axis.encoding.XMLType;
import org.apache.commons.lang.StringUtils;

import com.alibaba.fastjson.JSONObject;
import com.justep.baas.action.ActionContext;

public class Download {


	// 打开正文
	public static JSONObject openDoc(JSONObject params, ActionContext context) throws Exception {
		HttpServletResponse response = (HttpServletResponse) context.get(ActionContext.RESPONSE);
		String docid = params.getString("docID");

		String serviceUrl = Utils.getOaUrl("openDoc");
		Service service = new Service();
		Call call = (Call) service.createCall();// 通过service创建call对象

		call.setTargetEndpointAddress(new java.net.URL(serviceUrl));

		call.addParameter(new QName("http://tempuri.org/", "docID"), XMLType.XSD_STRING, ParameterMode.IN);

		call.setReturnType(XMLType.XSD_STRING); // 返回参数的类型
		call.setUseSOAPAction(true);
		call.setOperationName(new QName("http://tempuri.org/", "GetBlackDocData"));
		call.setSOAPActionURI("http://tempuri.org/GetBlackDocData");

		// 就是要加上要调用的方法Add,不然也会报错
		// Object 数组封装了参数，参数为"This is Test!",调用processService(String arg)
		String ret = (String) call.invoke(new Object[] { docid });
		System.out.println("-" + ret);
		byte[] bt = null;
		sun.misc.BASE64Decoder decoder = new sun.misc.BASE64Decoder();
		bt = decoder.decodeBuffer(ret);

		response.addHeader("Content-Disposition", "attachment; filename=\"" + docid + "\"");

		response.getOutputStream().write(bt);
		return null;
	}

	public static void main(String[] args) throws IOException {
		downloadDoc(null, null);
	}

	// 下载附件
	public static JSONObject downloadDoc(JSONObject params, ActionContext context) throws IOException {
		HttpServletResponse response = (HttpServletResponse) context.get(ActionContext.RESPONSE);
		final String requstDocUrl = Utils.getOaUrl("requstDocUrl") + "?FileID=" + params.getString("id");
		params.put("loginName", "ptr\\laijs");
		params.put("password","1qaz2wsx");
		JSONObject jsonObj = loginForCookie(params, context);
		final Map<String, String> COOKIES = (Map<String, String>) jsonObj.get("cookies");
		URL url;
		try {
			url = new URL(requstDocUrl);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.addRequestProperty("Cookie", Utils.map2String(COOKIES));
			conn.addRequestProperty("Accept", "*/*");
			conn.addRequestProperty("Accept-Encoding", "gzip, deflate");
			conn.addRequestProperty("Accept-Language", "zh-CN");
			conn.addRequestProperty("Connection", "keep-alive");
			conn.addRequestProperty("Host", "oa.petrochina");
			conn.addRequestProperty(
					"User-Agent",
					"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/4.0; chromeframe/30.0.1599.69; EmbeddedWB 14.52 from: http://www.bsalsa.com/ EmbeddedWB 14.52; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET CLR 1.1.4322; InfoPath.2; .NET4.0C; .NET4.0E)");
			InputStream input = conn.getInputStream();
			response.addHeader("Content-Disposition", "attachment; filename=\"" + URLEncoder.encode(params.getString("name"), "utf-8") + "\"");
			OutputStream fout = response.getOutputStream();
			int buf = 0;
			while ((buf = input.read()) != -1) {
				fout.write(buf);
			}
			fout.close();
			input.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}


	public static JSONObject loginForCookie(JSONObject params, ActionContext context) {
		boolean flag = true;
		String msg = null;
		ActionResult ar = null;
		try {
			String USERNAME = params.getString("loginName"); // (String)request.getAttribute("loginName");
			String PASSWORD = params.getString("password");
			if (StringUtils.isEmpty(USERNAME) || StringUtils.isEmpty(PASSWORD)) {
				throw new RuntimeException("用户名或密码为空，请重新登录");
			}
			ar = login(USERNAME, PASSWORD);
			if (!ar.isFlag()) {
				flag = false;
				msg = ar.getData() + "";
			} else {
				// CookiesUtils.updateCookies(context,
				// ar.getCookies(),COOKIE_ID);
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		result.put("cookies", ar.getCookies());
		return result;
	}

	public static ActionResult login(String username, String password) {
		ActionResult ar = new ActionResult(true, "");
		try {
			Map<String, String> cookies = new HashMap<String, String>();
			RespObj getLoginPageResult = getLoginPage();
			cookies.putAll(getLoginPageResult.getCookies());

			RespObj loginResult = doLogin(username, password, cookies, (Map<String, String>) getLoginPageResult.getResponseBody());
			// System.out.println("登陆成功，登陆人："+USERNAME);
			cookies.putAll(loginResult.getCookies());
			RespObj indexResult = getIndexPage(cookies);
			cookies.putAll(indexResult.getCookies());
			// ActionResult arNew = getTasksList(cookies);
			// cookies.putAll(arNew.getCookies());

			Map<String, String> data = (Map<String, String>) indexResult.getResponseBody();

			if (!"true".equals(data.get("flag"))) {
				ar.setFlag(false);
				ar.setData(data.get("msg"));
			} else {
				ar.addCookies(cookies);
			}

		} catch (Exception e) {
			e.printStackTrace();
			ar.setFlag(false);
			ar.setData(e.getMessage());

		}
		return ar;
	}

	private static RespObj doLogin(String username, String password, Map<String, String> cookies, Map<String, String> params) {
		ReqObj req = new ReqObj();
		req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		req.addHeader("Accept-Encoding", "gzip, deflate");
		req.addHeader("Accept-Language", "zh-CN,zh;q=0.8");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		req.addHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
		req.addHeader("Host", "oa.petrochina");
		req.addHeader("Origin", "http://oa.petrochina");
		req.addHeader("Pragma", "no-cache");
		req.addHeader("Upgrade-Insecure-Requests", "1");
		req.addHeader("Referer", "http://oa.petrochina/Task%20Portal/Login.aspx?ReturnUrl=%2ftask+portal%2findex.aspx");
		req.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.4 Safari/537.36");
		req.setMethod("post");
		req.setUrl("http://oa.petrochina/Task%20Portal/Login.aspx?ReturnUrl=%2ftask+portal%2findex.aspx");
		if (params != null) {
			req.getParams().putAll(params);
		}
		req.addParam("txtLogin", username);
		req.addParam("txtPassword", password);

		RespObj result = NetServer.service(req, new LoginPageDoLoginCallback());
		return result;
	}

	private static RespObj getIndexPage(Map<String, String> cookies) {
		ReqObj req = new ReqObj();
		req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept", "Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		// req.addHeader("Accept-Encoding", "gzip, deflate, sdch"); //不压缩
		req.addHeader("Accept-Language", "zh-CN,zh;q=0.8");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		req.addHeader("Host", "oatraining.petrochina");
		req.addHeader("Pragma", "no-cache");
		req.addHeader("Upgrade-Insecure-Requests", "1");
		req.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.4 Safari/537.36");
		req.setMethod("get");
		req.setUrl("http://oa.petrochina/task%20portal/index.aspx");
		RespObj result = NetServer.service(req, new LoginPageGetIndexCallback());
		return result;
	}

	private static RespObj getLoginPage() {
		ReqObj req = new ReqObj();
		req.addHeader("Accept", "Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		// req.addHeader("Accept-Encoding", "gzip, deflate, sdch"); //不压缩
		req.addHeader("Accept-Language", "zh-CN,zh;q=0.8");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		req.addHeader("Host", "oatraining.petrochina");
		req.addHeader("Pragma", "no-cache");
		req.addHeader("Upgrade-Insecure-Requests", "1");
		req.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.4 Safari/537.36");
		req.setMethod("get");
		req.setUrl("http://oa.petrochina/Task%20Portal/Login.aspx?ReturnUrl=%2ftask+portal%2findex.aspx");
		RespObj result = NetServer.service(req, new LoginPageGetLoginCallBack());
		return result;
	}

}
