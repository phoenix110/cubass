package mobiAppPlat.oa.app.contractapprove;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import mobiAppPlat.oa.app.contractapprove.beans.Contract;
import mobiAppPlat.oa.system.OASystemInit;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class PageUtils {

	// 获取合同信息
	public static void getContractInfo(Document doc, Contract contract) {
		System.out.println("%%%%%%%%%%");
		Map<String, String> valueMap = new HashMap<String, String>();
		// 合同申报
		valueMap.put("lblDeclareCode", doc.getElementById("lblDeclareCode").html() == null ? "" : doc.getElementById("lblDeclareCode").html());
		valueMap.put("lblLocalCode", doc.getElementById("lblLocalCode").html() == null ? "" : doc.getElementById("lblLocalCode").html());
		valueMap.put("lblContractName", doc.getElementById("lblContractName").html() == null ? "" : doc.getElementById("lblContractName").html());
		valueMap.put("lblContractType", doc.getElementById("lblContractType").html() == null ? "" : doc.getElementById("lblContractType").html());
		valueMap.put("lblFundAllocation", doc.getElementById("lblFundAllocation").html());
		valueMap.put("lblFundDitch", doc.getElementById("lblFundDitch").html() == null ? "" : doc.getElementById("lblFundDitch").html());
		valueMap.put("lblFrame", doc.getElementById("lblFrame").html() == null ? "" : doc.getElementById("lblFrame").html());
		valueMap.put("lblIsUnderFramework", doc.getElementById("lblIsUnderFramework").html() == null ? "" : doc.getElementById("lblIsUnderFramework").html());
		valueMap.put("lblSelectBusiness", doc.getElementById("lblSelectBusiness").html() == null ? "" : doc.getElementById("lblSelectBusiness").html());
		valueMap.put("lblBudgetSum", doc.getElementById("lblBudgetSum").html() == null ? "" : doc.getElementById("lblBudgetSum").html());

		// 标的
		valueMap.put("lblContractMark", doc.getElementById("lblContractMark") == null ? "" : doc.getElementById("lblContractMark").html());
		valueMap.put("lblMarkMoney", doc.getElementById("lblMarkMoney").html() == null ? "" : doc.getElementById("lblMarkMoney").html());
		valueMap.put("lblCurrencyType", doc.getElementById("lblCurrencyType").html() == null ? "" : doc.getElementById("lblCurrencyType").html());
		valueMap.put("lblContractType", doc.getElementById("lblContractType").html() == null ? "" : doc.getElementById("lblContractType").html());
		valueMap.put("lblStartDate", doc.getElementById("lblStartDate").html() == null ? "" : doc.getElementById("lblStartDate").html());
		valueMap.put("lblEndDate", doc.getElementById("lblEndDate").html() == null ? "" : doc.getElementById("lblEndDate").html());
		valueMap.put("dealagreement", doc.getElementById("dealagreement").html() == null ? "" : doc.getElementById("dealagreement").html());
		valueMap.put("lblContractAddress", doc.getElementById("lblContractAddress").html() == null ? "" : doc.getElementById("lblContractAddress").html());
		valueMap.put("lblBotherMode", doc.getElementById("lblBotherMode").html() == null ? "" : doc.getElementById("lblBotherMode").html());
		valueMap.put("lblInteriorContract", doc.getElementById("lblInteriorContract").html() == null ? "" : doc.getElementById("lblInteriorContract").html());
		valueMap.put("lblForeignInterestInvolved", doc.getElementById("lblForeignInterestInvolved").html() == null ? "" : doc.getElementById("lblForeignInterestInvolved").html());
		valueMap.put("lblConnectedTransactions", doc.getElementById("lblConnectedTransactions").html() == null ? "" : doc.getElementById("lblConnectedTransactions").html());
		valueMap.put("lblMyUnitName", doc.getElementById("lblMyUnitName").html() == null ? "" : doc.getElementById("lblMyUnitName").html());
		valueMap.put("lblSignName", doc.getElementById("lblSignName").html() == null ? "" : doc.getElementById("lblSignName").html());
		valueMap.put("lblOtherThing", doc.getElementById("lblOtherThing").html() == null ? "" : doc.getElementById("lblOtherThing").html());

		// 承办人信息
		valueMap.put("myUndertakeDeptmentInfo_lblDept", doc.getElementById("myUndertakeDeptmentInfo_lblDept") == null ? "" : doc.getElementById("myUndertakeDeptmentInfo_lblDept").val());
		valueMap.put("myUndertakeDeptmentInfo_lblDeptChargerName",
				doc.getElementById("myUndertakeDeptmentInfo_lblDeptChargerName").html() == null ? "" : doc.getElementById("myUndertakeDeptmentInfo_lblDeptChargerName").html());
		valueMap.put("myUndertakeDeptmentInfo_lblUndertaker",
				doc.getElementById("myUndertakeDeptmentInfo_lblUndertaker").html() == null ? "" : doc.getElementById("myUndertakeDeptmentInfo_lblUndertaker").html());
		valueMap.put("myUndertakeDeptmentInfo_telephone", doc.getElementById("myUndertakeDeptmentInfo_telephone").html() == null ? "" : doc.getElementById("myUndertakeDeptmentInfo_telephone").html());
		valueMap.put("myUndertakeDeptmentInfo_lblTimeTitle", doc.getElementById("myUndertakeDeptmentInfo_txtTime") == null ? "" : doc.getElementById("myUndertakeDeptmentInfo_txtTime").val());

		contract.setDeclareInfo(valueMap);
		// 其他信息
		contract.setContractBasis(getContractBasis(doc, contract));
		// 项目信息
		contract.setProjectInfo(getProjectInfo(doc, contract));
		// 人员信息
		contract.setPersonInfo(getPersonInfo(doc, contract));
		// 附件信息
		contract.setAttachment(getAttachments(doc, contract));
		// 文档信息
		contract.setDocument(getDocuments(doc, contract));

	}
	
	
	public static void getContractInfo2(Document doc, Contract contract) {
		System.out.println("&&&&&&&&&&&");
		System.out.println("###############"+doc.getElementById("lblTotalMoney").html() == null ? "" : doc.getElementById("lblTotalMoney").html());
		Map<String, String> valueMap = new HashMap<String, String>();
		// 付款
		valueMap.put("lblTotalMoney", doc.getElementById("lblTotalMoney").html() == null ? "" : doc.getElementById("lblTotalMoney").html());
		valueMap.put("lblPaidMoney", doc.getElementById("lblPaidMoney").html() == null ? "" : doc.getElementById("lblPaidMoney").html());
		valueMap.put("lblSurplusMoney", doc.getElementById("lblSurplusMoney").html() == null ? "" : doc.getElementById("lblSurplusMoney").html());
		valueMap.put("lblRemark", doc.getElementById("lblRemark").html() == null ? "" : doc.getElementById("lblRemark").html());
		valueMap.put("lblCommentPayment", doc.getElementById("lblCommentPayment") == null ? "" : doc.getElementById("lblCommentPayment").html());
		valueMap.put("lblPaymentProperty", doc.getElementById("lblPaymentProperty").html() == null ? "" : doc.getElementById("lblPaymentProperty").html());
		valueMap.put("lblPaymentMoney", doc.getElementById("lblPaymentMoney").html() == null ? "" : doc.getElementById("lblPaymentMoney").html());
		valueMap.put("lblPaymentDept", doc.getElementById("lblPaymentDept").html() == null ? "" : doc.getElementById("lblPaymentDept").html());
		valueMap.put("lblGatheringDept", doc.getElementById("lblGatheringDept").html() == null ? "" : doc.getElementById("lblGatheringDept").html());
		valueMap.put("lblDate", doc.getElementById("lblDate").html() == null ? "" : doc.getElementById("lblDate").html());
		valueMap.put("lblOperator", doc.getElementById("lblOperator") == null ? "" : doc.getElementById("lblOperator").html());
		System.out.println("$$$$$$$$$$$");
		
//		valueMap.put("lblMarkMoney", doc.getElementById("lblMarkMoney").html() == null ? "" : doc.getElementById("lblMarkMoney").html());
//		valueMap.put("lblCurrencyType", doc.getElementById("lblCurrencyType").html() == null ? "" : doc.getElementById("lblCurrencyType").html());
//		valueMap.put("lblContractType", doc.getElementById("lblContractType").html() == null ? "" : doc.getElementById("lblContractType").html());
//		valueMap.put("lblStartDate", doc.getElementById("lblStartDate").html() == null ? "" : doc.getElementById("lblStartDate").html());
//		valueMap.put("lblEndDate", doc.getElementById("lblEndDate").html() == null ? "" : doc.getElementById("lblEndDate").html());
//		valueMap.put("dealagreement", doc.getElementById("dealagreement").html() == null ? "" : doc.getElementById("dealagreement").html());
//		valueMap.put("lblContractAddress", doc.getElementById("lblContractAddress").html() == null ? "" : doc.getElementById("lblContractAddress").html());
//		valueMap.put("lblBotherMode", doc.getElementById("lblBotherMode").html() == null ? "" : doc.getElementById("lblBotherMode").html());
//		valueMap.put("lblInteriorContract", doc.getElementById("lblInteriorContract").html() == null ? "" : doc.getElementById("lblInteriorContract").html());
//		valueMap.put("lblForeignInterestInvolved", doc.getElementById("lblForeignInterestInvolved").html() == null ? "" : doc.getElementById("lblForeignInterestInvolved").html());
//		valueMap.put("lblConnectedTransactions", doc.getElementById("lblConnectedTransactions").html() == null ? "" : doc.getElementById("lblConnectedTransactions").html());
//		valueMap.put("lblMyUnitName", doc.getElementById("lblMyUnitName").html() == null ? "" : doc.getElementById("lblMyUnitName").html());
//		valueMap.put("lblSignName", doc.getElementById("lblSignName").html() == null ? "" : doc.getElementById("lblSignName").html());
//		valueMap.put("lblOtherThing", doc.getElementById("lblOtherThing").html() == null ? "" : doc.getElementById("lblOtherThing").html());
//
//		// 承办人信息
//		valueMap.put("myUndertakeDeptmentInfo_lblDept", doc.getElementById("myUndertakeDeptmentInfo_lblDept") == null ? "" : doc.getElementById("myUndertakeDeptmentInfo_lblDept").val());
//		valueMap.put("myUndertakeDeptmentInfo_lblDeptChargerName",
//				doc.getElementById("myUndertakeDeptmentInfo_lblDeptChargerName").html() == null ? "" : doc.getElementById("myUndertakeDeptmentInfo_lblDeptChargerName").html());
//		valueMap.put("myUndertakeDeptmentInfo_lblUndertaker",
//				doc.getElementById("myUndertakeDeptmentInfo_lblUndertaker").html() == null ? "" : doc.getElementById("myUndertakeDeptmentInfo_lblUndertaker").html());
//		valueMap.put("myUndertakeDeptmentInfo_telephone", doc.getElementById("myUndertakeDeptmentInfo_telephone").html() == null ? "" : doc.getElementById("myUndertakeDeptmentInfo_telephone").html());
//		valueMap.put("myUndertakeDeptmentInfo_lblTimeTitle", doc.getElementById("myUndertakeDeptmentInfo_txtTime") == null ? "" : doc.getElementById("myUndertakeDeptmentInfo_txtTime").val());

		contract.setDeclareInfo(valueMap);
//		// 其他信息
//		contract.setContractBasis(getContractBasis(doc, contract));
//		// 项目信息
//		contract.setProjectInfo(getProjectInfo(doc, contract));
//		// 人员信息
//		contract.setPersonInfo(getPersonInfo(doc, contract));
//		// 附件信息
//		contract.setAttachment(getAttachments(doc, contract));
//		// 文档信息
//		contract.setDocument(getDocuments(doc, contract));

	}

	// 获取签约依据
	public static List<Map<String, String>> getContractBasis(Document doc, Contract contract) {
		List<Map<String, String>> dataList = new ArrayList<Map<String, String>>();
		Element table = doc.getElementById("dgProjInfoList");
		if (table == null) {
			return dataList;
		}
		int i = 0;
		for (Element tr : table.getElementsByTag("tr")) {
			int j = 0;
			i++;
			if (i == 1)
				continue;
			Map<String, String> dataMap = new HashMap<String, String>();
			for (Element td : tr.getElementsByTag("td")) {
				if (j == 0) {
					Element a = td.getElementsByTag("a").get(0);
					dataMap.put("name", a.attr("title"));
					dataMap.put("url", a.attr("href"));
				} else if (j == 1) {
					dataMap.put("fileCode", td.html());
				}
				j++;
			}
			dataList.add(dataMap);

		}

		return dataList;

	}

	// 获取项目信息
	public static List<Map<String, String>> getProjectInfo(Document doc, Contract contract) {
		List<Map<String, String>> dataList = new ArrayList<Map<String, String>>();
		Element table = doc.getElementById("dgProject");
		if (table == null) {
			return dataList;
		}
		int i = 0;
		for (Element tr : table.getElementsByTag("tr")) {
			int j = 0;
			i++;
			if (i == 1)
				continue;
			Map<String, String> dataMap = new HashMap<String, String>();
			for (Element td : tr.getElementsByTag("td")) {
				if (j == 0) {
					dataMap.put("serialNo", td.html());
				} else if (j == 1) {
					dataMap.put("prjCode", td.html());
				} else if (j == 2) {
					Element a = td.getElementsByTag("a").get(0);
					dataMap.put("prjName", a.html());
					dataMap.put("url", a.attr("href"));
				} else if (j == 3) {
					dataMap.put("prjAmount", td.html());
				} else if (j == 4) {
					dataMap.put("prjCny", td.html());
				}
				j++;
			}
			dataList.add(dataMap);

		}

		return dataList;

	}

	// 获取合同相对人信息
	public static List<Map<String, String>> getPersonInfo(Document doc, Contract contract) {
		List<Map<String, String>> dataList = new ArrayList<Map<String, String>>();
		Element table = doc.getElementById("dgContractRelationPerson");
		if (table == null) {
			return dataList;
		}
		for (Element tr : table.getElementsByTag("tr")) {
			int j = 0;
			Map<String, String> dataMap = new HashMap<String, String>();
			for (Element td : tr.getElementsByTag("td")) {
				if (j == 0) {
					Element a = td.getElementsByTag("a").get(0);
					dataMap.put("name", a.html());
					dataMap.put("url", a.attr("href"));
				}
				j++;
			}
			dataList.add(dataMap);
		}
		return dataList;

	}

	// 获取合同最终文本
	public static List<Map<String, String>> getAttachments(Document doc, Contract contract) {
		List<Map<String, String>> dataList = new ArrayList<Map<String, String>>();
		Element table = doc.getElementById("FileUploadingMgt1_dgPostFile");
		if (table == null) {
			return dataList;
		}
		int i = 0;
		for (Element tr : table.getElementsByTag("tr")) {
			int j = 0;
			i++;
			if (i == 1)
				continue;
			Map<String, String> dataMap = new HashMap<String, String>();
			for (Element td : tr.getElementsByTag("td")) {
				if (j == 0) {
					Element a = td.getElementsByTag("a").get(0);
					dataMap.put("name", a.html());
					String url = a.attr("Onclick");
					url = url.substring(url.indexOf("'") + 1, url.lastIndexOf("'"));
					dataMap.put("url", OASystemInit.sysConfig.get("contractHost") + url);
					  //dataMap.put("url",url);
				} else if (j == 1) {
					dataMap.put("templateName", td.html().equals("&nbsp;")?"":td.html());
				} else if (j == 2) {
					dataMap.put("createTime", td.html());
				} else if (j == 3) {
					dataMap.put("standard", td.html());
				}
				j++;
			}
			dataList.add(dataMap);
		}
		return dataList;

	}

	// 合同最终相关资料
	public static List<Map<String, String>> getDocuments(Document doc, Contract contract) {
		List<Map<String, String>> dataList = new ArrayList<Map<String, String>>();
		Element table = doc.getElementById("FileUploadingMgt2_dgPostFile");
		if (table == null) {
			return dataList;
		}
		int i = 0;
		for (Element tr : table.getElementsByTag("tr")) {
			int j = 0;
			i++;
			if (i == 1)
				continue;
			Map<String, String> dataMap = new HashMap<String, String>();
			for (Element td : tr.getElementsByTag("td")) {
				if (j == 0) {
					Element a = td.getElementsByTag("a").get(0);
					dataMap.put("name", a.html());
					String url = a.attr("Onclick");
					url = url.substring(url.indexOf("'") + 1, url.lastIndexOf("'"));
					dataMap.put("url", OASystemInit.sysConfig.get("contractHost") + url);
					//dataMap.put("url",  url);
				} else if (j == 1) {
					dataMap.put("templateName", td.html().equals("&nbsp;")?"":td.html());
				} else if (j == 2) {
					dataMap.put("createTime", td.html());
				} else if (j == 3) {
					dataMap.put("standard", td.html());
				}
				j++;
				//System.out.println(dataMap);
			}
			dataList.add(dataMap);
		}
		return dataList;
	}

	// 审批流程信息
	public static List<Map<String, String>> getAuditFlow(Document doc) {
		List<Map<String, String>> dataList = new ArrayList<Map<String, String>>();
		Elements tables =doc.getElementById("tblDeptFlow").getElementsByTag("table");
		Element table = null;
		if(tables.size()>0){
			table=tables.get(1);


		}
		if (table == null) {
			return dataList;
		}
		int i = 0;
		for (Element tr : table.getElementsByTag("tr")) {
			int j = 1;
			i++;
			if (i == 1)
				continue;
			Map<String, String> dataMap = new HashMap<String, String>();
			for (Element td : tr.getElementsByTag("td")) {
				if (j == 2) {
					dataMap.put("moduleName", td.html());
				} else if (j == 3) {
					dataMap.put("taskName", td.html());
				} else if (j == 4) {
					 Elements children= td.getElementsByTag("span");
					 if(children.size()>0){
						 dataMap.put("dept", children.get(0).html()); 
					 }else{
						 dataMap.put("dept", "");
					 }
				} else if (j == 5) {
					 dataMap.put("auditMethod", td.html()); 

				}
				j++;
			}
			dataList.add(dataMap);
		}
		return dataList;

	}

	// 审批过程信息
	public static List<Map<String, String>> getAuditRecord(Document doc) {
		List<Map<String, String>> dataList = new ArrayList<Map<String, String>>();
		Element table = doc.getElementById("GroupID5");
		if (table == null) {
			return dataList;
		}
		int i = 0;
		for (Element tr : table.getElementsByTag("tr")) {
			int j = 0;
			i++;
			if (i == 1)
				continue;
			Map<String, String> dataMap = new HashMap<String, String>();
			for (Element td : tr.getElementsByTag("td")) {
				if (j == 0) {
					dataMap.put("auditResult", td.html());
				} else if (j == 1) {
					dataMap.put("dept", td.html());
				} else if (j == 2) {
					dataMap.put("person", td.html());
				} else if (j == 3) {
					dataMap.put("auditTime", td.html());
				}else if (j == 4) {
					dataMap.put("auditRemark", td.html());
				}
				j++;
			}
			dataList.add(dataMap);
		}
		return dataList;

	}

	// 获取POST信息
	public static Map<String, String> getPostInfo(Document doc) {

		Map<String, String> paramMap = new HashMap<String, String>();

		String[] NAMES = new String[] { "__VIEWSTATE", "__smartNavPostBack", "__VIEWSTATEGENERATOR", "CurrentTab", "LatestTab", "ReviewAndApproval:txtResultID", "ReviewAndApproval:txtRemark",
				"ReviewAndApproval:btnOK", "ReviewAndApproval:FileUploadingMgt:txtFileNo" };

		for (String name : NAMES) {
			Element e = doc.getElementById(name);
			if (e != null) {
				paramMap.put(name, e.attr("value"));
			}
		}

		System.out.println("postParams:" + paramMap);

		return paramMap;
	}

	// 获取返回目标
	public static Map<String, Object> getReturnTarget(Document doc) {
		Map<String, Object> dataMap = new HashMap<String, Object>();
		List<Map<String, String>> dataList = new ArrayList<Map<String, String>>();
		Element select = doc.getElementById("ReviewAndApproval_lbSource");
		Elements options = select.children();
		for (Element option : options) {
			Map<String, String> optionMap = new HashMap<String, String>();
			optionMap.put("targetValue", option.attr("value"));
			optionMap.put("targetName", option.html());
			dataList.add(optionMap);
		}
		dataMap.put("options", dataList);
		// dataMap.put("ReviewAndApproval:txtGoBackText",
		// doc.getElementById("ReviewAndApproval_txtGoBackText").val());
		System.out.println("ReturnTarget:" + dataMap);
		return dataMap;
	}

	// 返回页面的的请求参数
	public static Map<String, String> getReturnPagePostInfo(Document doc) {
		Map<String, String> paramMap = new HashMap<String, String>();
		String[] NAMES = new String[] { "__VIEWSTATE", "__VIEWSTATEGENERATOR", "CurrentTab", "LatestTab", "ReviewAndApproval:txtResultID", "ReviewAndApproval:txtRemark", "ReviewAndApproval:btnBack",
				"ReviewAndApproval:FileUploadingMgt:txtFileNo", "__smartNavPostBack" };
		for (String name : NAMES) {
			Element e = doc.getElementById(name);
			if (e != null) {
				paramMap.put(name, e.attr("value"));
			}
		}
		paramMap.put("ReviewAndApproval:txtResultID ", "0");
		paramMap.put("ReviewAndApproval:FileUploadingMgt:txtFileNo ", "");
		paramMap.put("__smartNavPostBack", "true");
		paramMap.put("ReviewAndApproval:btnBack", "返回相关部门");
		System.out.println("ReturnPagePostInfo:" + paramMap);
		return paramMap;
	}

	// 返回页面的的请求参数
	public static Map<String, String> getDoReturnPostInfo(Document doc) {
		Map<String, String> paramMap = new HashMap<String, String>();
		String[] NAMES = new String[] { "__EVENTTARGET", "__EVENTARGUMENT", "__LASTFOCUS", "__VIEWSTATE", "__VIEWSTATEGENERATOR", "CurrentTab", "LatestTab", "ReviewAndApproval:txtResultID",
				"ReviewAndApproval:txtRemark", "ReviewAndApproval:btnBack", "ReviewAndApproval:FileUploadingMgt:txtFileNo", "__smartNavPostBack" };
		for (String name : NAMES) {
			Element e = doc.getElementById(name);
			if (e != null) {
				paramMap.put(name, e.attr("value"));
			}
		}

		paramMap.put("ReviewAndApproval:txtResultID", "0");
		paramMap.put("ReviewAndApproval:FileUploadingMgt:txtFileNo", "");
		paramMap.put("rboGoBack", "0");
		paramMap.put("__smartNavPostBack", "true");
		paramMap.put("ReviewAndApproval:rboGoBack", "0");
		paramMap.put("ReviewAndApproval:btnGoBack", "确定");
		paramMap.put("__LASTFOCUS", "");
		paramMap.put("__EVENTTARGET", "");
		paramMap.put("__EVENTARGUMENT", "");
		paramMap.put("__LASTFOCUS", "");

		return paramMap;
	}
}
