<?xml version="1.0" encoding="UTF-8"?>
<model xmlns="http://www.justep.com/model">
	<action xmlns="http://www.w3.org/1999/xhtml" name="SimpleFileStore"
		impl="takeoutAdmin.SimpleFileStore.service"></action>
</model>