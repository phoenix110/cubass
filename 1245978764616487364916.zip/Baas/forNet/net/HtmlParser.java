package forNet.net;

import java.io.IOException;
import java.io.InputStream;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class HtmlParser {
	public static Document parser(InputStream in, String baseUri){
		if (baseUri==null) baseUri = "http://example.com/";
		Document result;
		try {
			result = Jsoup.parse(in, "UTF-8", baseUri);
		} catch (IOException e) {
			throw new RuntimeException("服务端解析返回数据出错！");
		}
		return result;
	}
}
