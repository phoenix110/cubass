package taobao;


	import java.util.Vector;

	import javax.xml.namespace.QName;
	import javax.xml.rpc.ParameterMode;
	import javax.xml.rpc.encoding.XMLType;

	import org.apache.axis.client.Call;
	import org.apache.axis.client.Service;


	/**
	* 通过输入IP地址查询国家、城市、所有者等信息。没有注明国家的为中国 输入参数：IP地址（自动替换 " 。" 为 "."），返回数据：
	* 一个一维字符串数组String(1)，String(0) = IP地址；String(1) = 查询结果或提示信息
	*
	* @author liulei
	*
	*/
	public class webservicetest {
		
		//WEB服务的URL
		private String url = "http://10.76.19.159/CommonServices/CommonService.asmx"; 
		//targetNamespace
		private String namespace = "http://tempuri.org/"; 
//		private String actionURI = "http://tempuri.org/GetDataBySql"; // Action路径 
		private String op = "GetDataBySql"; // 要调用的方法名

		public webservicetest() {
			Service service = new Service();
			try {
				Call call = (Call) service.createCall();
				call.setTargetEndpointAddress(new java.net.URL(url)); 
//				call.setSOAPActionURI(actionURI);
				// 设置要调用哪个方法
				call.setOperationName(new QName(namespace, op));
				// 设置参数名称，具体参照从浏览器中看到的2
//				call.addParameter(new QName(namespace, "strUserName"),XMLType.XSD_STRING, ParameterMode.IN); // 要返回的数据类型 
//				call.addParameter(new QName(namespace, "strPassword"),XMLType.XSD_STRING, ParameterMode.IN); // 要返回的数据类型
//				call.addParameter(new QName(namespace, "modename"),XMLType.XSD_STRING, ParameterMode.IN); // 要返回的数据类型
//				call.addParameter(new QName(namespace, "systemName"),XMLType.XSD_STRING, ParameterMode.IN); // 要返回的数据类型
//				call.addParameter(new QName(namespace, "subSystemUser"),XMLType.XSD_STRING, ParameterMode.IN); // 要返回的数据类型
//				call.addParameter(new QName(namespace, "sql"),XMLType.XSD_STRING, ParameterMode.IN); // 要返回的数据类型
//				call.setReturnType(new QName(namespace, op),Vector.class); // 入参：对应theIpAddress 
				Object[] params = new Object[] {
						"fengqi172@163.com",
						"1qaz2wsx",
						"PCDM97",
						"移动应用平台",
						"夏鑫",
						"select * from dks02 where dwdm='0'"
						}; // 调用方法并传递参数 
				Vector result = (Vector)call.invoke(params); 
//				System.out.println("Str:"+result);
			}catch (Exception ex){ 
				ex.printStackTrace(); 
			} 
		}
		public static void main(String args[]){ 
			new webservicetest(); 
		}
	}
