package mobiAppPlat.oa.app.contractapprove;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import mobiAppPlat.oa.app.docapprove.service.CheckUserOnline;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import forNet.net.HtmlParser;
import forNet.net.RespCallback;

public class TaskAuditInfoCallback implements RespCallback {
     
	public static void main(String[] args) {
		InputStream in = HtmlParser.class.getResourceAsStream("/mobiAppPlat/oa/app/contractapprove/auditInfo.txt");
		new TaskAuditInfoCallback().execute(in);
	}
	
	public Object execute(InputStream body) {
		String flag = "true";
		Document doc = HtmlParser.parser(body, null);
		//System.out.println("auditHtml:"+doc.html());
		CheckUserOnline.checkOnline(doc);
		Map<String, Object> result = new HashMap<String,Object>();
		result.put("flag", flag);
		result.put("auditFlow", PageUtils.getAuditFlow(doc));
		result.put("auditRecord", PageUtils.getAuditRecord(doc));
		//System.out.println(result);
		return result;
	}

}
