package forNet.net.pages;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import forNet.net.HtmlParser;
import forNet.net.RespCallback;

public class TaskPageLoadCallback implements RespCallback{
	private static final String[] NAMES = new String[]{
		"ctl03$AgentDrafterDisplayName",
		"ctl03$WordMarkNo",
		"ctl03$Topic",
		"ctl03$AgentDrafter",
		"ctl03$AgentDraftTime",
		"ctl03$GiveCopyUnitID",
		"ctl03$Accessory",
		"ctl03$HandleDescription",
		"ctl03$AdjunctTitle",
		"ctl03$AdjunctUrl",
		"ctl03$FileNo",
		"ctl03$ReaderFullName",
		"ctl03$ReaderName",
		"ctl03$Reader",
		"ctl03$GiveCopyUnit",
		"ctl03$GiveMainDiction",
		"ctl03$GiveCopyDiction",
		"ctl03$GiveFileReaderDiction",
		"__VIEWSTATE",
		"__EVENTVALIDATION",
		"ctl03$DraftTitle",
		"ctl03$TelephoneNo",
		"ctl03$DraftDate",
		"ctl03$DraftTime",
		"ctl03$DrafterIncID",
		"ctl03$GiveMainUnitID",
		"__VIEWSTATEGENERATOR",
		"ctl03$DocID",
		"Audit_00_Current_Ctrl$ReviewIdea",
		"ctl03$DraftUnitID",
		"ctl03$DrafterDeptID",
		"ctl03$DocWebService",
		"ctl00$txtforward_0",
		"ctl00$txtbackwords_0",
		"ctl03$Drafter",
		"ctl00$forward_0",
		"ctl03$HeadTemplate",
		"ctl03$DrafterIncName",
		"ctl03$DraftUnit",
		"ctl03$GiveMainUnit",
		"ctl03$DrafterDisplayName",
		"ctl03$DrafterDeptName"
	};
	
	private static final String[] TASK_COLUMNS = new String[]{
		"Audit_00_Current_Ctrl$ReviewIdea", //审批意见
		"ctl03$DraftTitle", //标题
		"ctl03$DrafterDisplayName", //拟稿人
		"ctl03$DraftUnit", //抄送单位
		"ctl03$DraftDate", //拟稿日期
		"ctl03$WordMarkNo" //文件编号
	}; 
	
	
	public Object execute(InputStream body) {
		Document doc = HtmlParser.parser(body, null);
		
		CheckUserOnline.checkOnline(doc);
		
		Map<String, Object> result = new HashMap<String, Object>();
		Map<String, String> pageState = new HashMap<String, String>();
		result.put("pageState", pageState);
		for (String name : NAMES){
			Elements es = doc.getElementsByAttributeValue("name", name);
			if (es.size()>=1){
				String value = "";
				Element e = es.get(0);
				if (e.tagName().equals("textarea")){
					value = e.text();
				}else{
					value = es.get(0).attr("value");
				}
				
				pageState.put(name, value);
				//System.out.println(es.get(0).toString());
				System.out.println(name + ": " + value);
			}
		}
		
		Map<String, String> task = new HashMap<String, String>();
		for (String column : TASK_COLUMNS){
			task.put(column, pageState.get(column));	
		}
		System.out.println(task);
		result.put("task", task);
		return result;
	}
	

}
