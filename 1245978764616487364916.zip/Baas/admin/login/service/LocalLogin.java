package admin.login.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import admin.utils.StringUtil;
import admin.utils.SystemInit;

import com.alibaba.fastjson.JSONObject;
import com.justep.baas.action.ActionContext;
import com.justep.baas.data.DataUtils;
import com.justep.baas.data.Row;
import com.justep.baas.data.Table;

public class LocalLogin implements ILoginStrategy {

	public JSONObject login(JSONObject params, ActionContext context) {
		JSONObject jsonObj = new JSONObject();
		String loginName = params.getString("loginName");
		String password = StringUtil.string2MD5(params.getString("password"));
		String uuid = params.getString("uuid") == null ? "" : params.getString("uuid");
		String client = params.getString("client");
		System.out.println("loginName:" + loginName);
		System.out.println("password:" + password);
		Connection conn = null;
		try {
			conn = context.getConnection(SystemInit.sysConfig.get("dsSys"));
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		}
		List<Object> sqlParams = new ArrayList<Object>();
		sqlParams.add(loginName);
		//sqlParams.add(password);
		//Table table = DataUtils.queryData(conn, "select sDeviceSerialNo from sa_opperson where sLoginName=? and sPassword=?", sqlParams, null, null, null);
		Table table = DataUtils.queryData(conn, "select sDeviceSerialNo from sa_opperson where sLoginName=?", sqlParams, null, null, null);
		System.out.println("getRows===============:"+table.getRows().size());

		// (1.登录成功,2.串码未备案,3.用户名或者密码错误),只有原生APP才验证串码，webApp不验证,串码验证开关打开才进行验证
		if (table.getRows().size() > 0) {
			Row row = table.getRows().get(0);
			if (!uuid.equals(row.getString("sDeviceSerialNo")) && "mobile".equals(client) && "1".equals(SystemInit.sysConfig.get("device_serial_validate"))) {
				jsonObj.put("msg", 2);
			} else {
				jsonObj.put("msg", 1);
			}
		} else {
			jsonObj.put("msg", 3);
		}
		return jsonObj;
	}

}
