package mobiAppPlat.oa.app.expenseapprove.personal;

import java.util.Map;

import mobiAppPlat.oa.system.OASystemInit;
import mobiAppPlat.oa.utils.ConfigUtil;

import forNet.net.NetServer;
import forNet.net.ReqObj;
import forNet.net.RespObj;
import forNet.net.pages.ActionResult;
import forNet.net.util.Utils;

public class TaskListPage {
	public static ActionResult load(Map<String, String> cookies){
		System.out.println("cookie:"+Utils.map2String(cookies));
		ActionResult ar = new ActionResult(true, "");
		ReqObj req = new ReqObj();
		req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept", "Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		//req.addHeader("Accept-Encoding", "gzip, deflate, sdch"); //不压缩
		req.addHeader("Accept-Language", "zh-CN,zh;q=0.8");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		//req.addHeader("Host", "10.27.82.155");
		//req.addHeader("Origin", "http://10.27.82.155");
		req.addHeader("Pragma", "no-cache");
		req.addHeader("Upgrade-Insecure-Requests", "1");
		req.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.4 Safari/537.36");
		req.setMethod("post");
		req.setUrl(OASystemInit.sysConfig.get("expenseTaskList"));
		RespObj tasks = NetServer.service(req, new TaskListPageCallback());
		ar.addCookies(tasks.getCookies());
		ar.setData(tasks.getResponseBody());
		return ar;
		
	}
	
}
