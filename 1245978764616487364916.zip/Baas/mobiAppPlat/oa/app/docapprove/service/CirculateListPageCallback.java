package mobiAppPlat.oa.app.docapprove.service;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import mobiAppPlat.oa.app.docapprove.bean.HtmlParser;
import mobiAppPlat.oa.app.docapprove.bean.RespCallback;
import mobiAppPlat.oa.app.docapprove.bean.Task;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class CirculateListPageCallback implements RespCallback{
	
	public Object execute(InputStream body) {
		Map<String,Object> pageSate = new HashMap<String,Object>();
		List<Task> result = new ArrayList<Task>();
		Document doc = HtmlParser.parser(body, null);
		CheckUserOnline.checkOnline(doc);
		//Element e = doc.getElementById("tabTask");
		  Element e = doc.getElementById("dgSData");
		if (e!=null){
			int i = 0;
			for (Element tr : e.getElementsByTag("tr")){
				
				if (i++ == 0) continue; //忽略表头
				//Elements tds = tr.getElementsByTag("td");
				Task task = new Task();
				Elements es = tr.getElementsByTag("a");
				if (es.size()==1){
					Element a =  es.get(0);
					task.detailUrl = "/task%20portal/UIWorkflowQuery/"+a.attr("href");
					task.name = a.html();
					String next=a.nextSibling().toString();
					String[] items = next.split("&nbsp;");
					task.time=items[1];
					task.status=items[2];
					/*
					task.name = es.get(0).text();
					if ((click!=null) && click.contains("'")){
						String[] items = click.split("'");
						if (items.length>=3){
							task.detailUrl=items[1].replaceAll("\\.\\.", "");
							task.id = items[1].split("=")[1].replaceAll("&openType", "");
						}
					}
					*/
				}
				if ("()".equals(task.status)) continue;
				result.add(task);
			}
		}
		pageSate.put("taskList", result);
		pageSate.put("recordCount", result.size());
		return pageSate;
	}
	
	
	private static String getUrl(Element tr){
		
		return null;
		
	}
	

	public static void main(String[] args) {
		InputStream in = HtmlParser.class.getResourceAsStream("/mobiAppPlat/oa/app/docapprove/circulateTaskList.txt");
		new CirculateListPageCallback().execute(in);
	}

}
