package mobiAppPlat.oa.app.docapprove;

import java.util.HashMap;
import java.util.Map;

import mobiAppPlat.oa.app.docapprove.bean.ActionResult;
import mobiAppPlat.oa.app.docapprove.center1.service.Task1BgsdjPage;
import mobiAppPlat.oa.app.docapprove.center2.service.Task2BgsnbPage;
import mobiAppPlat.oa.app.docapprove.center3.service.Task3ZxldpsPage;
import mobiAppPlat.oa.app.docapprove.center4.service.Task4SpsPage;
import mobiAppPlat.oa.app.docapprove.dept1.service.Task1KsdjPage;
import mobiAppPlat.oa.app.docapprove.dept2.service.Task2KssbPage;
import mobiAppPlat.oa.app.docapprove.dept3.service.Task3KspbPage;
import mobiAppPlat.oa.app.docapprove.dept4.service.Task4CbPage;
import mobiAppPlat.oa.app.docapprove.service.StartTaskPage;
import mobiAppPlat.oa.app.docapprove.utils.CookiesUtils;

import com.alibaba.fastjson.JSONObject;
import com.justep.baas.action.ActionContext;


public class DoTask {
	
	private static final String COOKIE_ID = CookiesUtils.getCookiesID();
	
	//流程启动环节
	public static JSONObject doStartTask(JSONObject params, ActionContext context){
		boolean flag = true;
		String msg = null;
		try{
			JSONObject pageState = (JSONObject)params.get("pageState");
			String task = params.getString("task");
			Map<String, String> state = new HashMap<String, String>();
			for (String key : pageState.keySet()){
				state.put(key, pageState.getString(key));
			}
			ActionResult ar = StartTaskPage.doTask(task, CookiesUtils.getCookies(context,COOKIE_ID), state);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
			}
		}catch(Exception e){
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		return result;
	}
	
	
	//（处室收文）的（科室登记）环节执行（处室送办）
	public static JSONObject do1KsdjTask(JSONObject params, ActionContext context){
		boolean flag = true;
		String msg = null;
		try{
			JSONObject pageState = (JSONObject)params.get("pageState");
			String task = params.getString("task");
			Map<String, String> state = new HashMap<String, String>();
			for (String key : pageState.keySet()){
				state.put(key, pageState.getString(key));
			}
			ActionResult ar = Task1KsdjPage.doTask(task, CookiesUtils.getCookies(context,COOKIE_ID), state);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
			}
		}catch(Exception e){
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		return result;
		
	}
	
	
	private static final String[] DO2KSPDPARAMS = new String[]{
		"__VIEWSTATEGENERATOR",
		"__EVENTVALIDATION",
		"__VIEWSTATE",
		"ctl00$forward_0",
		"ctl00$txtforward_0",
		"ctl00$txtforward_1",
		"ctl00$txtfinish_0",
		"ctl00$txtdistribute_0",
		"ctl00$txtsave_0",
		"ctl00$txtstop_0",
		"ctl00$txtprint_0",
		"ReviewStart_01_Current_Ctrl$UsersID",
		"ReviewStart_01_Current_Ctrl$UsersName",
		"ReviewStart_01_Current_Ctrl$DeptSigners",
		"Register_00_History_Ctrl$WordMarkNo",
		"Register_00_History_Ctrl$ReceiveDate",
		"Register_00_History_Ctrl$RegisterDisplayName",
		"Register_00_History_Ctrl$DraftUnit",
		"Register_00_History_Ctrl$SourceType",
		"Register_00_History_Ctrl$SecretLevel",
		"Register_00_History_Ctrl$SecretLimit",
		"Register_00_History_Ctrl$UrgentLevel",
		"Register_00_History_Ctrl$CarrierType",
		"Register_00_History_Ctrl$ReceiveFileNo",
		"Register_00_History_Ctrl$CreateDate",
		"Register_00_History_Ctrl$Amount",
		"Register_00_History_Ctrl$ReceiveType",
		"Register_00_History_Ctrl$FileTitle",
		"Register_00_History_Ctrl$Topic",
		"Register_00_History_Ctrl$GiveMainUnit",
		"Register_00_History_Ctrl$GiveCopyUnit",
		"Register_00_History_Ctrl$Archive",
		"Register_00_History_Ctrl$TimeLimit",
		"Register_00_History_Ctrl$Issue",
		"Register_00_History_Ctrl$ChannelDirectory",
		"Register_00_History_Ctrl$RegisterDeptID",
		"Register_00_History_Ctrl$RegisterDept",
		"Register_00_History_Ctrl$Register",
		"Register_00_History_Ctrl$GiveMainUnitID",
		"Register_00_History_Ctrl$GiveCopyUnitID",
		"Register_00_History_Ctrl$ReceiveTime",
		"Register_00_History_Ctrl$CreateTime",
		"Register_00_History_Ctrl$DocID",
		"Register_00_History_Ctrl$DocWebService",
		"Register_00_History_Ctrl$Accessory",
		"Register_00_History_Ctrl$HeadTemplate",
		"Register_00_History_Ctrl$DrafterIncID",
		"Register_00_History_Ctrl$DrafterIncName",
		"Register_00_History_Ctrl$DrafterDeptID",
		"Register_00_History_Ctrl$DrafterDeptName",
		"Register_00_History_Ctrl$ReceiveRemark"
	};
	//（处室收文）的（科室送办）环节执行（处室批办）
	public static JSONObject do2KspbTask(JSONObject params,ActionContext context){
		boolean flag = true;
		String msg = null;
		try {
			JSONObject pageState = (JSONObject)params.get("pageState");
			String task = params.getString("task");
			Map<String, String> state = new HashMap<String, String>();
			for (String key : DO2KSPDPARAMS) {
				state.put(key, pageState.getString(key));
				
			}
			ActionResult ar = Task2KssbPage.doKspbTask(task, CookiesUtils.getCookies(context,COOKIE_ID), state);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		return result;
		
	}
	
	
	private static final String[] DO2BJPARAMS = new String[]{
		"__VIEWSTATEGENERATOR",
		"__EVENTVALIDATION",
		"__VIEWSTATE",
		"ctl00$finish_0",
		"ctl00$txtforward_0",
		"ctl00$txtforward_1",
		"ctl00$txtfinish_0",
		"ctl00$txtdistribute_0",
		"ctl00$txtsave_0",
		"ctl00$txtstop_0",
		"ctl00$txtprint_0",
		"ReviewStart_01_Current_Ctrl$UsersID",
		"ReviewStart_01_Current_Ctrl$UsersName",
		"ReviewStart_01_Current_Ctrl$DeptSigners",
		"Register_00_History_Ctrl$WordMarkNo",
		"Register_00_History_Ctrl$ReceiveDate",
		"Register_00_History_Ctrl$RegisterDisplayName",
		"Register_00_History_Ctrl$DraftUnit",
		"Register_00_History_Ctrl$SourceType",
		"Register_00_History_Ctrl$SecretLevel",
		"Register_00_History_Ctrl$SecretLimit",
		"Register_00_History_Ctrl$UrgentLevel",
		"Register_00_History_Ctrl$CarrierType",
		"Register_00_History_Ctrl$ReceiveFileNo",
		"Register_00_History_Ctrl$CreateDate",
		"Register_00_History_Ctrl$Amount",
		"Register_00_History_Ctrl$ReceiveType",
		"Register_00_History_Ctrl$FileTitle",
		"Register_00_History_Ctrl$Topic",
		"Register_00_History_Ctrl$GiveMainUnit",
		"Register_00_History_Ctrl$GiveCopyUnit",
		"Register_00_History_Ctrl$Archive",
		"Register_00_History_Ctrl$TimeLimit",
		"Register_00_History_Ctrl$Issue",
		"Register_00_History_Ctrl$ChannelDirectory",
		"Register_00_History_Ctrl$RegisterDeptID",
		"Register_00_History_Ctrl$RegisterDept",
		"Register_00_History_Ctrl$Register",
		"Register_00_History_Ctrl$GiveMainUnitID",
		"Register_00_History_Ctrl$GiveCopyUnitID",
		"Register_00_History_Ctrl$ReceiveTime",
		"Register_00_History_Ctrl$CreateTime",
		"Register_00_History_Ctrl$DocID",
		"Register_00_History_Ctrl$DocWebService",
		"Register_00_History_Ctrl$Accessory",
		"Register_00_History_Ctrl$HeadTemplate",
		"Register_00_History_Ctrl$DrafterIncID",
		"Register_00_History_Ctrl$DrafterIncName",
		"Register_00_History_Ctrl$DrafterDeptID",
		"Register_00_History_Ctrl$DrafterDeptName",
		"Register_00_History_Ctrl$ReceiveRemark",
	};
	//(处室收文)的（科室送办）环节执行（办结）
	public static JSONObject do2BjTask(JSONObject params,ActionContext context){
		boolean flag = true;
		String msg = null;
		try {
			JSONObject pageState = (JSONObject)params.get("pageState");
			String task = params.getString("task");
			Map<String, String> state = new HashMap<String, String>();
			for (String key : DO2BJPARAMS) {
				state.put(key, pageState.getString(key));
				
			}
			ActionResult ar = Task2KssbPage.doBjTask(task, CookiesUtils.getCookies(context,COOKIE_ID), state);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		return result;
	}
	
	private static final String[] DO2ZZGWPARAMS = new String[]{
		"__VIEWSTATEGENERATOR",
		"__EVENTVALIDATION",
		"__VIEWSTATE",
		"ctl00$stop_0",
		"ctl00$txtforward_0",
		"ctl00$txtforward_1",
		"ctl00$txtfinish_0",
		"ctl00$txtdistribute_0",
		"ctl00$txtsave_0",
		"ctl00$txtstop_0",
		"ctl00$txtprint_0",
		"ReviewStart_01_Current_Ctrl$UsersID",
		"ReviewStart_01_Current_Ctrl$UsersName",
		"ReviewStart_01_Current_Ctrl$DeptSigners",
		"Register_00_History_Ctrl$WordMarkNo",
		"Register_00_History_Ctrl$ReceiveDate",
		"Register_00_History_Ctrl$RegisterDisplayName",
		"Register_00_History_Ctrl$DraftUnit",
		"Register_00_History_Ctrl$SourceType",
		"Register_00_History_Ctrl$SecretLevel",
		"Register_00_History_Ctrl$SecretLimit",
		"Register_00_History_Ctrl$UrgentLevel",
		"Register_00_History_Ctrl$CarrierType",
		"Register_00_History_Ctrl$ReceiveFileNo",
		"Register_00_History_Ctrl$CreateDate",
		"Register_00_History_Ctrl$Amount",
		"Register_00_History_Ctrl$ReceiveType",
		"Register_00_History_Ctrl$FileTitle",
		"Register_00_History_Ctrl$Topic",
		"Register_00_History_Ctrl$GiveMainUnit",
		"Register_00_History_Ctrl$GiveCopyUnit",
		"Register_00_History_Ctrl$Archive",
		"Register_00_History_Ctrl$TimeLimit",
		"Register_00_History_Ctrl$Issue",
		"Register_00_History_Ctrl$ChannelDirectory",
		"Register_00_History_Ctrl$RegisterDeptID",
		"Register_00_History_Ctrl$RegisterDept",
		"Register_00_History_Ctrl$Register",
		"Register_00_History_Ctrl$GiveMainUnitID",
		"Register_00_History_Ctrl$GiveCopyUnitID",
		"Register_00_History_Ctrl$ReceiveTime",
		"Register_00_History_Ctrl$CreateTime",
		"Register_00_History_Ctrl$DocID",
		"Register_00_History_Ctrl$DocWebService",
		"Register_00_History_Ctrl$Accessory",
		"Register_00_History_Ctrl$HeadTemplate",
		"Register_00_History_Ctrl$DrafterIncID",
		"Register_00_History_Ctrl$DrafterIncName",
		"Register_00_History_Ctrl$DrafterDeptID",
		"Register_00_History_Ctrl$DrafterDeptName",
		"Register_00_History_Ctrl$ReceiveRemark",
	};
	
	//(处室收文)的（科室送办）环节执行（终止公文）
	public static JSONObject do2ZzgwTask(JSONObject params,ActionContext context){
		boolean flag = true;
		String msg = null;
		try {
			JSONObject pageState = (JSONObject)params.get("pageState");
			String task = params.getString("task");
			Map<String, String> state = new HashMap<String, String>();
			for (String key : DO2ZZGWPARAMS) {
				state.put(key, pageState.getString(key));
				
			}
			ActionResult ar = Task2KssbPage.doZzgwTask(task, CookiesUtils.getCookies(context,COOKIE_ID), state);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		return result; 
	}
	
	private static final String[] DO2ZCBPARAMS = new String[]{
		"__VIEWSTATEGENERATOR",
		"__EVENTVALIDATION",
		"__VIEWSTATE",
		"ctl00$forward_1",
		"ctl00$txtforward_0",
		"ctl00$txtforward_1",
		"ctl00$txtfinish_0",
		"ctl00$txtdistribute_0",
		"ctl00$txtsave_0",
		"ctl00$txtstop_0",
		"ctl00$txtprint_0",
		"ReviewStart_01_Current_Ctrl$UsersID",
		"ReviewStart_01_Current_Ctrl$UsersName",
		"ReviewStart_01_Current_Ctrl$DeptSigners",
		"Register_00_History_Ctrl$WordMarkNo",
		"Register_00_History_Ctrl$ReceiveDate",
		"Register_00_History_Ctrl$RegisterDisplayName",
		"Register_00_History_Ctrl$DraftUnit",
		"Register_00_History_Ctrl$SourceType",
		"Register_00_History_Ctrl$SecretLevel",
		"Register_00_History_Ctrl$SecretLimit",
		"Register_00_History_Ctrl$UrgentLevel",
		"Register_00_History_Ctrl$CarrierType",
		"Register_00_History_Ctrl$ReceiveFileNo",
		"Register_00_History_Ctrl$CreateDate",
		"Register_00_History_Ctrl$Amount",
		"Register_00_History_Ctrl$ReceiveType",
		"Register_00_History_Ctrl$FileTitle",
		"Register_00_History_Ctrl$Topic",
		"Register_00_History_Ctrl$GiveMainUnit",
		"Register_00_History_Ctrl$GiveCopyUnit",
		"Register_00_History_Ctrl$Archive",
		"Register_00_History_Ctrl$TimeLimit",
		"Register_00_History_Ctrl$Issue",
		"Register_00_History_Ctrl$ChannelDirectory",
		"Register_00_History_Ctrl$RegisterDeptID",
		"Register_00_History_Ctrl$RegisterDept",
		"Register_00_History_Ctrl$Register",
		"Register_00_History_Ctrl$GiveMainUnitID",
		"Register_00_History_Ctrl$GiveCopyUnitID",
		"Register_00_History_Ctrl$ReceiveTime",
		"Register_00_History_Ctrl$CreateTime",
		"Register_00_History_Ctrl$DocID",
		"Register_00_History_Ctrl$DocWebService",
		"Register_00_History_Ctrl$Accessory",
		"Register_00_History_Ctrl$HeadTemplate",
		"Register_00_History_Ctrl$DrafterIncID",
		"Register_00_History_Ctrl$DrafterIncName",
		"Register_00_History_Ctrl$DrafterDeptID",
		"Register_00_History_Ctrl$DrafterDeptName",
		"Register_00_History_Ctrl$ReceiveRemark"
	};
	
	//（处室收文）的（处室送办）环节执行（转承办）
	public static JSONObject do2zcbTask(JSONObject params,ActionContext context){
		boolean flag = true;
		String msg = null;
		try {
			JSONObject pageState = (JSONObject)params.get("pageState");
			String task = params.getString("task");
			Map<String, String> state = new HashMap<String, String>();
			for (String key : DO2ZCBPARAMS) {
				state.put(key, pageState.getString(key));
				
			}
			ActionResult ar = Task2KssbPage.doZcbTask(task, CookiesUtils.getCookies(context,COOKIE_ID), state);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		return result;
	}
	
	//（处室收文）的（处室送办）环节执行（传阅）
	public static JSONObject do2cyTask(JSONObject params,ActionContext context){
		boolean flag = true;
		String msg = null;
		try {
			String postData = params.getString("postData");
			
			Task2KssbPage.doCyTask(postData, CookiesUtils.getCookies(context,COOKIE_ID));
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		return result; 
	}
	
	private static final String[] DO3FIRSTCSPBPARAMS = new String[]{
		"__VIEWSTATE",
		"__VIEWSTATEGENERATOR",
		"__EVENTVALIDATION",         
		"ctl00$backwords_0",            
		"ctl00$txtbackwords_0",
		"Confirm_01_Current_Ctrl$ReviewIdea", //
	};
	
	//（处室收文）的（处室批办）环节执行（处室送办）
	public static JSONObject do3KspbTask(JSONObject params,ActionContext context){
		boolean flag = true;
		String msg = null;
		try {
			JSONObject pageState = (JSONObject)params.get("pageState");
			String task = params.getString("task");
			Map<String, String> state = new HashMap<String, String>();
			
			for (String key : DO3FIRSTCSPBPARAMS) {
				state.put(key, pageState.getString(key));
			}
			ActionResult ar = Task3KspbPage.doKssbTask(task, CookiesUtils.getCookies(context,COOKIE_ID), state);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		return result; 
	}
	
	private static final String[] DO4ZCBPARAMS = new String[]{
		"__VIEWSTATE",
		"__VIEWSTATEGENERATOR",
		"__EVENTVALIDATION",         
		"ctl00$forward_0",            
		"ctl00$txtforward_0",
		"ctl00$txtbackwords_0", //
		"hq_01_Current_Ctrl$SignIdea"
	};
	
	//（处室收文）的（承办）环节执行（转承办）
	public static JSONObject do4ZcbTask(JSONObject params,ActionContext context){
		boolean flag = true;
		String msg = null;
		try {
			JSONObject pageState = (JSONObject)params.get("pageState");
			String task = params.getString("task");
			Map<String, String> state = new HashMap<String, String>();
			
			for (String key : DO4ZCBPARAMS) {
				state.put(key, pageState.getString(key));
			}
			ActionResult ar = Task4CbPage.doZcbTask(task, CookiesUtils.getCookies(context,COOKIE_ID), state);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		return result; 
	}
	
	private static final String[] DO4CSSBPARAMS = new String[]{
		"__VIEWSTATE",
		"__VIEWSTATEGENERATOR",
		"__EVENTVALIDATION",         
		"ctl00$backwords_0",            
		"ctl00$txtforward_0",
		"ctl00$txtbackwords_0", //
		"hq_01_Current_Ctrl$SignIdea"
	};
	
	//（处室收文）的（承办）环节执行（处室送办）
	public static JSONObject do4CssbTask(JSONObject params,ActionContext context){
		boolean flag = true;
		String msg = null;
		try {
			JSONObject pageState = (JSONObject)params.get("pageState");
			String task = params.getString("task");
			Map<String, String> state = new HashMap<String, String>();
			
			for (String key : DO4CSSBPARAMS) {
				state.put(key, pageState.getString(key));
			}
			ActionResult ar = Task4CbPage.doCssbTask(task, CookiesUtils.getCookies(context,COOKIE_ID), state);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		return result; 
	}
	
	private static final String[] DO1BGSNBPARAMS = new String[]{
		"__VIEWSTATE",
		"__VIEWSTATEGENERATOR",
		"__EVENTVALIDATION",
		"ctl00$forward_0",
		"ctl00$txtforward_0",
		"ctl00$txtforward_1",
		"ctl00$txtforward_2",
		"ctl00$txtfinish_0",
		"ctl00$txtdistributecompany_0",
		"ctl00$txtsave_0",
		"ctl00$txtstop_0",
		"ctl00$txtprint_0"
	};
	
	
	//（中心收文）的（办公室登记）环节执行（办公室拟办）
	public static JSONObject do1BgsnbTask(JSONObject params,ActionContext context){
		boolean flag = true;
		String msg = null;
		try {
			JSONObject pageState = (JSONObject)params.get("pageState");
			String task = params.getString("task");
			Map<String, String> state = new HashMap<String, String>();
			
			for (String key : DO1BGSNBPARAMS) {
				state.put(key, pageState.getString(key));
			}
			System.out.println("111");
			ActionResult ar = Task1BgsdjPage.doCssbTask(task, CookiesUtils.getCookies(context,COOKIE_ID), state);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		System.out.println("222");
		return result; 
	}
	
	private static final String[] DO1ZXLDPSPARAMS = new String[]{
		"__VIEWSTATE",
		"__VIEWSTATEGENERATOR",
		"__EVENTVALIDATION",
		"ctl00$forward_1",
		"ctl00$txtforward_0",
		"ctl00$txtforward_1",
		"ctl00$txtforward_2",
		"ctl00$txtfinish_0",
		"ctl00$txtdistributecompany_0",
		"ctl00$txtsave_0",
		"ctl00$txtstop_0",
		"ctl00$txtprint_0"
	};
	
	//（中心收文）的（办公室登记）环节执行（中心领导批示）
	public static JSONObject do1ZxldpsTask(JSONObject params,ActionContext context){
		boolean flag = true;
		String msg = null;
		try {
			JSONObject pageState = (JSONObject)params.get("pageState");
			String task = params.getString("task");
			Map<String, String> state = new HashMap<String, String>();
			
			for (String key : DO1ZXLDPSPARAMS) {
				state.put(key, pageState.getString(key));
			}
			ActionResult ar = Task1BgsdjPage.doZxldpsTask(task, CookiesUtils.getCookies(context,COOKIE_ID), state);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		return result; 
	}
	
	private static final String[] DO1BGSCBPARAMS = new String[]{
		"__VIEWSTATE",
		"__VIEWSTATEGENERATOR",
		"__EVENTVALIDATION",
		"ctl00$forward_2",
		"ctl00$txtforward_0",
		"ctl00$txtforward_1",
		"ctl00$txtforward_2",
		"ctl00$txtfinish_0",
		"ctl00$txtdistributecompany_0",
		"ctl00$txtsave_0",
		"ctl00$txtstop_0",
		"ctl00$txtprint_0",
		"Register_00_Current_Ctrl$WordMarkNo",
		"Register_00_Current_Ctrl$DraftUnit",
		"Register_00_Current_Ctrl$RegisterDisplayName",
		"Register_00_Current_Ctrl$RegisterPhoneNo",
		"Register_00_Current_Ctrl$ReceiveDate",
		"Register_00_Current_Ctrl$SourceType",
		"Register_00_Current_Ctrl$SecretLevel",
		"Register_00_Current_Ctrl$SecretLimit",
		"Register_00_Current_Ctrl$UrgentLevel",
		"Register_00_Current_Ctrl$CarrierType",
		"Register_00_Current_Ctrl$ReceiveFileNo",
		"Register_00_Current_Ctrl$CreateDate",
		"Register_00_Current_Ctrl$Amount",
		"Register_00_Current_Ctrl$ReceiveType",
		"Register_00_Current_Ctrl$FileTitle",
		"Register_00_Current_Ctrl$Topic",
		"Register_00_Current_Ctrl$GiveMainUnit",
		"Register_00_Current_Ctrl$GiveCopyUnit",
		"Register_00_Current_Ctrl$Archive",
		"Register_00_Current_Ctrl$TimeLimit",
		"Register_00_Current_Ctrl$Issue",
		"Register_00_Current_Ctrl$ChannelDirectory",
		"Register_00_Current_Ctrl$RegisterDeptID",
		"Register_00_Current_Ctrl$RegisterDept",
		"Register_00_Current_Ctrl$Register",
		"Register_00_Current_Ctrl$GiveMainUnitID",
		"Register_00_Current_Ctrl$GiveCopyUnitID",
		"Register_00_Current_Ctrl$ReceiveTime",
		"Register_00_Current_Ctrl$CreateTime",
		"Register_00_Current_Ctrl$DocID",
		"Register_00_Current_Ctrl$DocWebService",
		"Register_00_Current_Ctrl$Accessory",
		"Register_00_Current_Ctrl$HeadTemplate",
		"Register_00_Current_Ctrl$DrafterIncID",
		"Register_00_Current_Ctrl$DrafterIncName",
		"Register_00_Current_Ctrl$DrafterDeptID",
		"Register_00_Current_Ctrl$DrafterDeptName",
		"Register_00_Current_Ctrl$ReceiveRemark"
	};
	
	//（中心收文）的（办公室登记）环节执行（办公室承办）
	public static JSONObject do1BgscbTask(JSONObject params,ActionContext context){
		boolean flag = true;
		String msg = null;
		try {
			JSONObject pageState = (JSONObject)params.get("pageState");
			String task = params.getString("task");
			Map<String, String> state = new HashMap<String, String>();
			
			for (String key : DO1BGSCBPARAMS) {
				state.put(key, pageState.getString(key));
			}
			ActionResult ar = Task1BgsdjPage.doBgscbpsTask(task, CookiesUtils.getCookies(context,COOKIE_ID), state);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		return result; 
	}
	
	private static final String[] DO1BJPARAMS = new String[]{
		"__VIEWSTATE",
		"__VIEWSTATEGENERATOR",
		"__EVENTVALIDATION",
		"ctl00$finish_0",
		"ctl00$txtforward_0",
		"ctl00$txtforward_1",
		"ctl00$txtforward_2",
		"ctl00$txtfinish_0",
		"ctl00$txtdistributecompany_0",
		"ctl00$txtsave_0",
		"ctl00$txtstop_0",
		"ctl00$txtprint_0"
	};
	
	//（中心收文）的（办公室登记）环节执行（办结）
	public static JSONObject do1BjTask(JSONObject params,ActionContext context){
		boolean flag = true;
		String msg = null;
		try {
			JSONObject pageState = (JSONObject)params.get("pageState");
			String task = params.getString("task");
			Map<String, String> state = new HashMap<String, String>();
			
			for (String key : DO1BJPARAMS) {
				state.put(key, pageState.getString(key));
			}
			ActionResult ar = Task1BgsdjPage.doBjTask(task, CookiesUtils.getCookies(context,COOKIE_ID), state);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		return result; 
	}
	
	private static final String[] DO1BCPARAMS = new String[]{
		"__VIEWSTATE",
		"__VIEWSTATEGENERATOR",
		"__EVENTVALIDATION",
		"ctl00$save_0",
		"ctl00$txtforward_0",
		"ctl00$txtforward_1",
		"ctl00$txtforward_2",
		"ctl00$txtfinish_0",
		"ctl00$txtdistributecompany_0",
		"ctl00$txtsave_0",
		"ctl00$txtstop_0",
		"ctl00$txtprint_0",
		"Register_00_Current_Ctrl$WordMarkNo",
		"Register_00_Current_Ctrl$DraftUnit",
		"Register_00_Current_Ctrl$RegisterDisplayName",
		"Register_00_Current_Ctrl$RegisterPhoneNo",
		"Register_00_Current_Ctrl$ReceiveDate",
		"Register_00_Current_Ctrl$SourceType",
		"Register_00_Current_Ctrl$SecretLevel",
		"Register_00_Current_Ctrl$SecretLimit",
		"Register_00_Current_Ctrl$UrgentLevel",
		"Register_00_Current_Ctrl$CarrierType",
		"Register_00_Current_Ctrl$ReceiveFileNo",
		"Register_00_Current_Ctrl$CreateDate",
		"Register_00_Current_Ctrl$Amount",
		"Register_00_Current_Ctrl$ReceiveType",
		"Register_00_Current_Ctrl$FileTitle",
		"Register_00_Current_Ctrl$Topic",
		"Register_00_Current_Ctrl$GiveMainUnit",
		"Register_00_Current_Ctrl$GiveCopyUnit",
		"Register_00_Current_Ctrl$Archive",
		"Register_00_Current_Ctrl$TimeLimit",
		"Register_00_Current_Ctrl$Issue",
		"Register_00_Current_Ctrl$ChannelDirectory",
		"Register_00_Current_Ctrl$RegisterDeptID",
		"Register_00_Current_Ctrl$RegisterDept",
		"Register_00_Current_Ctrl$Register",
		"Register_00_Current_Ctrl$GiveMainUnitID",
		"Register_00_Current_Ctrl$GiveCopyUnitID",
		"Register_00_Current_Ctrl$ReceiveTime",
		"Register_00_Current_Ctrl$CreateTime",
		"Register_00_Current_Ctrl$DocID",
		"Register_00_Current_Ctrl$DocWebService",
		"Register_00_Current_Ctrl$Accessory",
		"Register_00_Current_Ctrl$HeadTemplate",
		"Register_00_Current_Ctrl$DrafterIncID",
		"Register_00_Current_Ctrl$DrafterIncName",
		"Register_00_Current_Ctrl$DrafterDeptID",
		"Register_00_Current_Ctrl$DrafterDeptName",
		"Register_00_Current_Ctrl$ReceiveRemark"
	};
	
	//（中心收文）的（办公室登记）环节执行（办结）
	public static JSONObject do1BcTask(JSONObject params,ActionContext context){
		boolean flag = true;
		String msg = null;
		try {
			JSONObject pageState = (JSONObject)params.get("pageState");
			String task = params.getString("task");
			Map<String, String> state = new HashMap<String, String>();
			
			for (String key : DO1BCPARAMS) {
				state.put(key, pageState.getString(key));
			}
			ActionResult ar = Task1BgsdjPage.doBcTask(task, CookiesUtils.getCookies(context,COOKIE_ID), state);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		return result; 
	}
	
	//（中心收文）的（办公室登记）环节执行（传阅）
	public static JSONObject do1CyTask(JSONObject params,ActionContext context){
		boolean flag = true;
		String msg = null;
		try {
			String postData = params.getString("postData");
			
			Task1BgsdjPage.doCyTask(postData, CookiesUtils.getCookies(context,COOKIE_ID));
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		return result; 
	}
	
	private static final String[] DO1ZZGWPARAMS = new String[]{
		"__VIEWSTATE",
		"__VIEWSTATEGENERATOR",
		"__EVENTVALIDATION",
		"ctl00$stop_0",
		"ctl00$txtforward_0",
		"ctl00$txtforward_1",
		"ctl00$txtforward_2",
		"ctl00$txtfinish_0",
		"ctl00$txtdistributecompany_0",
		"ctl00$txtsave_0",
		"ctl00$txtstop_0",
		"ctl00$txtprint_0"
	};
	
	//（中心收文）的（办公室登记）环节执行（中止收文）
	public static JSONObject do1ZzgwTask(JSONObject params,ActionContext context){
		boolean flag = true;
		String msg = null;
		try {
			JSONObject pageState = (JSONObject)params.get("pageState");
			String task = params.getString("task");
			Map<String, String> state = new HashMap<String, String>();
			
			for (String key : DO1ZZGWPARAMS) {
				state.put(key, pageState.getString(key));
			}
			ActionResult ar = Task1BgsdjPage.doZzgwTask(task, CookiesUtils.getCookies(context,COOKIE_ID), state);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		return result; 
	}
	
	private static final String[] DO2BGSNBPARAMS = new String[]{
		"__VIEWSTATE",
		"__VIEWSTATEGENERATOR",
		"__EVENTVALIDATION",
		"ctl00$backwords_0",
		"ctl00$txtbackwords_0",
		"PreConfirm_00_Current_Ctrl$ReviewIdea"
	};
	
	//(中心收文)的（办公室拟办）环节执行（办公室登记）
	public static JSONObject do2BgsdjTask(JSONObject params,ActionContext context){
		boolean flag = true;
		String msg = null;
		try {
			JSONObject pageState = (JSONObject)params.get("pageState");
			String task = params.getString("task");
			Map<String, String> state = new HashMap<String, String>();
			
			for (String key : DO2BGSNBPARAMS) {
				state.put(key, pageState.getString(key));
			}
			ActionResult ar = Task2BgsnbPage.doBgsdjTask(task, CookiesUtils.getCookies(context,COOKIE_ID), state);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		return result; 
	}
	
	private static final String[] DO3ZXLDPSPARAMS = new String[]{
		"__VIEWSTATE",
		"__VIEWSTATEGENERATOR",
		"__EVENTVALIDATION",
		"ctl00$backwords_0",
		"ctl00$txtbackwords_0",
		"Confirm_01_Current_Ctrl$ReviewIdea"
	};
	
	//(中心收文)的（办公室拟办）环节执行（办公室登记）
	public static JSONObject do3BgsdjTask(JSONObject params,ActionContext context){
		boolean flag = true;
		String msg = null;
		try {
			JSONObject pageState = (JSONObject)params.get("pageState");
			String task = params.getString("task");
			Map<String, String> state = new HashMap<String, String>();
			
			for (String key : DO3ZXLDPSPARAMS) {
				state.put(key, pageState.getString(key));
			}
			ActionResult ar = Task3ZxldpsPage.doBgsdjTask(task, CookiesUtils.getCookies(context,COOKIE_ID), state);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		return result; 
	}
	
	private static final String[] DO4ZJLBDJPARAMS = new String[]{
		"__VIEWSTATE",
		"__VIEWSTATEGENERATOR",
		"__EVENTVALIDATION",
		"ctl00$backwords_0",
		"ctl00$txtforward_0",
		"ctl00$txtbackwords_0",
		"ReviewStart_01_Current_Ctrl$UsersID",
		"ReviewStart_01_Current_Ctrl$UsersName"
	};
	//(公司收文)的（送批示）环节执行（总经理办登记）
	public static JSONObject do4ZjlbdjTask(JSONObject params,ActionContext context){
		boolean flag = true;
		String msg = null;
		try {
			JSONObject pageState = (JSONObject)params.get("pageState");
			String task = params.getString("task");
			Map<String, String> state = new HashMap<String, String>();
			
			for (String key : DO4ZJLBDJPARAMS) {
				state.put(key, pageState.getString(key));
			}
			ActionResult ar = Task4SpsPage.doBgsdjTask(task, CookiesUtils.getCookies(context,COOKIE_ID), state);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		return result; 
	}
	private static final String[] DO4ZGSLDPSPARAMS = new String[]{
		"__VIEWSTATE",
		"__VIEWSTATEGENERATOR",
		"__EVENTVALIDATION",
		"ctl00$forward_0",
		"ctl00$txtforward_0",
		"ctl00$txtbackwords_0",
		"ReviewStart_01_Current_Ctrl$UsersID",
		"ReviewStart_01_Current_Ctrl$UsersName"
	};
	
	//转公司领导批示
	public static JSONObject do4zgsldpsTask(JSONObject params,ActionContext context){
		boolean flag = true;
		String msg = null;
		try {
			JSONObject pageState = (JSONObject)params.get("pageState");
			String task = params.getString("task");
			Map<String, String> state = new HashMap<String, String>();
			
			for (String key : DO4ZGSLDPSPARAMS) {
				state.put(key, pageState.getString(key));
			}
			ActionResult ar = Task4SpsPage.doZgsldpsTask(task, CookiesUtils.getCookies(context,COOKIE_ID), state);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		return result; 
	}
	
}
