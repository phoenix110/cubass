package mobiAppPlat.oa.app.contractapprove;

import java.util.Map;

import org.apache.commons.httpclient.HttpClient;

import forNet.net.ReqObj;
import forNet.net.RespObj;
import forNet.net.SslNetServer;
import forNet.net.pages.ActionResult;
import forNet.net.util.Utils;

public class TaskListPage {
	 /**
     * 获取待办任务
     */
	public static ActionResult load(HttpClient httpClient,Map<String, String> cookies,String url){
		ActionResult ar = new ActionResult(true, "");
		ReqObj req = new ReqObj();
		//req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept", "image/jpeg, application/x-ms-application, image/gif, application/xaml+xml, image/pjpeg, application/x-ms-xbap, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*");
		req.addHeader("Accept-Encoding", "gzip, deflate"); //不压缩
		req.addHeader("Accept-Language", "zh-CN,zh;q=0.8");
		//req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		//req.addHeader("Pragma", "no-cache");
		req.addHeader("Referer", "https://cms.petrochina/CMSProduction/Default.aspx");
		//req.addHeader("Upgrade-Insecure-Requests", "1");
		req.addHeader("Host", "cms.petrochina");
		req.addHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/4.0; chromeframe/30.0.1599.69; EmbeddedWB 14.52 from: http://www.bsalsa.com/ EmbeddedWB 14.52; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET CLR 1.1.4322; InfoPath.2; .NET4.0C; .NET4.0E)");
		req.setMethod("get");
		System.out.println(url);
		req.setUrl(url);
		RespObj tasks = SslNetServer.service(httpClient,req, new TaskListPageCallback());
		//RespObj tasks = SslNetServer.doGet(req, new TaskListPageCallback());
		ar.addCookies(tasks.getCookies());
		ar.setData(tasks.getResponseBody());
		return ar;
	}
	
}
