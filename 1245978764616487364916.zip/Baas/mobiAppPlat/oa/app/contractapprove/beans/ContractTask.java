/**
 * 
 */
package mobiAppPlat.oa.app.contractapprove.beans;

/**
 * 合同代办任务
 * @author luofei
 *
 */
public class ContractTask {
	/**
	 * 名称
	 */
	private String name;
	/**
	 *详细页面url
	 */
	private String detailUrl;
	/**
	 * 模块
	 */
	private String moduleName;
	/**
	 * 流程名
	 */
	private String flowName;
	/**
	 * 任务名
	 */
	private String taskName;
	/**
	 * 状态名
	 */
	private String statusName;
	/**
	 * 分配时间
	 */
	private String createTime;
	/**
	 * 承办部门
	 */
	private String deptName;
	/**
	 * 承办人
	 */
	private String userName;
	/**
	 * 委托人
	 */
	private String deputeName;
	/**
	 * 有效状态
	 */
	private String validStatus;
	/**
	 * 进展
	 */
	private String progress;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public String getFlowName() {
		return flowName;
	}
	public void setFlowName(String flowName) {
		this.flowName = flowName;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getStatusName() {
		return statusName;
	}
	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getDeputeName() {
		return deputeName;
	}
	public void setDeputeName(String deputeName) {
		this.deputeName = deputeName;
	}
	public String getValidStatus() {
		return validStatus;
	}
	public void setValidStatus(String validStatus) {
		this.validStatus = validStatus;
	}
	public String getProgress() {
		return progress;
	}
	public void setProgress(String progress) {
		this.progress = progress;
	}
	public String getDetailUrl() {
		return detailUrl;
	}
	public void setDetailUrl(String detailUrl) {
		this.detailUrl = detailUrl;
	}
	
	

}
