package mobiAppPlat.oa.utils;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.SimpleHttpConnectionManager;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.params.HttpClientParams;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import forNet.net.util.Utils;

public class ConfigUtil {

	private static Document document;
	private static Element orgKind;
	static {
		URL url = ConfigUtil.class.getClassLoader().getResource("oa.config.m");
		File file = new File(url.getFile());
		try {
			document = Jsoup.parse(file, "UTF-8");
			Elements orgKinds = document.select("[name=orgKind]");
			if (orgKinds.size() > 0) {
				orgKind = orgKinds.first();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static String getConfigValue(String itemName) {
		return document.select("[name=" + itemName + "]").val();
	}
	public static Element getItem(String configName) {
		return orgKind.select("[name=" + configName + "]").first();
	}

	public static Map<String, String> getLabels(String itemName) {
		Map<String, String> labelMap = new HashMap<String, String>();
		Element item = ConfigUtil.getItem(itemName);
		Elements labels = item.select("label");
		for (Element label : labels) {
			 labelMap.put(label.attr("language"), label.text());
		}
		return labelMap;
	}
	

	public static InputStream getImageStream(String imgUrl) {
		
		InputStream ins=null;
		try {
			//System.out.println("imgUrl:"+imgUrl);
			URL url = new URL(encodeUrl(imgUrl));
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setConnectTimeout(5 * 1000);
			conn.connect();
			ins = conn.getInputStream();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return ins;	
	}
	
	public static String encodeUrl(String url){
		
		 String name = url.substring(url.lastIndexOf("/")+1, url.length());
		  url=url.replace(name, "");
	     try {
			url=url+java.net.URLEncoder.encode(name,"UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		 url=url.replaceAll("\\+", "%20");
		 
		 System.out.println(url);
		 return url;
		
	}
	
public static InputStream getImageStreamNew(String imgUrl) {
		
		InputStream ins=null;
		try {
			imgUrl =java.net.URLDecoder.decode(imgUrl,"utf-8");
			System.out.println("imgUrl:"+imgUrl);
			HttpClient httpClient = new HttpClient(new HttpClientParams(), new SimpleHttpConnectionManager(true));
			HttpMethod httpMethod = new GetMethod(imgUrl);
			httpMethod.addRequestHeader("Accept", "Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
			httpMethod.addRequestHeader("Accept-Language", "zh-CN,zh;q=0.8");
			httpMethod.addRequestHeader("Cache-Control", "no-cache");
			httpMethod.addRequestHeader("Connection", "keep-alive");
			httpMethod.addRequestHeader("Pragma", "no-cache");
			httpMethod.addRequestHeader("Upgrade-Insecure-Requests", "1");
			httpMethod.addRequestHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.4 Safari/537.36");
			httpClient.executeMethod(httpMethod);
			ins = httpMethod.getResponseBodyAsStream();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return ins;	
	}

	
	
	
	
public static InputStream getImageStream(String imgUrl,Map<String, String> cookies) {
		
		InputStream ins=null;
		try {
			URL url = new URL(imgUrl);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.addRequestProperty("Cookie", Utils.map2String(cookies));
			conn.addRequestProperty("Accept", "image/jpeg, application/x-ms-application, image/gif, application/xaml+xml, image/pjpeg, application/x-ms-xbap, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*");
			conn.setRequestMethod("GET");
			conn.setConnectTimeout(5 * 1000);
			conn.connect();
			ins = conn.getInputStream();
			//conn.disconnect();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return ins;	
	}


public static InputStream getContractAttaStream(HttpClient httpClient,String imgUrl,Map<String, String> cookies) {
	InputStream ins=null;
	try {
		HttpMethod httpMethod = new GetMethod(imgUrl);
		httpClient.executeMethod(httpMethod);
		ins = httpMethod.getResponseBodyAsStream();
		httpMethod.releaseConnection();
	} catch (Exception e) {
		e.printStackTrace();
	}
	return ins;	
}
	

}
