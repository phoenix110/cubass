package admin.login.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import admin.utils.ADHelper;
import admin.utils.SystemInit;

import com.alibaba.fastjson.JSONObject;
import com.justep.baas.action.ActionContext;
import com.justep.baas.data.DataUtils;
import com.justep.baas.data.Row;
import com.justep.baas.data.Table;

public class DomainLogin implements ILoginStrategy {

	public JSONObject login(JSONObject params, ActionContext context) {
		JSONObject jsonObj = new JSONObject();
		String loginName = params.getString("loginName");
		String password = params.getString("password");
		String uuid = params.getString("uuid") == null ? "" : params.getString("uuid");
		String client = params.getString("client");
		if ("1".equals(SystemInit.sysConfig.get("device_serial_validate")) && "mobile".equals(client)) {
			// 验证窜码的正确性
			Connection conn = null;
			try {
				conn = context.getConnection(SystemInit.sysConfig.get("dsSys"));
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (NamingException e) {
				e.printStackTrace();
			}
			List<Object> sqlParams = new ArrayList<Object>();
			sqlParams.add(loginName);
			Table table = DataUtils.queryData(conn, "select sDeviceSerialNo from sa_opperson where sLoginName=?", sqlParams, null, null, null);
			if (table.getRows().size() > 0) {
				Row row = table.getRows().get(0);
				if (!uuid.equals(row.getString("sDeviceSerialNo"))) {
					jsonObj.put("msg", 2);
					jsonObj.put("adminTel", SystemInit.sysConfig.get("admin_tel"));
					jsonObj.put("uuid", uuid);
				}
			}
		}
		// 如果串码验证通过，则验证域账号的正确性
		if (2 != jsonObj.getIntValue("msg")) {
			int loginFlag = ADHelper.connect(SystemInit.sysConfig.get("domainIp"), SystemInit.sysConfig.get("domainPort"), loginName, password);
			jsonObj.put("msg", loginFlag);
		}
		return jsonObj;
	}

}
