package forNet.net.pages;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TestEngine {
	//txtLogin              ptr\dg_liuqing18                                                  
	//txtPassword           lq0511                                                            
	public static void main(String[] args){
		/*
		Map<String, String> cookies = new HashMap<String, String>();
		
		ActionResult ar = LoginPage.login("ptr\\laijs", "lq0511");
		System.out.println("flag: " + ar.isFlag() + ", data: " + ar.getData());
		if (ar.isFlag()){
			cookies.putAll(ar.getCookies());
			ActionResult tasksResult = TaskListPage.load(cookies);
			if (tasksResult.isFlag()){
				cookies.putAll(tasksResult.getCookies());
				List<Task> tasks = (List<Task>)tasksResult.getData();
				System.out.println(tasks);
				if (tasks.size() > 0){
					Task task = tasks.get(0);
					ActionResult loadTaskAr = TaskPage.load(task.id, task.type, task.status, cookies);
					if (loadTaskAr.isFlag()){
						cookies.putAll(loadTaskAr.getCookies());
						//TaskPage.doTask("同意", cookies);
						Map<String, Object> data = (Map<String, Object>)loadTaskAr.getData();
						Map<String, String> params = (Map<String, String>)data.get("pageState");
						System.out.println(params);
						TaskPage.doTask(task.id, "--同意", cookies, params);
					}
				}
			}
		}*/
		
	}

}
