/**
 * 
 */
package mobiAppPlat.oa.app.contractapprove;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import mobiAppPlat.oa.utils.ConfigUtil;

import org.apache.commons.httpclient.HttpClient;

import forNet.net.ReqObj;
import forNet.net.RespObj;
import forNet.net.SslNetServer;
import forNet.net.pages.ActionResult;
import forNet.net.util.CookiesUtils;
import forNet.net.util.Utils;

/**
 * @author luofei
 * 
 */
public class LoginPage {

	
	private String loginUrl;

	public LoginPage(String loginUrl) {
		this.loginUrl = loginUrl;
	}
    /**
     * 登录
     */
	public  ActionResult login(HttpClient httpClient,Map<String,String> params){
		ActionResult ar = new ActionResult(true, "");
		try{
			
			Map<String, String> cookies = new HashMap<String, String>();
			RespObj getLoginPageResult = getLoginPage(httpClient);
			cookies.putAll(getLoginPageResult.getCookies());
			
			RespObj loginResult = doLogin(httpClient,params, cookies, (Map<String, String>)getLoginPageResult.getResponseBody());
			cookies.putAll(loginResult.getCookies());
			
			ar.addCookies(cookies);
			RespObj indexResult = getIndexPage(httpClient,cookies);
			cookies.putAll(indexResult.getCookies());
			
			Map<String, String> data = (Map<String, String>)indexResult.getResponseBody();
			if (!"true".equals(data.get("flag"))){
				ar.setFlag(false);
				ar.setData( data.get("msg")) ;
			}else{
				ar.addCookies(cookies);
			}

		}catch(Exception e){
			e.printStackTrace();
			ar.setFlag(false);
			ar.setData(e.getMessage()) ;
			
		}
		
		return ar;
	}
	 /**
     * 获取登录页
     */
	public RespObj getLoginPage(HttpClient httpClient) {
		ReqObj req = new ReqObj();
		req.addHeader("Accept", "Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		// req.addHeader("Accept-Encoding", "gzip, deflate, sdch"); //不压缩
		req.addHeader("Accept-Language", "zh-CN,zh;q=0.8");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		req.addHeader("Pragma", "no-cache");
		req.addHeader("Upgrade-Insecure-Requests", "1");
		req.addHeader("Host", "cms.petrochina");
		req.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.4 Safari/537.36");
		req.setMethod("get");
		req.setUrl("https://cms.petrochina/CMSProduction/Login/Login.aspx?ReturnUrl=%2fCMSProduction%2fDefault.aspx");
		RespObj result = SslNetServer.service(httpClient,req, new LoginPageGetLoginCallBack());
		//RespObj result = SslNetServer.doGet(req, new LoginPageGetLoginCallBack());
		return result;
	}
	
	
	 /**
     * 获取首页
     */
	private  RespObj getIndexPage(HttpClient httpClient,Map<String, String> cookies){
		ReqObj req = new ReqObj();
		req.addHeader("Cookie", Utils.map2String(cookies));
		//req.addHeader("Accept", "Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		//req.addHeader("Accept", "image/jpeg, application/x-ms-application, image/gif, application/xaml+xml, image/pjpeg, application/x-ms-xbap, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*");
		/*
		req.addHeader("Accept-Encoding", "gzip, deflate"); //不压缩
		req.addHeader("Accept-Language", "zh-CN,zh;q=0.8");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		//req.addHeader("Pragma", "no-cache");
		req.addHeader("Referer", "https://cms.petrochina/CMSProduction/Login/Login.aspx?ReturnUrl=/fCMSProduction/fDefault.aspx");
		//req.addHeader("Upgrade-Insecure-Requests", "1");
		req.addHeader("Host", "cms.petrochina");
		req.addHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/4.0; chromeframe/30.0.1599.69; EmbeddedWB 14.52 from: http://www.bsalsa.com/ EmbeddedWB 14.52; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET CLR 1.1.4322; InfoPath.2; .NET4.0C; .NET4.0E)");
		*/
		req.setMethod("get");
		req.setUrl("https://cms.petrochina/CMSProduction/Default.aspx");
		
		RespObj result = SslNetServer.service(httpClient,req, new LoginPageGetIndexCallback());
		//RespObj result = SslNetServer.doGet(req, new LoginPageGetIndexCallback());
		return result;
	}

	 /**
     * 进行登录
     */
	protected RespObj doLogin(HttpClient httpClient,Map<String, String> userParams, Map<String, String> cookies, Map<String, String> params) {
		
		ReqObj req = new ReqObj();
		//req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept", "application/x-ms-application, image/jpeg, application/xaml+xml, image/gif, image/pjpeg, application/x-ms-xbap, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*");
		req.addHeader("Accept-Encoding", "gzip, deflate");
		req.addHeader("Accept-Language", "zh-CN");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		req.addHeader("Referer", "https://cms.petrochina/CMSProduction/Login/Login.aspx?ReturnUrl=/CMSProduction/Default.aspx");
		req.addHeader("Content-Type", "application/x-www-form-urlencoded");
		req.addHeader("Host", "cms.petrochina");
		req.addHeader("DNT", "1");
		req.addHeader("Referer", this.loginUrl);
		req.addHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/4.0; chromeframe/30.0.1599.69; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.3)");
		req.setMethod("post");
		req.setUrl(this.loginUrl);
		
		if (params != null) {
			req.getParams().putAll(params);
		}

		Iterator<String> ir = userParams.keySet().iterator();
		while (ir.hasNext()) {
			
			String paramName = String.valueOf(ir.next());
			String paramValue = userParams.get(paramName);
			req.addParam(paramName, paramValue);
		}
		
		//System.out.println("登录参数:"+req.getParams());
		
		RespObj result = SslNetServer.service(httpClient,req, new LoginPageDoLoginCallback());
		//RespObj result = SslNetServer.doGet(req, new LoginPageDoLoginCallback());
		return result;
	}
	
	  public void testHttps(){
		
	  }
	
	
	public static void main(String[] args) {
		LoginPage LoginPage = new LoginPage("https://cms.petrochina/CMSProduction/Login/Login.aspx?ReturnUrl=%2fCMSProduction%2fDefault.aspx");
		Map<String, String> userParams = new HashMap<String, String>();
		userParams.put("LoginCtr1:Domain", "rbPetrochina");
		userParams.put("LoginCtr1:txtUserID", "ptr\\laijs");
		userParams.put("LoginCtr1:txtPassword", "1qaz2wsx");
		userParams.put("LoginCtr1:Login", "");
		userParams.put("LoginCtr1:hfRemainLoginTime", "");
		userParams.put("LoginCtr1:hfRemainLoginTimes", "");
		//InputStream ins = ConfigUtil.getContractAttaStream(httpClient,"https://cms.petrochina/CMSProduction/Common/DownloadViaFile.aspx?OULabel=025&WorkTypeID=7&FileID=2006019701&OPTF=1", null);

		
		//LoginPage.login(httpClient,userParams);
	}
	
}
