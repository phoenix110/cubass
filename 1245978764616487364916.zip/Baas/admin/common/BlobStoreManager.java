package admin.common;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.IOUtils;

import admin.utils.SystemConfigUtil;
import admin.utils.SystemInit;

import com.alibaba.fastjson.JSONObject;
import com.justep.baas.action.ActionContext;
import com.justep.baas.data.DataUtils;

/**
 * 文件存储管理器(存储在数据库中)
 * 
 * @author luofei
 * 
 */
public class BlobStoreManager {

	public static JSONObject service(JSONObject params, ActionContext context) throws ServletException, IOException, SQLException, NamingException {
		HttpServletRequest request = (HttpServletRequest) context.get(ActionContext.REQUEST);
		HttpServletResponse response = (HttpServletResponse) context.get(ActionContext.RESPONSE);
		doPost(request, response);
		return null;
	}

	public static JSONObject saveFile(JSONObject params, ActionContext context) throws ServletException, IOException, SQLException, NamingException {
		HttpServletRequest request = (HttpServletRequest) context.get(ActionContext.REQUEST);
		Connection conn = context.getConnection(SystemInit.sysConfig.get("dsSys"));
		// 表名
		String tableName = params.getString("tableName");
		// 字段名
		String columnName = params.getString("columnName");
		// id字段名
		String idColumnName = params.getString("idColumnName");
		// id字段值
		String idColumnValue = params.getString("idColumnValue");
		//文件
		String file=(String)request.getSession().getAttribute("file");
		byte[] bt = null;
		sun.misc.BASE64Decoder decoder = new sun.misc.BASE64Decoder();  
		bt = decoder.decodeBuffer(file);
		String updateSql = "update " + tableName + " set " + columnName + "=? where " + idColumnName + "=?";
		ByteArrayInputStream ins = new ByteArrayInputStream(bt);
		PreparedStatement stmt = conn.prepareStatement(updateSql);
		stmt.setBinaryStream(1,new ByteArrayInputStream(bt),ins.available());
		stmt.setString(2, idColumnValue);
		stmt.execute();
		request.getSession().removeAttribute("file");
		return null;
	}
	
	public static JSONObject getFileFromMem(JSONObject params, ActionContext context) throws ServletException, IOException, SQLException, NamingException {
		HttpServletRequest request = (HttpServletRequest) context.get(ActionContext.REQUEST);
		HttpServletResponse response = (HttpServletResponse) context.get(ActionContext.RESPONSE);
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("file", request.getSession().getAttribute("file"));
		DataUtils.writeJsonToResponse(response, jsonObj);
		return null;
	}
	public static JSONObject getFile(JSONObject params, ActionContext context) throws ServletException, IOException, SQLException, NamingException {
		HttpServletResponse response = (HttpServletResponse) context.get(ActionContext.RESPONSE);
		HttpServletRequest request = (HttpServletRequest) context.get(ActionContext.REQUEST);
		String ds = SystemConfigUtil.getConfigValue("ds.admin");
		Connection conn = context.getConnection(ds);
		// 表名
		String tableName = params.getString("tableName");
		// 字段名
		String columnName = params.getString("columnName");
		// 字段名
		String idColumnName = params.getString("idColumnName");
		// 字段名
		String idColumnValue = params.getString("idColumnValue");

		String selectSql = "select " + columnName + " from " + tableName + " where " + idColumnName + "=?";
		PreparedStatement stmt = conn.prepareStatement(selectSql);
		stmt.setString(1, idColumnValue);
		ResultSet rs = stmt.executeQuery();
		InputStream fis = null;
		while (rs.next()) {
			fis = rs.getBinaryStream(1);
		}
		sun.misc.BASE64Encoder encoder = new sun.misc.BASE64Encoder();  
		byte[] textByte=null;
		if (fis != null) {
			textByte = new byte[fis.available()];
			fis.read(textByte);
			fis.close();
		}
		JSONObject jsonObj = new JSONObject();
		String base64="";
		if(textByte==null){
			jsonObj.put("file", "");
		}else{
			base64=encoder.encode(textByte);
			jsonObj.put("file", encoder.encode(textByte));
		}
		request.getSession().setAttribute("file", base64);
		DataUtils.writeJsonToResponse(response, jsonObj);
		return null;
	}


	/**
	 * post为上传
	 **/
	protected static void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String contentType = request.getContentType();
		String file ="";
		try {
			if ("application/octet-stream".equals(contentType)) {
				storeOctStreamFile(request, response);
			} else if (contentType != null && contentType.startsWith("multipart/")) {
				file = storeFile(request, response);
			} else {
				throw new RuntimeException("not supported contentType");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new IOException("storeFile异常");
		}
		request.getSession().setAttribute("file", file);
		response.getWriter().write("");
	}

	private static void storeOctStreamFile(HttpServletRequest request, HttpServletResponse response) throws IOException, SQLException {
		InputStream in = null;
		FileOutputStream storeStream = null;
		try {
			
		} finally {
			IOUtils.closeQuietly(in);
			IOUtils.closeQuietly(storeStream);
		}
	}

	public static List<FileItem> parseMultipartRequest(HttpServletRequest request) throws FileUploadException {
		DiskFileItemFactory factory = new DiskFileItemFactory();
		ServletContext servletContext = request.getSession().getServletContext();
		File repository = (File) servletContext.getAttribute("javax.servlet.context.tempdir");
		factory.setRepository(repository);
		ServletFileUpload upload = new ServletFileUpload(factory);
		@SuppressWarnings("unchecked")
		List<FileItem> items = upload.parseRequest(request);
		return items;
	}

	private static String storeFile(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HashMap<String, String> params = new HashMap<String, String>();
		List<FileItem> items = parseMultipartRequest(request);
		Iterator<FileItem> iter = items.iterator();
		FileItem fileItem = null;
		while (iter.hasNext()) {
			FileItem item = iter.next();
			if (item.isFormField()) {
				String name = item.getFieldName();
				String value = item.getString();
				params.put(name, value);
			} else {
				fileItem = item;
			}
		}
		sun.misc.BASE64Encoder encoder = new sun.misc.BASE64Encoder();  
		byte[] textByte=null;
		if (fileItem != null) {
			InputStream is = fileItem.getInputStream();
			textByte = new byte[is.available()];
			is.read(textByte);
			is.close();
		}
		return encoder.encode(textByte);

	}
}
