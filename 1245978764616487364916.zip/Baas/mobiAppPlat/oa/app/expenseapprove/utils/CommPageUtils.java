package mobiAppPlat.oa.app.expenseapprove.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import mobiAppPlat.oa.app.expenseapprove.beans.CommExpense;
import mobiAppPlat.oa.app.expenseapprove.beans.TravelExpense;
import mobiAppPlat.oa.system.OASystemInit;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class CommPageUtils {

	// 获取基本信息
	public static void getBaseInfo(Document doc, CommExpense commExpense) {
		
		Map<String, String> valueMap = new HashMap<String, String>();
		//标题
		valueMap.put("lTitle", doc.getElementById("lTitle").html());
		//单据编号
		valueMap.put("lSheetCode", doc.getElementById("lSheetCode").html()); 
		//事由
		valueMap.put("lblTitle",    doc.getElementById("lblTitle").html());
		//备注
		valueMap.put("lRemark", doc.getElementById("lRemark").html());
		//附件张数
		valueMap.put("lAttachmentCount", doc.getElementById("lAttachmentCount").html());
		//总计金额
		valueMap.put("lTotalSum", doc.getElementById("lTotalSum").html());
		//实际支付金额
		valueMap.put("lLastestSum", doc.getElementById("lLastestSum").html());
		//所属预算
		valueMap.put("lBudgetName", doc.getElementById("BT1_lBudgetName").html());
		
		commExpense.setBaseInfo(valueMap);
	}


	//获取附件信息
	public static void getAttaDetail(Document doc, CommExpense commExpense) {
		List<Map<String, String>> dataList = new ArrayList<Map<String, String>>();
		int i = 0;
		for (Element data : doc.getElementsByAttributeValueContaining("id", "lSeriesNum")) {
			Map<String, String> valueMap = new HashMap<String, String>();
			String start = "CS1_rptUpperFiles_ctl0" + i + "_";
			//序号
			valueMap.put("lSeriesNum", data.html());
			//备注
			valueMap.put("lRemark", doc.getElementById(start + "lRemark").html());
			Element a = doc.getElementById(start + "hlkNavigator");
			valueMap.put("attaName",a.html());
			valueMap.put("attaNameHtml","<a>"+a.html()+"</a>");
			valueMap.put("attaUrl", OASystemInit.sysConfig.get("expenseBaseUrl")+"/expense"+ a.attr("href").replace("../", "/"));
			dataList.add(valueMap);
			i++;
		}
		commExpense.setAttaDetail(dataList);
	}
	
	

	// 获取单据明细
	public static void getListDetail(Document doc, CommExpense commExpense) {
		List<Map<String, String>> dataList = new ArrayList<Map<String, String>>();
		int i = 0;
		for (Element data : doc.getElementsByAttributeValueEnding("id", "lExpenseType")) {
			Map<String, String> valueMap = new HashMap<String, String>();
			String start = "CS1_rptOther_ctl0" + i + "_";
			valueMap.put("lSeriesNo", doc.getElementById(start + "lSeriesNo").html());
			valueMap.put("lExpenseType", data.html());
			valueMap.put("lPrice", doc.getElementById(start + "lPrice").html());
			valueMap.put("lBillAmount", doc.getElementById(start + "lBillAmount").html());
			valueMap.put("lSum", doc.getElementById(start + "lSum").html());
			valueMap.put("lDetailRemark", doc.getElementById(start + "lDetailRemark").html());
			valueMap.put("lIsDenied", doc.getElementById(start + "lIsDenied").html());
			valueMap.put("lApproveSum", doc.getElementById(start + "lApproveSum").html());
			valueMap.put("lBillAmountCanceled", doc.getElementById(start + "lBillAmountCanceled").html());
			valueMap.put("lAmountCanceled", doc.getElementById(start + "lAmountCanceled").html());
			valueMap.put("lValueAddedTaxApprove", doc.getElementById(start + "lValueAddedTaxApprove").html());
			valueMap.put("lRemarkCanceled", doc.getElementById(start + "lRemarkCanceled").html());
			dataList.add(valueMap);
			i++;
		}
		commExpense.setListDetail(dataList);
	}

	// 获取审批信息
	public static void getReviewIdea(Document doc, CommExpense commExpense) {
		List<Map<String, String>> dataList = new ArrayList<Map<String, String>>();
		Element element = doc.getElementById("CtrHistoryComments1_GridHistoryComments");
		for (Element tr : element.getElementsByTag("tr")) {
			Map<String, String> valueMap = new HashMap<String, String>();
			int i = 0;
			for (Element td : tr.getElementsByTag("td")) {
				if (i == 0) {
					valueMap.put("txtBussApplyName", td.html());
				} else if (i == 1) {
					valueMap.put("txtBussApplyUserName", td.getElementsByTag("a").html());
				} else if (i == 2) {
					valueMap.put("txtBussApplyResult", "&nbsp;".equals(td.html()) ? "" : td.html());
				} else if (i == 3) {
					valueMap.put("txtBussApplyIdea", "&nbsp;".equals(td.html()) ? "" : td.html());
				} else if (i == 4) {
					valueMap.put("txtBussApplyTime", td.html());
				}
				i++;
			}
			dataList.add(valueMap);
		}
		commExpense.setReviewIdea(dataList);
	}

	// 获取POST信息
		public static void getPostInfo(Document doc, CommExpense commExpense) {
			Map<String, String> paramMap = new HashMap<String, String>();
			Element form = doc.getElementById("aspnetForm");
			for (Element element : form.getElementsByTag("input")) {
				if("submit".equals(element.attr("type"))||"image".equals(element.attr("type"))){
					continue;
				}
				if(element.attr("name").indexOf("btn")<0 &&!"disabled".equals(element.attr("disabled"))){
					if("checkbox".equals(element.attr("type"))){
						if("checked".equals(element.attr("checked"))){
							paramMap.put(element.attr("name"), "on");
						}
					}else{
						paramMap.put(element.attr("name"), element.attr("value"));
					}
				}
				
			}
			// select
			for (Element element : form.getElementsByTag("select")) {
				Elements options = element.children();
				if(!"disabled".equals(element.attr("disabled"))){
					for (Element option : options) {
						int i=0;
						if ("selected".equals(option.attr("selected"))) {
							paramMap.put(element.attr("name"), option.attr("value"));
							break;
						}else{
							if(i==0){
								paramMap.put(element.attr("name"), option.attr("value"));
								//break;
							}
							
						}
						i++;
					}
				}
			
			}
			// textarea
			for (Element element : form.getElementsByTag("textarea")) {
				if(element.attr("name").indexOf("btn")<0){
					paramMap.put(element.attr("name"), element.text());
				}
				//paramMap.put(element.attr("name"), element.text());
			}
			
			paramMap.put("txtSubmitTimes", "1");
			paramMap.remove("");
		
		   // paramMap.remove("BtnReturn");
		/*
		paramMap.remove("btnAgree");
		paramMap.remove("btnDisagree");
		paramMap.remove("btnDelete2");
		paramMap.remove("btnDelete1");
		
		paramMap.remove("btnPrev");
		paramMap.remove("btnModify");
		paramMap.remove("btnNext");
		paramMap.remove("btnAgreeAndAddActivity");
		paramMap.remove("BtnReturn");
		paramMap.remove("btnSave");
		//paramMap.remove("BtnReturn");*/
		System.out.println("postparam:"+paramMap);
		commExpense.setPostParams(paramMap);
	}

}
