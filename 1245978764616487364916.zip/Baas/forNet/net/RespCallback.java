package forNet.net;

import java.io.InputStream;

public interface RespCallback {
	public Object execute(InputStream body);
}
