package mobiAppPlat.oa.app.expenseapprove.beans;

import java.util.List;
import java.util.Map;

/**
 * 
 * @author luofei
 * 
 */
public class TravelExpense {

	/**
	 * 基本信息
	 */
	private Map<String, String> baseInfo;

	/**
	 * 出差人员
	 */
	private List<Map<String, String>> expenseUser;
	/**
	 * 住宿费
	 */
	private  List<Map<String, String>> hotelExpense;
	/**
	 * 交通费
	 */
	private List<Map<String, String>> trafficExpense;

	/**
	 * 其他费用
	 */
	private List<Map<String, String>> otherExpense;

	
	/**
	 * 补助费用
	 */
	private List<Map<String, String>> supplyExpense;
	
	/**
	 * 总计金额
	 */
	private List<Map<String, String>> totalExpense;

	/**
	 * 历史审批意见
	 */
	private List<Map<String, String>> ReviewIdea;


	/**
	 * 请求参数
	 */
	private Map<String, String> postParams;

	/**
	 * 请求地址
	 */
	private String postUrl;
	
	
	

	public Map<String, String> getPostParams() {
		return postParams;
	}

	public void setPostParams(Map<String, String> postParams) {
		this.postParams = postParams;
	}

	public String getPostUrl() {
		return postUrl;
	}

	public void setPostUrl(String postUrl) {
		this.postUrl = postUrl;
	}

	public List<Map<String, String>> getExpenseUser() {
		return expenseUser;
	}

	public void setExpenseUser(List<Map<String, String>> expenseUser) {
		this.expenseUser = expenseUser;
	}

	public List<Map<String, String>> getOtherExpense() {
		return otherExpense;
	}

	public void setOtherExpense(List<Map<String, String>> otherExpense) {
		this.otherExpense = otherExpense;
	}

	public List<Map<String, String>> getSupplyExpense() {
		return supplyExpense;
	}

	public void setSupplyExpense(List<Map<String, String>> supplyExpense) {
		this.supplyExpense = supplyExpense;
	}

	public Map<String, String> getBaseInfo() {
		return baseInfo;
	}

	public void setBaseInfo(Map<String, String> baseInfo) {
		this.baseInfo = baseInfo;
	}

	public List<Map<String, String>> getTotalExpense() {
		return totalExpense;
	}

	public void setTotalExpense(List<Map<String, String>> totalExpense) {
		this.totalExpense = totalExpense;
	}

	public List<Map<String, String>> getReviewIdea() {
		return ReviewIdea;
	}

	public void setReviewIdea(List<Map<String, String>> reviewIdea) {
		ReviewIdea = reviewIdea;
	}

	public List<Map<String, String>> getTrafficExpense() {
		return trafficExpense;
	}

	public void setTrafficExpense(List<Map<String, String>> trafficExpense) {
		this.trafficExpense = trafficExpense;
	}

	public List<Map<String, String>> getHotelExpense() {
		return hotelExpense;
	}

	public void setHotelExpense(List<Map<String, String>> hotelExpense) {
		this.hotelExpense = hotelExpense;
	}
}
