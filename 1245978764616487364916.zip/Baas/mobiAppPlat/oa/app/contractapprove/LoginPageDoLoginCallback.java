package mobiAppPlat.oa.app.contractapprove;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import forNet.net.HtmlParser;
import forNet.net.RespCallback;



public class LoginPageDoLoginCallback implements RespCallback {

	public Object execute(InputStream body) {
		Document doc = HtmlParser.parser(body, null);
		//System.out.println("doLogin:"+doc.html());
		String flag = "true";
		String msg = "";
		Map<String, String> result = new HashMap<String, String>();
		for (Element e : doc.getElementsByTag("a")){
			String href = e.attr("href");
			msg=href;
			/*
			if (href.endsWith("default.aspx")){
				flag = "true";
			}else{
				flag = "false";
				msg = "未知错误";
			}
			break;
			*/
		}
		result.put("flag", flag);
		result.put("msg", msg);
		return result;
	}

}
