package mobiAppPlat.oa.app.docapprove.center4.service;

import java.io.InputStream;

import mobiAppPlat.oa.app.docapprove.bean.HtmlParser;
import mobiAppPlat.oa.app.docapprove.bean.RespCallback;
import mobiAppPlat.oa.app.docapprove.service.CheckUserOnline;

import org.jsoup.nodes.Document;

public class Task4SpsPageDoTaskCallback  implements RespCallback {

	public Object execute(InputStream body) {
		Document doc = HtmlParser.parser(body, null);
		//System.out.println(doc.toString());
		CheckUserOnline.checkOnline(doc);

		return null;
	}

}