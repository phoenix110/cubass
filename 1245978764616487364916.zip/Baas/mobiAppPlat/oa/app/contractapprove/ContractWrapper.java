package mobiAppPlat.oa.app.contractapprove;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mobiAppPlat.oa.app.contractapprove.beans.ContractTask;
import mobiAppPlat.oa.system.OASystemInit;
import mobiAppPlat.oa.utils.ConfigUtil;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.SimpleHttpConnectionManager;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.params.HttpClientParams;
import org.apache.commons.httpclient.protocol.Protocol;
import org.apache.commons.httpclient.protocol.ProtocolSocketFactory;

import admin.utils.StringUtil;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.justep.baas.action.ActionContext;

import forNet.net.NetSecureProtocolSocketFactory;
import forNet.net.pages.ActionResult;
import forNet.net.util.CookiesUtils;

public class ContractWrapper {

	
	public static HttpClient httpClient = null;
	static {
		ProtocolSocketFactory fcty = new NetSecureProtocolSocketFactory();
		// ProtocolSocketFactory fcty = new SSLProtocolSocketFactory();
		Protocol.registerProtocol("https", new Protocol("https", fcty, 443));
		httpClient = new HttpClient(new HttpClientParams(), new SimpleHttpConnectionManager());
	}
	
	public static JSONObject login(JSONObject params, ActionContext context) {
		boolean flag = true;
		String msg = null;
		try {
			String username = params.getString("username");
			String password = params.getString("password");
			LoginPage loginPage = new LoginPage(ConfigUtil.getConfigValue("contractLoginUrl"));
			Map<String, String> userParams = new HashMap<String, String>();
			userParams.put("LoginCtr1:Domain", "rbPetrochina");
			userParams.put("LoginCtr1:txtUserID", username);
			userParams.put("LoginCtr1:txtPassword", password);
			userParams.put("LoginCtr1:Login", "");
			userParams.put("LoginCtr1:hfRemainLoginTime", "");
			userParams.put("LoginCtr1:hfRemainLoginTimes", "");
			
			
			
			ActionResult ar = loginPage.login(httpClient,userParams);
			if (!ar.isFlag()) {
				flag = false;
				msg = ar.getData() + "";
			} else {
				CookiesUtils.updateCookies(context, ar.getCookies());
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		return result;
	}

	public static JSONObject loadTasks(JSONObject params, ActionContext context) {
		
		HttpServletRequest request = (HttpServletRequest) context.get(ActionContext.REQUEST);
		HttpSession session = request.getSession(true);
		Map<String, String> cookies = CookiesUtils.getCookies(context);
		
		Object sessionUserName = session.getAttribute("userName");
		
		//如果cookies存在，就不在重新登录了
		if(StringUtil.isEmpty(cookies.get("myform"))){
			httpClient = new HttpClient(new HttpClientParams(), new SimpleHttpConnectionManager());
			JSONObject loginResult = login(params, context);
			if (!loginResult.getBoolean("flag")) {
				return loginResult;
			}
		}else if(!params.getString("username").equals(sessionUserName)){ //换了用户了，就再登录
			System.out.println("用户切换，重新登录......");
			httpClient = new HttpClient(new HttpClientParams(), new SimpleHttpConnectionManager());
			JSONObject loginResult = login(params, context);
			if (!loginResult.getBoolean("flag")) {
				return loginResult;
			}
		}
		session.setAttribute("userName", params.getString("username"));

		boolean flag = true;
		String msg = null;
		Object data = null;
		try {
			String taskListUrl = OASystemInit.sysConfig.get("contractTaskList");
			session.setAttribute("taskListUrl", taskListUrl);
			ActionResult ar = TaskListPage.load(httpClient, cookies, taskListUrl);
			if (!ar.isFlag()) {
				flag = false;
				msg = ar.getData() + "";
			} else {
				CookiesUtils.updateCookies(context, ar.getCookies());
				data = new JSONArray();
				List<ContractTask> tasks = (List<ContractTask>) ar.getData();
				for (ContractTask t : tasks) {
					((JSONArray) data).add(JSONObject.toJSON(t));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}

		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		result.put("data", data);
		return result;
	}

	public static JSONObject loadTask(JSONObject params, ActionContext context) {
		boolean flag = true;
		String msg = null;
		String taskUrl = params.getString("taskUrl");
		String module = params.getString("module");
		String progressUrl = params.getString("progressUrl");
		
		JSONObject result = new JSONObject();
		try {
			Map<String, String> cookies = CookiesUtils.getCookies(context);
			ActionResult ar = TaskPage.load(httpClient,taskUrl,module,cookies, context);
			if (!ar.isFlag()) {
				flag = false;
				msg = ar.getData() + "";
			} else {
				CookiesUtils.updateCookies(context, ar.getCookies());
				result = (JSONObject) JSONObject.toJSON(ar.getData());
				ActionResult auditResult = TaskPage.loadAuditInfo(httpClient,progressUrl,cookies, context);
				result.put("auditInfo", auditResult.getData());
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}

		result.put("flag", flag);
		result.put("msg", msg);
		
		System.out.println("contractInfo:"+result);

		return result;

	}

	public static JSONObject doTask(JSONObject params, ActionContext context) {
		HttpServletRequest request = (HttpServletRequest) context.get(ActionContext.REQUEST);
		HttpSession session = request.getSession(true);
		boolean flag = true;
		String msg = null;
		try {
			String taskUrl = params.getString("taskUrl");
			Map<String, String> postParam = null;
			ActionResult ar =null;
			if("1".equals(params.getString("operType"))){
				postParam=(Map<String, String>) session.getAttribute("postParam");
				postParam.put("ReviewAndApproval:btnOK", "审查通过");
				postParam.put("ReviewAndApproval:txtRemark", params.getString("txtRemark"));
				postParam.put("ReviewAndApproval:txtResultID", "0");
				postParam.put("ReviewAndApproval:FileUploadingMgt:txtFileNo", "");
				ar=TaskPage.doTask(taskUrl, CookiesUtils.getCookies(context), postParam);
			}else{
				postParam=TaskPage.getDoReturnPage(httpClient,taskUrl, CookiesUtils.getCookies(context));
				postParam.put("ReviewAndApproval:txtRemark", params.getString("txtRemark"));
				postParam.remove("msg");
				postParam.remove("flag");
				ar = TaskPage.doTask(taskUrl, CookiesUtils.getCookies(context), postParam);
				
			}
			if (!ar.isFlag()) {
				flag = false;
				msg = ar.getData() + "";
			} else {
				CookiesUtils.updateCookies(context, ar.getCookies());
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		return result;
	}
	
	/**
	 * 获取返回页面
	 * @param params
	 * @param context
	 * @return
	 */
	public static JSONObject loadReturnPage(JSONObject params, ActionContext context) {
		boolean flag = true;
		String msg = null;
		JSONObject result = new JSONObject();
		try {
			String taskUrl = params.getString("taskUrl");
			System.out.println("taskUrl:"+taskUrl);
			ActionResult ar = TaskPage.goReturnPage(httpClient,taskUrl, CookiesUtils.getCookies(context));
			if (!ar.isFlag()) {
				flag = false;
				msg = ar.getData() + "";
			} else {
				CookiesUtils.updateCookies(context, ar.getCookies());
				result = (JSONObject) JSONObject.toJSON(ar.getData());

			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		result.put("flag", flag);
		result.put("msg", msg);
		return result;
	}

	/**
	 * 获取图片流
	 * 
	 * @param params
	 * @param context
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws IOException
	 */
	public static JSONObject getImageStream(JSONObject params, ActionContext context) throws SQLException, NamingException, IOException {
		HttpServletResponse response = (HttpServletResponse) context.get(ActionContext.RESPONSE);
		String attaUrl = params.getString("attaUrl");
		String attaName = params.getString("attaName");
		attaName = java.net.URLDecoder.decode(attaName, "utf-8");
		attaUrl = java.net.URLDecoder.decode(attaUrl, "utf-8");
		
		HttpMethod httpMethod = new GetMethod(attaUrl);
		httpClient.executeMethod(httpMethod);
		InputStream ins  = httpMethod.getResponseBodyAsStream();
		
		// response.addHeader("Content-Type", "application/octet-stream");
		response.addHeader("Content-Disposition", "attachment; filename=\"" + java.net.URLEncoder.encode(attaName, "UTF-8")+".rar" + "\"");
		OutputStream out = response.getOutputStream();
		byte[] buffer = new byte[32768 * 8];
		try {
			int read;
			while ((read = ins.read(buffer)) != -1) {
				out.write(buffer, 0, read);
			}
		} finally {
			ins.close();
			out.close();
			httpMethod.releaseConnection();
		}
		return null;
	}
	
	public static void main(String[] args) throws Exception {
		Object sessionUserName ="luofei";
		System.out.println("luofei".equals(sessionUserName));
	}
	
	
}
