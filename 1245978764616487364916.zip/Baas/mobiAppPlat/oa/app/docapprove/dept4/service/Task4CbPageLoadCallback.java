package mobiAppPlat.oa.app.docapprove.dept4.service;

import java.io.InputStream;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import mobiAppPlat.oa.app.docapprove.bean.HtmlParser;
import mobiAppPlat.oa.app.docapprove.bean.RespCallback;
import mobiAppPlat.oa.app.docapprove.service.CheckUserOnline;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.justep.baas.data.ColumnValue;
import com.justep.baas.data.DataType;
import com.justep.baas.data.Row;
import com.justep.baas.data.RowState;
import com.justep.baas.data.Table;
import com.justep.baas.data.Transform;

public class Task4CbPageLoadCallback implements RespCallback{
	private static final String[] NAMES = new String[]{
		"__VIEWSTATE",
		"__VIEWSTATEGENERATOR",
		"__EVENTVALIDATION",         
		"ctl00$forward_0",            
		"ctl00$txtforward_0",
		"ctl00$txtbackwords_0", //
		"hq_01_Current_Ctrl$SignIdea",
		"ctl00$backwords_0"
		
	};
	
	
	
	public Object execute(InputStream body) {
		
		Document doc = HtmlParser.parser(body, null);
		CheckUserOnline.checkOnline(doc);
		
		Map<String, Object> result = new HashMap<String, Object>();
		Map<String, String> pageState = new HashMap<String, String>();
		result.put("pageState", pageState);
		for (String name : NAMES){
			Elements es = doc.getElementsByAttributeValue("name", name);
			if (es.size()>=1){
				String value = "";
				Element e = es.get(0);
				if (e.tagName().equals("textarea")){
					value = e.text();
				}else{
					value = es.get(0).attr("value");
				}
				
				pageState.put(name, value);
			}
		}
		
		
		//获取表单数据
		//文件编号
		pageState.put("WordMarkNos", getElementValueByMatching(doc,"name","^ctl.*\\$WordMarkNo$"));
		//收文日期
		pageState.put("ReceiveDate", getElementValueByMatching(doc, "name", "^ctl.*\\$ReceiveDate$"));
		//登记人
		pageState.put("RegisterDisplayName", getElementValueByMatching(doc, "name", "^ctl.*\\$RegisterDisplayName$"));
		//来文单位
		pageState.put("DraftUnit", getElementValueByMatching(doc, "name", "^ctl.*\\$DraftUnit$"));
		//收文编号
		pageState.put("ReceiveFileNo", getElementValueByMatching(doc, "name", "^ctl.*\\$ReceiveFileNo$"));
		//成文日期
		pageState.put("CreateDate", getElementValueByMatching(doc, "name", "^ctl.*\\$CreateDate$"));
		//份数
		pageState.put("Amount", getElementValueByMatching(doc, "name", "^ctl.*\\$Amount$"));
		//文件标题
		pageState.put("FileTitle", getElementValueByMatching(doc, "name", "^ctl.*\\$FileTitle$"));
		//备注
		pageState.put("ReceiveRemark", getElementValueByMatching(doc, "name", "^ctl.*\\$ReceiveRemark$"));
		
		//正文ID
		pageState.put("DocID", getElementValueByMatching(doc, "name", "^ctl.*\\$DocID$"));

		
		Map<String, String> task = new HashMap<String, String>();
		
		for (String column : pageState.keySet()){
			task.put(column, pageState.get(column));
		}
		task.put("type", pageState.get("type"));
		
		//定义返回附件数据的table对象
		Map<String, DataType> columns = new LinkedHashMap<String, DataType>();
		columns.put("id", DataType.STRING);
		columns.put("name", DataType.STRING);
		columns.put("docName", DataType.STRING);
		Table table = new Table(columns);
		
		//获取附件数据
		Elements attachmentTableas = doc.getElementsByAttributeValueMatching("id","^ctl.*_FileTableCtrl_dgFile$");
		Element attachmentTable = null;
		if (attachmentTableas.size()>0) {
			attachmentTable = attachmentTableas.get(0);
		}
		if (null != attachmentTable) {
			Elements attachmentTrs = attachmentTable.children().get(0).children();
			for (Element attachmentTr : attachmentTrs) {
				Element attachmentA = attachmentTr.getElementsByTag("a").get(0);
				
				Map<String, ColumnValue> column = new HashMap<String, ColumnValue>();
				column.put("name", new ColumnValue(attachmentA.html()));
				column.put("id", new ColumnValue(attachmentA.attr("onclick").split("=")[1].split("'")[0]));
				column.put("docName", new ColumnValue(attachmentA.attr("title")));
				Row row = new Row(column, RowState.NEW);
				table.appendRow(row);
			}
		}
		result.put("attachment", Transform.tableToJson(table));
		
		
		result.put("task", task);

		//获取审批记录

		JSONArray history = new JSONArray();
		
		Elements historyTables = doc.getElementsByAttributeValueMatching("id", "^ctl.*_DraftTab$");
		for (int i = 0; i < historyTables.size(); i++) {
			Element historyTable = historyTables.get(i);
			Elements trs = historyTable.children().get(0).children();
			//获取子历史记录的标题
			String title = trs.get(0).getElementsByTag("span").get(0).html();
			if (!"科室批办".equals(title) && !"承办".equals(title)) {
				continue;
			}
			//定义子历史记录对象
			JSONObject childHistory = new JSONObject();
			history.add(childHistory);
			
			//定义子历史记录的数据列表
			JSONArray childHistoryDataList = new JSONArray();
			
			childHistory.put("title", title);
			childHistory.put("data", childHistoryDataList);
			
			
			
			Elements childHistoryDataTables = trs.get(2).getElementsByTag("table");
			for (int j = 0; j < childHistoryDataTables.size(); j++) {
				JSONObject jsob = new JSONObject();
				Element childHistoryDataTable = childHistoryDataTables.get(j);
				String DisplayName = childHistoryDataTable.getElementsByAttributeValueMatching("id","DisplayName$").get(0).html();
				String DeptName = childHistoryDataTable.getElementsByAttributeValueMatching("id","DeptName$").get(0).html();
				String Time = childHistoryDataTable.getElementsByAttributeValueMatching("id","Time$").get(0).html();
				String Idea = childHistoryDataTable.getElementsByAttributeValueMatching("id","Idea$").get(0).html();
				jsob.put("审核人", DisplayName);
				jsob.put("部门", DeptName);
				jsob.put("时间", Time);
				jsob.put("意见", Idea);
				
				childHistoryDataList.add(jsob);
			}
			
		}
		
		result.put("history", history);
		return result;
	}
	
	private static String getElementValueByAttrivute(Document doc,String attrivute,String attrivuteValue){
		String result = "";
		Elements elements = doc.getElementsByAttributeValue("id", attrivuteValue);
		if (elements.size()>0) {
			if ("textarea".equals(elements.get(0).tagName())) {
				result = elements.get(0).text();
			}else {
				result = elements.get(0).attr("value");
			}
		}
		return result;
	}
	
	private static String getElementValueByMatching(Document doc,String attrivuteValue,String matching){
		String result = "";
		Elements elements = doc.getElementsByAttributeValueMatching(attrivuteValue, matching);
		if (elements.size()>0) {
			if ("textarea".equals(elements.get(0).tagName())) {
				result = elements.get(0).text();
			}else {
				result = elements.get(0).attr("value");
			}
		}
		return result;
	}
}