<?xml version="1.0" encoding="UTF-8"?><model xmlns="http://www.justep.com/model"><action xmlns="http://www.w3.org/1999/xhtml" name="listNews" impl="action:common/CRUD/sqlQuery"><private name="countSql" type="String"><![CDATA[select count(a.nvarchar7)
from AllLists l
inner join Webs w
on l.tp_WebId=w.Id
inner join AllUserData a on a.tp_ListId=l.tp_ID
inner join AllDocs b on a.tp_DocId=b.Id
where   ::filter
and w.ParentWebId='DBE25851-9795-4D2C-B97D-65D258F8A188'
and w.FullUrl like '%zmh%'
 and a.tp_IsCurrent= 1 
and a.tp_DeleteTransactionId=0
and a.tp_IsCurrentVersion=1
and a.tp_ModerationStatus=0
and a.nvarchar7 is not null 
and a.ntext6 is not null
and a.ntext11 is not null
and DATEADD(hh, 8 ,datetime1)<=getdate()]]></private><private name="db" type="String">dgyt_news</private><private name="sql" type="String"><![CDATA[select a.tp_id id,a.tp_listId,a.tp_RowOrdinal,a.nvarchar7 title,a.nvarchar15 vedioUrl, a.ntext3 img,b.DirName,b.LeafName,CONVERT(varchar(100), DATEADD(hh, 8 ,datetime1),120)  createTime,
0 readCount,w.title menuName
from AllLists l
inner join Webs w
on l.tp_WebId=w.Id
inner join AllUserData a on a.tp_ListId=l.tp_ID
inner join AllDocs b on a.tp_DocId=b.Id
where   ::filter
and w.ParentWebId='DBE25851-9795-4D2C-B97D-65D258F8A188'
and w.FullUrl like '%zmh%'
 and a.tp_IsCurrent= 1 
and a.tp_DeleteTransactionId=0
and a.tp_IsCurrentVersion=1
and a.tp_ModerationStatus=0
and a.nvarchar7 is not null 
and DATEADD(hh, 8 ,datetime1)<=getdate()
and a.ntext11 is not null
and a.ntext6 is not null
order by a.datetime1 desc]]></private><private name="tableName" type="String">AllUserData</private><public name="columns" type="Object"></public><public name="filter" type="String"></public><public name="limit" type="Integer"></public><public name="offset" type="Integer"></public><public name="orderBy" type="String"></public><public name="variables" type="Object"></public></action><action xmlns="http://www.w3.org/1999/xhtml" name="getNews" impl="mobiAppPlat.oa.home.NewsPortals.getNews"></action><action xmlns="http://www.w3.org/1999/xhtml" name="getImage" impl="mobiAppPlat.oa.home.NewsPortals.getImageStream"></action><action xmlns="http://www.w3.org/1999/xhtml" name="getReadCount" impl="mobiAppPlat.oa.home.NewsPortals.getReadCount"></action></model>