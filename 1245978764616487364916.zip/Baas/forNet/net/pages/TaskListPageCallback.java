package forNet.net.pages;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.alibaba.fastjson.JSONObject;

import forNet.net.HtmlParser;
import forNet.net.RespCallback;

public class TaskListPageCallback implements RespCallback{

	
	public Object execute(InputStream body) {
		JSONObject jsob = new JSONObject();
		Integer total = 0;
		List<Task> result = new ArrayList<Task>();
		Document doc = HtmlParser.parser(body, null);
		CheckUserOnline.checkOnline(doc);

		Element e = doc.getElementById("tabTask");
		if (e!=null){
			int i = 0;
			for (Element tr : e.getElementsByTag("tr")){
				if (i++ == 0) continue; //忽略表头
				
				Task task = new Task();
				Elements es = tr.getElementsByTag("a");
				if (es.size()==1){
					String click = es.get(0).attr("onclick");
					task.name = es.get(0).text();
					if ((click!=null) && click.contains("'")){
						String[] items = click.split("'");
						if (items.length>=3){
							task.id = items[1].split("=")[1];
						}
					}
				}
				if (task.id==null) continue;
				
				Elements tds = tr.getElementsByTag("td");
				if (tds.size() > 6){
					task.type = tds.get(3).text();
					task.time = tds.get(4).text();
					task.status = tds.get(5).text();
				}
				
				result.add(task);
			}
		}
		Element e_tabFile = doc.getElementById("tabFile");
		boolean isTotalStr = false;
		boolean isTotal = false;
		if (e_tabFile!=null) {
			for (Element tr : e_tabFile.getElementsByTag("tr")){
					String tdStr = tr.getElementsByTag("td").get(0).text();
					if (!isTotalStr && StringUtils.isNotEmpty(tdStr) && tdStr.indexOf("总记录数")>=0) {
						String regex = "\\d*";
						Pattern p = Pattern.compile(regex);

						Matcher m = p.matcher(tdStr);
						m.find();
						
						while (m.find()) {
							if (!isTotal && !"".equals(m.group())){
								total =  Integer.parseInt(m.group());
								isTotal = true;
							}
						}
						isTotalStr = true;
					}
			}
		}
		
		jsob.put("result", result);
		System.out.println("总记录数："+total);
		System.out.println(result);
		return result;
	}
	
	
	private static String getUrl(Element tr){
		
		return null;
		
	}

}
