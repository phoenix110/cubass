package admin.login.service;

import com.alibaba.fastjson.JSONObject;
import com.justep.baas.action.ActionContext;

public interface ILoginStrategy {
	/**
	 * 登录
	 * @param params
	 * @param context
	 * @return
	 */
	public JSONObject login(JSONObject params, ActionContext context);

}
