package admin.utils;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.sql.DataSource;

import com.justep.baas.data.DataUtils;
import com.justep.baas.data.Row;
import com.justep.baas.data.Table;

public class SystemInit implements ServletContextListener {

	public final static Map<String, String> sysConfig = new HashMap<String, String>();
	private String systemCofigPath;

	public void contextDestroyed(ServletContextEvent event) {
		// TODO 自动生成的方法存根

	}

	public void contextInitialized(ServletContextEvent event) {
		System.out.println("系统后台开始初始化......");
		
		//加载配置文件配置的信息
		sysConfig.put("dsSys", SystemConfigUtil.getConfigValue("ds.admin"));
		sysConfig.put("uploadBaseDir", SystemConfigUtil.getConfigValue("uploadBaseDir"));
		sysConfig.put("itilAttach", SystemConfigUtil.getConfigValue("itilAttach"));
		sysConfig.put("friendAttach", SystemConfigUtil.getConfigValue("friendAttach"));
		sysConfig.put("domainIp",     SystemConfigUtil.getConfigValue("domainIp"));
		sysConfig.put("domainPort",   SystemConfigUtil.getConfigValue("domainPort"));
		sysConfig.put("loginMode",    SystemConfigUtil.getConfigValue("loginMode"));
		

		// 加载系统配置信息
		Connection conn = getConnect();
		Table table = DataUtils.queryData(conn, "select * from SA_SysConfig", null, null, null, null);
		List<Row> Rows = table.getRows();
		for (Row row : Rows) {
			sysConfig.put(row.getString("sCode"), row.getString("sValue"));
		}

		System.out.println("系统后台初始化完成......");
	}

	public Connection getConnect() {
		Connection con = null;
		try {
			Context ic = new InitialContext();
			DataSource source = (DataSource) ic.lookup("java:comp/env/"+SystemConfigUtil.getConfigValue("ds.admin"));
			con = source.getConnection();
		} catch (NamingException e) {
			System.out.println("数据源没找到！");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("获取数连接对象失败！");
			e.printStackTrace();
		}
		return con;
	}

	public String getSystemCofigPath() {
		return systemCofigPath;
	}

	public void setSystemCofigPath(String systemCofigPath) {
		this.systemCofigPath = systemCofigPath;
	}

	public static void main(String[] args) {
	}

}
