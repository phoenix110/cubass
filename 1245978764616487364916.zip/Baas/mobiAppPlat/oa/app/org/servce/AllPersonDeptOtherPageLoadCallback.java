package mobiAppPlat.oa.app.org.servce;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import mobiAppPlat.oa.app.docapprove.bean.HtmlParser;
import mobiAppPlat.oa.app.docapprove.bean.RespCallback;

public class AllPersonDeptOtherPageLoadCallback implements RespCallback{

	public Object execute(InputStream body) {
		//定义要返回的数据对象
		Map<String, Object>  map = new HashMap<String, Object>();
		
		//将抓取到的数据转成document对象。
		Document doc = HtmlParser.parser(body, null);
		Elements nodes = doc.getElementsByTag("nodes").get(0).children();
		for (int i = 0; i < nodes.size(); i++) {
			Element node = nodes.get(i);
			Map<String, Object>  orgMap = new HashMap<String, Object>();
			//获取名称
			map.put(node.attr("text"), orgMap);
			//获取组织类型
			String orgType = node.attr("target");
			
			//获取ID
			orgMap.put(node.attr("id"), orgType);
		}
		return map;
	}

}
