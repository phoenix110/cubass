package admin.beans;

import java.util.List;

/**
 * 用户
 * @author luofei
 *
 */
public class User {
	/**
	 * 用户id
	 */
	private String id;
	/**
	 * 用户编码
	 */
	private String code;
	/**
	 * 用户名
	 */
	private String name;
	/**
	 * 登录名
	 */
	private String loginName;
	/**
	 * 密码
	 */
	private String password;
	/**
	 * 所属机构id
	 */
	private String orgId;
	/**
	 * 所属机构编码
	 */
	private String orgCode;
	/**
	 * 所属机构名称
	 */
	private String orgName;
	/**
	 * 所属机构full ID
	 */
	private String orgFId;
	/**
	 * 所属机构 full 编码
	 */
	private String orgFCode;
	/**
	 * 所属机构全名
	 */
	private String orgFName;
	/**
	 * 电子邮件
	 */
	private String mail;
	
	/**
	 * 手机号码
	 */
	private String phone;
	
	/**
	 * 地址
	 */
	private String address;
	/**
	 * 办公电话
	 */
	private String oficePhone;
	
	/**
	 * 用户照片
	 */
	private String userPhoto;
	/**
	 * 父节点id
	 */
    private String parentId;
    
    /**
     * 用户类型
     */
    private int userType;
	
	/**
	 * 用户的角色
	 */
	private List<Role> roles;
	
	/**
	 * 用户的权限
	 */
	private List<UserPermission> permissions;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}
	
	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public String getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getOrgFName() {
		return orgFName;
	}

	public int getUserType() {
		return userType;
	}

	public void setUserType(int userType) {
		this.userType = userType;
	}

	public void setOrgFName(String orgFName) {
		this.orgFName = orgFName;
	}

	public String getUserPhoto() {
		return userPhoto;
	}

	public void setUserPhoto(String userPhoto) {
		this.userPhoto = userPhoto;
	}

	public List<Role> getRoles() {
		return roles;
	}

	public void setRoles(List<Role> roles) {
		this.roles = roles;
	}

	public String getOrgFId() {
		return orgFId;
	}

	public void setOrgFId(String orgFId) {
		this.orgFId = orgFId;
	}

	public String getOrgFCode() {
		return orgFCode;
	}

	public void setOrgFCode(String orgFCode) {
		this.orgFCode = orgFCode;
	}

	public List<UserPermission> getPermissions() {
		return permissions;
	}

	public void setPermissions(List<UserPermission> permissions) {
		this.permissions = permissions;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getOficePhone() {
		return oficePhone;
	}

	public void setOficePhone(String oficePhone) {
		this.oficePhone = oficePhone;
	}

	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}
	
	
	
}
