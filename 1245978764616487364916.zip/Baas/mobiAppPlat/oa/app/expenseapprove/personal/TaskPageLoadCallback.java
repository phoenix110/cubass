package mobiAppPlat.oa.app.expenseapprove.personal;

import java.io.InputStream;

import mobiAppPlat.oa.app.expenseapprove.beans.TravelExpense;
import mobiAppPlat.oa.app.expenseapprove.utils.PageUtils;
import mobiAppPlat.oa.system.OASystemInit;

import org.jsoup.nodes.Document;

import com.alibaba.fastjson.JSONObject;

import forNet.net.HtmlParser;
import forNet.net.RespCallback;
import forNet.net.pages.CheckUserOnline;

public class TaskPageLoadCallback implements RespCallback {

	public Object execute(InputStream body) {

		JSONObject result = new JSONObject();
		Document doc = HtmlParser.parser(body, null);
		CheckUserOnline.checkOnline(doc);
		TravelExpense travelExpense = new TravelExpense();
		// 获取请求信息
		PageUtils.getPostInfo(doc, travelExpense);
		// 获取基本信息
		PageUtils.getBaseInfo(doc, travelExpense);
		// 获取人员信息
		PageUtils.getFee1(doc, travelExpense);
		// 获取交通信息
		PageUtils.getFee2(doc, travelExpense);
		// 获取住宿信息
		PageUtils.getFee3(doc, travelExpense);
		// 获取其他费用信息
		PageUtils.getFee4(doc, travelExpense);
		// 获取补助信息
		PageUtils.getFee5(doc, travelExpense);
		// 获取历史审批信息
		PageUtils.getReviewIdea(doc, travelExpense);
		// 设置请求URL
		travelExpense.setPostUrl(doc.getElementById("aspnetForm").attr("action"));
		// 设置请求URL
		String postUrl = doc.getElementById("aspnetForm").attr("action");
		travelExpense.setPostUrl(postUrl);
		result.put("result", travelExpense);
		System.out.println("result:"+result);

		return result;
	}

	public static void main(String[] args) {
		InputStream in = HtmlParser.class.getResourceAsStream("/mobiAppPlat/oa/app/expenseapprove/personal/travelDetail.txt");
		//Document doc = HtmlParser.parser(in, null);
		new TaskPageLoadCallback().execute(in);
	}

}
