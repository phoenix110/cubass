<?xml version="1.0" encoding="UTF-8"?>
<model>
<action name="push" impl="jpush.Push.push">
<public name="registrationId" type="String" />
</action>
</model>