package admin.utils;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Timer;
import java.util.TimerTask;

public class TelnetOperator {

	private Connection dbConn = getConnect();

	public void connect(String moduleName) {
		try {
			URL reqUrl = null;
			if ("oa".equals(moduleName)) {
				reqUrl = new URL("http://oa.petrochina");
			} else if ("contract".equals(moduleName)) {
				reqUrl = new URL("https://cms.petrochina");
			} else if ("expense".equals(moduleName)) {
				reqUrl = new URL("http://expense.cnpc/Expense/Logon.aspx?ReturnUrl=%2fExpense%2f");
			}
			HttpURLConnection conn = (HttpURLConnection) reqUrl.openConnection();
			conn.connect();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			if ("oa".equals(moduleName)) {
				saveLog(moduleName, "http://oa.petrochina");
			} else if ("contract".equals(moduleName)) {
				saveLog(moduleName, "https://cms.petrochina");
			} else if ("expense".equals(moduleName)) {
				saveLog(moduleName, "http://expense.cnpc/Expense/Logon.aspx?ReturnUrl=%2fExpense%2f");
			}
		}
	}

	public void saveLog(String modleName, String url) {
		String sql = "insert into t_monitor_log values(?,?,?,?)";
		try {
			java.sql.PreparedStatement stmt = dbConn.prepareStatement(sql);
			stmt.setString(1, java.util.UUID.randomUUID().toString());
			stmt.setString(2, modleName);
			stmt.setString(3, url);
			stmt.setTimestamp(4, new Timestamp(System.currentTimeMillis()));
			// stmt.setDate(4, new Date(System.currentTimeMillis()));
			stmt.execute();
			// dbConn.commit();
		} catch (SQLException e) {
		}

	}

	public void monitor(final String modleName) {
		Timer timer = new Timer();
		timer.schedule(new TimerTask() {
			@Override
			public void run() {
				new TelnetOperator().connect(modleName);
			}
		}, 1000, 1000*30);
	}

	public static void executeOA() {
		new TelnetOperator().monitor("oa");
	}

	public static void executeContract() {
		new TelnetOperator().monitor("contract");
	}

	public static void executeExpense() {
		new TelnetOperator().monitor("expense");
	}

	public Connection getConnect() {
		String url = "jdbc:mysql://127.0.0.1/demo";
		String name = "com.mysql.jdbc.Driver";
		String user = "root";
		String password = "x5";
		Connection conn = null;
		try {
			Class.forName(name);
			conn = DriverManager.getConnection(url, user, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}

		return conn;
	}

	public static void main(String[] args) throws Exception {
		executeOA();
		executeContract();
		executeExpense();
	}

}
