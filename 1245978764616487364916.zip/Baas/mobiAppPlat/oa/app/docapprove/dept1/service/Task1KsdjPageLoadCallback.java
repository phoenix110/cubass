package mobiAppPlat.oa.app.docapprove.dept1.service;

import java.io.InputStream;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import mobiAppPlat.oa.app.docapprove.bean.HtmlParser;
import mobiAppPlat.oa.app.docapprove.bean.RespCallback;
import mobiAppPlat.oa.app.docapprove.service.CheckUserOnline;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.justep.baas.data.ColumnValue;
import com.justep.baas.data.DataType;
import com.justep.baas.data.Row;
import com.justep.baas.data.RowState;
import com.justep.baas.data.Table;
import com.justep.baas.data.Transform;


public class Task1KsdjPageLoadCallback implements RespCallback{
	private static final String[] NAMES = new String[]{
		"ctl00$forward_0",
		"ctl00$txtforward_0",
		"Register_00_Current_Ctrl$WordMarkNo",
		"Register_00_Current_Ctrl$ReceiveDate",
		"Register_00_Current_Ctrl$RegisterDisplayName",
		"Register_00_Current_Ctrl$DraftUnit",
		"Register_00_Current_Ctrl$SourceType",
		"Register_00_Current_Ctrl$SecretLevel",
		"Register_00_Current_Ctrl$SecretLimit",
		"Register_00_Current_Ctrl$UrgentLevel",
		"Register_00_Current_Ctrl$CarrierType",
		"Register_00_Current_Ctrl$ReceiveFileNo",
		"Register_00_Current_Ctrl$CreateDate",
		"Register_00_Current_Ctrl$Amount",
		"Register_00_Current_Ctrl$ReceiveType",
		"Register_00_Current_Ctrl$FileTitle",
		"Register_00_Current_Ctrl$Topic",
		"Register_00_Current_Ctrl$Archive",
		"Register_00_Current_Ctrl$TimeLimit",
		"Register_00_Current_Ctrl$Issue",
		"Register_00_Current_Ctrl$ReceiveRemark",
		
		
		//补充属性，为执行流转用
		"Register_00_Current_Ctrl$RegisterDeptID",
		"Register_00_Current_Ctrl$RegisterDept",
		"Register_00_Current_Ctrl$Register",
		"Register_00_Current_Ctrl$ReceiveTime",
		"Register_00_Current_Ctrl$HeadTemplate",
		"Register_00_Current_Ctrl$GiveMainUnitID",
		"Register_00_Current_Ctrl$GiveMainUnit",
		"Register_00_Current_Ctrl$GiveCopyUnitID",
		"Register_00_Current_Ctrl$GiveCopyUnit",
		"Register_00_Current_Ctrl$DrafterIncName",
		"Register_00_Current_Ctrl$DrafterIncID",
		"Register_00_Current_Ctrl$DrafterDeptName",
		"Register_00_Current_Ctrl$DrafterDeptID",
		"Register_00_Current_Ctrl$DocWebService",
		"Register_00_Current_Ctrl$DocID",
		"Register_00_Current_Ctrl$CreateTime",
		"Register_00_Current_Ctrl$ChannelDirectory",
		"Register_00_Current_Ctrl$Accessory",
		"__VIEWSTATE",
		"__VIEWSTATEGENERATOR",
		"__EVENTVALIDATION"
	};
	
	private static final String[] TASK_COLUMNS = new String[]{
		"ctl00$forward_0",
		"ctl00$txtforward_0",
		"Register_00_Current_Ctrl$WordMarkNo",
		"Register_00_Current_Ctrl$ReceiveDate",
		"Register_00_Current_Ctrl$RegisterDisplayName",
		"Register_00_Current_Ctrl$DraftUnit",
		"Register_00_Current_Ctrl$SourceType",
		"Register_00_Current_Ctrl$SecretLevel",
		"Register_00_Current_Ctrl$SecretLimit",
		"Register_00_Current_Ctrl$UrgentLevel",
		"Register_00_Current_Ctrl$CarrierType",
		"Register_00_Current_Ctrl$ReceiveFileNo",
		"Register_00_Current_Ctrl$CreateDate",
		"Register_00_Current_Ctrl$Amount",
		"Register_00_Current_Ctrl$ReceiveType",
		"Register_00_Current_Ctrl$FileTitle",
		"Register_00_Current_Ctrl$Topic",
//		"Register_00_Current_Ctrl$btnViewMainUnits",
//		"Register_00_Current_Ctrl$btnViewCopyUnits",
//		"Register_00_Current_Ctrl$OpenDocumentCtrl$btnOpenDocument",
		"Register_00_Current_Ctrl$Archive",
		"Register_00_Current_Ctrl$TimeLimit",
//		"Register_00_Current_Ctrl_FileTableCtrl_div",
//		"Register_00_Current_Ctrl$FileTableCtrl$btn_ipdown",
		"Register_00_Current_Ctrl$Issue",
		"Register_00_Current_Ctrl$ReceiveRemark",
		
		//补充属性，为执行流转用
		"Register_00_Current_Ctrl$RegisterDeptID",
		"Register_00_Current_Ctrl$RegisterDept",
		"Register_00_Current_Ctrl$Register",
		"Register_00_Current_Ctrl$ReceiveTime",
		"Register_00_Current_Ctrl$HeadTemplate",
		"Register_00_Current_Ctrl$GiveMainUnitID",
		"Register_00_Current_Ctrl$GiveMainUnit",
		"Register_00_Current_Ctrl$GiveCopyUnitID",
		"Register_00_Current_Ctrl$GiveCopyUnit",
		"Register_00_Current_Ctrl$DrafterIncName",
		"Register_00_Current_Ctrl$DrafterIncID",
		"Register_00_Current_Ctrl$DrafterDeptName",
		"Register_00_Current_Ctrl$DrafterDeptID",
		"Register_00_Current_Ctrl$DocWebService",
		"Register_00_Current_Ctrl$DocID",
		"Register_00_Current_Ctrl$CreateTime",
		"Register_00_Current_Ctrl$ChannelDirectory",
		"Register_00_Current_Ctrl$Accessory",
		"__VIEWSTATE",
		"__VIEWSTATEGENERATOR",
		"__EVENTVALIDATION"
	}; 
	
	
	public Object execute(InputStream body) {
		Document doc = HtmlParser.parser(body, null);
		
		CheckUserOnline.checkOnline(doc);
		
		Map<String, Object> result = new HashMap<String, Object>();
		Map<String, String> pageState = new HashMap<String, String>();
		
		//定义返回附件数据的table对象
		Map<String, DataType> columns = new LinkedHashMap<String, DataType>();
		columns.put("id", DataType.STRING);
		columns.put("name", DataType.STRING);
		columns.put("docName", DataType.STRING);
		Table table = new Table(columns);
		
		result.put("pageState", pageState);
		for (String name : NAMES){
			Elements es = doc.getElementsByAttributeValue("name", name);
			if (es.size()>=1){
				String value = "";
				Element e = es.get(0);
				if (e.tagName().equals("textarea")){
					value = e.text();
				}else{
					value = es.get(0).attr("value");
				}
				
				pageState.put(name, value);
			}
		}
		
		Map<String, String> task = new HashMap<String, String>();
		for (String column : TASK_COLUMNS){
			task.put(column, pageState.get(column));	
		}
		
		//获取附件数据
		Element attachmentTable = doc.getElementById("Register_00_Current_Ctrl_FileTableCtrl_dgFile");
		if (null != attachmentTable) {
			Elements attachmentTrs = attachmentTable.children().get(0).children();
			for (Element attachmentTr : attachmentTrs) {
				Element attachmentA = attachmentTr.getElementsByTag("a").get(0);
				
				Map<String, ColumnValue> column = new HashMap<String, ColumnValue>();
				column.put("name", new ColumnValue(attachmentA.html()));
				column.put("id", new ColumnValue(attachmentA.attr("onclick").split("=")[1].split("'")[0]));
				column.put("docName", new ColumnValue(attachmentA.attr("title")));
				Row row = new Row(column, RowState.NEW);
				table.appendRow(row);
			}
		}
		result.put("attachment", Transform.tableToJson(table));
		result.put("task", task);
		return result;
	}

}
