package admin.user;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletResponse;

import admin.beans.UserPermission;
import admin.utils.StringUtil;
import admin.utils.SystemInit;

import com.alibaba.fastjson.JSONObject;
import com.justep.baas.action.ActionContext;
import com.justep.baas.data.DataUtils;

public class UserManager {
	
	/**
	 * 获取用户照片
	 * @param params
	 * @param context
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws IOException
	 */
	public static JSONObject getUserPhoto(JSONObject params, ActionContext context) throws SQLException, NamingException, IOException {
		JSONObject jsonObj = new JSONObject();
		HttpServletResponse response = (HttpServletResponse) context.get(ActionContext.RESPONSE);
		String loginName = params.getString("loginName");
		Connection conn = context.getConnection(SystemInit.sysConfig.get("dsSys"));
		List<Object> sqlParams = new ArrayList<Object>();
		sqlParams.add(loginName);
		PreparedStatement stmt = conn
				.prepareStatement("select a.sPhoto from sa_opperson a where a.sLoginName=?");
		stmt.setString(1, loginName);
		ResultSet rs = stmt.executeQuery();
		String userPhoto="";
		while (rs.next()) {
			userPhoto=StringUtil.getBase64String(rs.getBinaryStream("sPhoto"));
		}
		jsonObj.put("userPhoto", userPhoto);
		DataUtils.writeJsonToResponse(response, jsonObj);
		return null;
	}
	
	/**
	 * 获取用户的权限(用户的角色的权限去重)
	 * @param roleId
	 * @return
	 * @throws SQLException 
	 * @throws NamingException 
	 * @throws IOException 
	 */
	public static JSONObject getUserPermisions(JSONObject params, ActionContext context) throws SQLException, NamingException, IOException {
		JSONObject jsonObj = new JSONObject();
		HttpServletResponse response = (HttpServletResponse) context.get(ActionContext.RESPONSE);
		List<UserPermission> permissions = new ArrayList<UserPermission>();
		String orgFId = params.getString("orgFId");
		String client = params.getString("client");
		Connection conn = context.getConnection(SystemInit.sysConfig.get("dsSys"));
			String sql = "select  c.sID,c.sCode,c.sName,c.sFID,c.sFCode,c.sFName,c.sUrl,c.sParent,c.sKind,c.sIcon from  SA_OPAuthorize a,SA_OPPermission b,SA_OPFunction c where charindex(a.sOrgID ,?)>0 and a.sAuthorizeRoleID=b.sPermissionRoleID and b.sFuncId=c.sID";
			if ("admin".equals(client)) {
				  sql = sql + " and c.sKind=1";
			}else{
				  sql = sql + " and c.sKind=2";
			}
			sql = sql + " order by c.sSequence";
			
			System.out.println(sql);
			
			PreparedStatement stmt = conn
					.prepareStatement(sql);
			stmt.setString(1, orgFId);
			ResultSet rs = stmt.executeQuery();
			String funcId="";
			while (rs.next()) {
				UserPermission userPermission = new UserPermission();
				userPermission.setId(rs.getString("sID"));
				userPermission.setCode(rs.getString("sCode"));
				userPermission.setName(rs.getString("sName"));
				userPermission.setFullId(rs.getString("sFID"));
				userPermission.setFullCode(rs.getString("sFCode"));
				userPermission.setFullName(rs.getString("sFName"));
				userPermission.setUrl(rs.getString("sUrl"));
				userPermission.setKind(rs.getInt("sKind"));
				userPermission.setParentId(rs.getString("sParent"));
				userPermission.setIcon(StringUtil.getBase64String(rs.getBinaryStream("sIcon")));
				if(!rs.getString("sID").equals(funcId)){
					permissions.add(userPermission);
				}
				funcId=rs.getString("sID");
			}
			jsonObj.put("permissions", permissions);
			DataUtils.writeJsonToResponse(response, jsonObj);
		return null; 
	   }

}
