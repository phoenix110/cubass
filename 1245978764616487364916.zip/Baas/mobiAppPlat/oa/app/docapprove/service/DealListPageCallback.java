package mobiAppPlat.oa.app.docapprove.service;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import mobiAppPlat.oa.app.contractapprove.TaskPageLoadCallback;
import mobiAppPlat.oa.app.docapprove.bean.HtmlParser;
import mobiAppPlat.oa.app.docapprove.bean.RespCallback;
import mobiAppPlat.oa.app.docapprove.bean.Task;
import mobiAppPlat.oa.app.docapprove.service.CheckUserOnline;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class DealListPageCallback implements RespCallback{

	public Object execute(InputStream body) {
		List<Task> result = new ArrayList<Task>();
		Document doc = HtmlParser.parser(body, null);
		CheckUserOnline.checkOnline(doc);
		
		Element e = doc.getElementById("receiveDoneTab");
		if (e!=null){
			int i = 0;
			for (Element tr : e.getElementsByTag("tr")){
				
				if (i++ == 0) continue; //忽略表头
				Elements tds = tr.getElementsByTag("td");
				
				Task task = new Task();
				Elements es = tr.getElementsByTag("a");
				if (es.size()==1){
					String click = es.get(0).attr("onclick");
					task.name = es.get(0).text();
					if ((click!=null) && click.contains("'")){
						String[] items = click.split("'");
						if (items.length>=3){
							task.detailUrl="/task%20portal/"+items[1].replaceAll("\\.\\.", "");
							task.id = items[1].split("=")[1];
						}
					}
				}
				if (task.id==null) continue;
				if (tds.size() > 6){
					task.type = tds.get(5).text();
					task.time = tds.get(2).text();
					task.status = tds.get(6).text();
				}
				result.add(task);
			}
		}
		return result;
	}
	
	
	private static String getUrl(Element tr){
		
		return null;
		
	}
	

	public static void main(String[] args) {
		InputStream in = HtmlParser.class.getResourceAsStream("/mobiAppPlat/oa/app/docapprove/taskList.txt");
		new DealListPageCallback().execute(in);
	}

}
