package itil;

public class AlarmCondition {
	private String id;
	private String type;
	private int process = 0;
	private String sortOrder = "firstOccurtime";
	private String isDesc = "true";
	private String serverity;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getProcess() {
		return process;
	}

	public void setProcess(int process) {
		this.process = process;
	}

	public String getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}


	public String getServerity() {
		return serverity;
	}

	public void setServerity(String serverity) {
		this.serverity = serverity;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getIsDesc() {
		return isDesc;
	}

	public void setIsDesc(String isDesc) {
		this.isDesc = isDesc;
	}
	
	
}
