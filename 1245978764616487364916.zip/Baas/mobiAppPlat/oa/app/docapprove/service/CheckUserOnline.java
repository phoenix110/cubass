package mobiAppPlat.oa.app.docapprove.service;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class CheckUserOnline {
	public static final String NO_USER = "对不起，您不是系统用户，请重新登录！";
	public static void checkOnline(Document doc){
		Elements es = doc.getElementsByTag("IMG");
		if (es.size()==1){
			for (Element e : es){
				String src = e.attr("src");
				if (src.endsWith("img/error_nouser.gif")){
					throw new RuntimeException(NO_USER);
				}
				break;
			}
		}
		
		for (Element e : doc.getElementsByTag("a")){
			String href = e.attr("href");
			if (href.endsWith("error_nouser.htm")){
				throw new RuntimeException(NO_USER);
			}
			break;
		}
	}
}
