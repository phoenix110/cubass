package mobiAppPlat.oa.app.expenseapprove.beans;

import java.util.List;
import java.util.Map;

/**
 * 
 * @author luofei
 * 
 */
public class CommExpense {

	/**
	 * 基本信息
	 */
	private Map<String, String> baseInfo;

	/**
	 * 附件明细
	 */
	private List<Map<String, String>> attaDetail;
	/**
	 * 单据明细
	 */
	private List<Map<String, String>> listDetail;

	/**
	 * 历史审批意见
	 */
	private List<Map<String, String>> ReviewIdea;

	/**
	 * 请求参数
	 */
	private Map<String, String> postParams;

	/**
	 * 请求地址
	 */
	private String postUrl;
	

	public Map<String, String> getBaseInfo() {
		return baseInfo;
	}

	public void setBaseInfo(Map<String, String> baseInfo) {
		this.baseInfo = baseInfo;
	}

	public List<Map<String, String>> getAttaDetail() {
		return attaDetail;
	}

	public void setAttaDetail(List<Map<String, String>> attaDetail) {
		this.attaDetail = attaDetail;
	}

	public List<Map<String, String>> getListDetail() {
		return listDetail;
	}

	public void setListDetail(List<Map<String, String>> listDetail) {
		this.listDetail = listDetail;
	}

	public List<Map<String, String>> getReviewIdea() {
		return ReviewIdea;
	}

	public void setReviewIdea(List<Map<String, String>> reviewIdea) {
		ReviewIdea = reviewIdea;
	}

	public Map<String, String> getPostParams() {
		return postParams;
	}

	public void setPostParams(Map<String, String> postParams) {
		this.postParams = postParams;
	}

	public String getPostUrl() {
		return postUrl;
	}

	public void setPostUrl(String postUrl) {
		this.postUrl = postUrl;
	}
}
