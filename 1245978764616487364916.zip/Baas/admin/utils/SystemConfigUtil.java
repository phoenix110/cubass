package admin.utils;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class SystemConfigUtil {

	private static Document document;
	private static Element orgKind;
	static {
		URL url = SystemConfigUtil.class.getClassLoader().getResource("admin/config/sys.config.m");
		File file = new File(url.getFile());
		try {
			document = Jsoup.parse(file, "UTF-8");
			Elements orgKinds = document.select("[name=orgKind]");
			if (orgKinds.size() > 0) {
				orgKind = orgKinds.first();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static String getConfigValue(String itemName) {
		return document.select("[name=" + itemName + "]").val();
	}
	public static Element getItem(String configName) {
		return orgKind.select("[name=" + configName + "]").first();
	}

	public static Map<String, String> getLabels(String itemName) {
		Map<String, String> labelMap = new HashMap<String, String>();
		Element item = SystemConfigUtil.getItem(itemName);
		Elements labels = item.select("label");
		for (Element label : labels) {
			 labelMap.put(label.attr("language"), label.text());
		}
		return labelMap;
	}
	
	public static void main(String[] args) {
		System.out.println(getConfigValue("ds.admin"));
	}

}
