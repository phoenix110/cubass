package forNet.net.pages;

import com.alibaba.fastjson.JSONObject;

public class Task {
	public String name = "";
	public String time = "";
	public String status = "";
	public String type = "";
	public String id = "";
	
	
	public String toString(){
		return "id: " + id + ", name: " + name + ", time: "+ time + ", status: " + status + ", type: " + type;
	}
	
	public JSONObject toJson(){
		JSONObject obj = new JSONObject();
		obj.put("id", id);
		obj.put("name", name);
		obj.put("time", time);
		obj.put("status", status);
		obj.put("type", type);
		return obj;
	}
}
