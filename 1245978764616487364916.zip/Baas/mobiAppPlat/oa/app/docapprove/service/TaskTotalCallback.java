package mobiAppPlat.oa.app.docapprove.service;

import java.io.InputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;


import mobiAppPlat.oa.app.docapprove.bean.HtmlParser;
import mobiAppPlat.oa.app.docapprove.bean.RespCallback;
import mobiAppPlat.oa.app.docapprove.service.CheckUserOnline;

public class TaskTotalCallback implements RespCallback {

	public Object execute(InputStream body) {

		Integer total = 0;
		Document doc = HtmlParser.parser(body, null);
		CheckUserOnline.checkOnline(doc);
		
		Element e_tabFile = doc.getElementById("tabFile");
		boolean isTotalStr = false;
		boolean isTotal = false;
		if (e_tabFile!=null) {
			for (Element tr : e_tabFile.getElementsByTag("tr")){
					String tdStr = tr.getElementsByTag("td").get(0).text();
					if (!isTotalStr && StringUtils.isNotEmpty(tdStr) && tdStr.indexOf("总记录数")>=0) {
						String regex = "\\d*";
						Pattern p = Pattern.compile(regex);

						Matcher m = p.matcher(tdStr);
						m.find();
						
						while (m.find()) {
							if (!isTotal && !"".equals(m.group())){
								total =  Integer.parseInt(m.group());
								isTotal = true;
							}
						}
						isTotalStr = true;
					}
			}
		}
		return total;
	}

}
