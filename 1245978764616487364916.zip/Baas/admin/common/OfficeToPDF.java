package admin.common;

import java.io.File;

import com.artofsolving.jodconverter.DocumentConverter;
import com.artofsolving.jodconverter.openoffice.connection.OpenOfficeConnection;
import com.artofsolving.jodconverter.openoffice.connection.SocketOpenOfficeConnection;
import com.artofsolving.jodconverter.openoffice.converter.OpenOfficeDocumentConverter;

public class OfficeToPDF {

	public void docToPdf(File inputFile, File outputFile) {
		// 启动服务
		String OpenOffice_HOME = "C:/Program Files (x86)/OpenOffice 4";// 这里是OpenOffice的安装目录
		if (OpenOffice_HOME.charAt(OpenOffice_HOME.length() - 1) != '/') {
			OpenOffice_HOME += "/";
		}
		Process pro = null;
		OpenOfficeConnection connection = null;
		// 启动OpenOffice的服务
		String command = OpenOffice_HOME + "program/soffice.exe -headless -accept=\"socket,host=127.0.0.1,port=8100;urp;\"";
		System.out.println("==========command======="+command);
		// connect to an OpenOffice.org instance running on port 8100

		try {
			pro = Runtime.getRuntime().exec(command);
			connection = new SocketOpenOfficeConnection("127.0.0.1",8100);
			connection.connect();

			// convert
			DocumentConverter converter = new OpenOfficeDocumentConverter(connection);
			System.out.println(inputFile + "=" + outputFile);
			converter.convert(inputFile, outputFile);
		} catch (Exception ex) {
			System.out.println("程序出错了");
			ex.printStackTrace();

		} finally {
			// close the connection
			if (connection != null) {
				connection.disconnect();
				connection = null;
			}
			pro.destroy();
		}
		System.out.println("生成" + outputFile.getName());
	}
	

	// 生产pdf线程
	static class TestThread extends java.lang.Thread {
		private File inputFile;
		private File outputFile;

		public void run() {
			OfficeToPDF t = new OfficeToPDF();
			t.docToPdf(inputFile, outputFile);
			System.out.println(outputFile.getName() + "文件已生成");
		}

		public void setInputFile(File inputFile) {
			this.inputFile = inputFile;
		}

		public void setOutputFile(File outputFile) {
			this.outputFile = outputFile;
		}

		public static void main(String[] args) {
			// word 转 pdf
			OfficeToPDF wordToPDF = new OfficeToPDF();
			//wordToPDF.docToPdf(new File("D:/dgyt/doc/移动学习需求规格说明书v1.0.docx"), new File("D:/dgyt/doc/移动学习需求规格说明书v1.0.pdf"));
			//wordToPDF.docToPdf(new File("D:/dgyt/doc/大港油田移动学习项目_解决方案_20170510_v1.1.pptx"), new File("D:/dgyt/doc/大港油田移动学习项目_解决方案_20170510_v1.1.pdf"));
			wordToPDF.docToPdf(new File("D:/dgyt/doc/E菜篮功能清单.xlsx"), new File("D:/dgyt/doc/E菜篮功能清单.pdf"));

			
			// excel 转 pdf
			//wordToPDF.docToPdf(new File("E:/interface.xlsx"), new File("C:/Users/admin/Desktop/ss/interface.pdf"));
		}
	}
}