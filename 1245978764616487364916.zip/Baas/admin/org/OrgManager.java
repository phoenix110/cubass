/**
 * 
 */
package admin.org;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import admin.utils.SystemInit;

import com.alibaba.fastjson.JSONObject;
import com.justep.baas.action.ActionContext;
import com.justep.baas.data.DataUtils;
import com.justep.baas.data.Row;
import com.justep.baas.data.Table;

/**
 * 机构管理
 * 
 * @author luofei
 * 
 */
public class OrgManager {

	/**
	 * 获取组织类型
	 * 
	 * @param params
	 * @param context
	 * @return
	 */
	public static JSONObject getOrgKindsAction(JSONObject params, ActionContext context) {
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("orgKind", OrgKinds.getInstance().getOrgKinds());
		return jsonObj;
	}

	/**
	 * 修改密码
	 * 
	 * @param params
	 * @param context
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws IOException
	 */
	public static JSONObject changePassword(JSONObject params, ActionContext context) throws SQLException, NamingException, IOException {
		String userName = params.getString("username");
		String password = params.getString("password");
		String newPassword = params.getString("new_password");
		Connection conn = context.getConnection("x5Sys");
		String sql = "update SA_OPPerson  set sPassword=?  where sLoginName=? and sPassword=?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setString(1, newPassword);
		stmt.setString(2, userName);
		stmt.setString(3, password);
		stmt.execute();
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("flag", true);
		return jsonObj;

	}

	/**
	 * 移动组织
	 * 
	 * @param params
	 * @param context
	 * @return
	 * @throws NamingException
	 * @throws SQLException
	 */
	public static JSONObject moveOrg(JSONObject params, ActionContext context) throws SQLException, NamingException {

		JSONObject jsonObj = new JSONObject();
		Connection conn = context.getConnection(SystemInit.sysConfig.get("dsSys"));
		String orgId = params.getString("orgId");
		PreparedStatement stmt = null;
		String sql = "select * from SA_OPOrg where sFID like ?  order by sSequence asc";
		List<Object> sqlParams = new ArrayList<Object>();
		sqlParams.add("%" + orgId + "%");
		Table table = DataUtils.queryData(conn, sql, sqlParams, null, null, null);
		List<Row> rows = table.getRows();
		String updateSql = "update SA_OPOrg  set  sFID=?,sFCode=?, sFName=? where sID=?";
		for (Row row : rows) {
			stmt = conn.prepareStatement(updateSql);
			String parentId = row.getString("sParent");
			Row parent = new OrgManager().getParent(conn, parentId);
			// 根节点
			if (parent == null) {
				stmt.setString(1, "/" + row.getString("sID"));
				stmt.setString(2, "/" + row.getString("sCode"));
				stmt.setString(3, "/" + row.getString("sName"));
			} else {
				stmt.setString(1, parent.getString("sFID") + "/" + row.getString("sID"));
				stmt.setString(2, parent.getString("sFCode") + "/" + row.getString("sCode"));
				stmt.setString(3, parent.getString("sFName") + "/" + row.getString("sName"));
			}
			stmt.setString(4, row.getString("sID"));
			stmt.execute();
		}
		return jsonObj;
	}

	/**
	 * 更新组织
	 * 
	 * @param params
	 * @param context
	 * @return
	 * @throws NamingException
	 * @throws SQLException
	 */
	public static JSONObject updateOrg(JSONObject params, ActionContext context) throws SQLException, NamingException {
		JSONObject jsonObj = new JSONObject();

		Connection conn = context.getConnection(SystemInit.sysConfig.get("dsSys"));
		String orgId = params.getString("orgId");
		PreparedStatement stmt = null;
		String sql = "select * from SA_OPOrg where sFID like ?  order by sSequence asc";
		List<Object> sqlParams = new ArrayList<Object>();
		sqlParams.add("%" + orgId + "%");
		Table table = DataUtils.queryData(conn, sql, sqlParams, null, null, null);
		List<Row> rows = table.getRows();
		String updateSql = "update SA_OPOrg set  sFID=?,sFCode=?, sFName=? where sID=?";
		for (Row row : rows) {
			stmt = conn.prepareStatement(updateSql);
			String parentId = row.getString("sParent");
			Row parent = new OrgManager().getParent(conn, parentId);
			// 根节点
						if (parent == null) {
							stmt.setString(1, "/" + row.getString("sID"));
							stmt.setString(2, "/" + row.getString("sCode"));
							stmt.setString(3, "/" + row.getString("sName"));
						} else {
							stmt.setString(1, parent.getString("sFID") + "/" + row.getString("sID"));
							stmt.setString(2, parent.getString("sFCode") + "/" + row.getString("sCode"));
							stmt.setString(3, parent.getString("sFName") + "/" + row.getString("sName"));
						}
						stmt.setString(4, row.getString("sID"));
						stmt.execute();
		}
		return jsonObj;
	}

	/**
	 * 获取父组织
	 * 
	 * @param conn
	 * @param orgId
	 * @return
	 */
	private Row getParent(Connection conn, String orgId) {
		List<Object> sqlParams = new ArrayList<Object>();
		sqlParams.add(orgId);
		String sql = "select * from SA_OPOrg where sID =?";
		Table table = DataUtils.queryData(conn, sql, sqlParams, null, null, null);
		if (table.getRows().size() > 0) {
			return table.getRows().get(0);
		}
		return null;

	}

	/**
	 * 删除组织
	 * 
	 * @param params
	 * @param context
	 * @return
	 * @throws NamingException
	 * @throws SQLException
	 */
	public static JSONObject deleteOrg(JSONObject params, ActionContext context) throws SQLException, NamingException {
		JSONObject jsonObj = new JSONObject();
		Connection conn = context.getConnection(SystemInit.sysConfig.get("dsSys"));
		String orgId = params.getString("orgId");
		String sql = "select * from SA_OPOrg where sFID like ?";
		List<Object> sqlParams = new ArrayList<Object>();
		sqlParams.add("%" + orgId + "%");
		Table table = DataUtils.queryData(conn, sql, sqlParams, null, null, null);
		List<Row> rows = table.getRows();
		for (Row row : rows) {
			new OrgManager().deleteRelation(conn, row.getString("sID"));
		}
		// 删除组织信息
		String deleteSql = "delete from SA_OPOrg where sFID like ?";
		PreparedStatement stmt = conn.prepareStatement(deleteSql);
		stmt.setString(1, "%" + orgId + "%");
		stmt.execute();

		return jsonObj;
	}

	/**
	 * 删除机构的关联对象
	 * 
	 * @param conn
	 * @param orgId
	 * @throws SQLException
	 */
	private void deleteRelation(Connection conn, String orgId) throws SQLException {
		// 删除人员
		String deleteSql = "delete from SA_OPPerson where sMainOrgID=?";
		PreparedStatement stmt = conn.prepareStatement(deleteSql);
		stmt.setString(1, orgId);
		stmt.execute();
		deleteSql = "delete from SA_OPAuthorize where sOrgID=?";
		// 删除授权信息
		stmt = conn.prepareStatement(deleteSql);
		stmt.setString(1, orgId);
		stmt.execute();
		if (stmt != null) {
			stmt.close();
		}

	}

}
