package mobiAppPlat.oa.app.expenseapprove.personal;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletResponse;

import mobiAppPlat.oa.app.expenseapprove.LoginPage;
import mobiAppPlat.oa.app.expenseapprove.beans.ExpenseTask;
import mobiAppPlat.oa.utils.ConfigUtil;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.justep.baas.action.ActionContext;

import forNet.net.pages.ActionResult;
import forNet.net.util.CookiesUtils;

public class ExpenseWrapper {

	public static JSONObject login(JSONObject params, ActionContext context) {
		boolean flag = true;
		String msg = null;
		try {
			String username = params.getString("username");
			String password = params.getString("password");
			LoginPage loginPage = new LoginPage(ConfigUtil.getConfigValue("expenseLoginUrl"));
			Map<String, String> userParams = new HashMap<String, String>();
			userParams.put("AccountType", "rdAccountTypePTR");
			userParams.put("txtUserName", username);
			userParams.put("txtPassword", password);
			ActionResult ar = loginPage.login(userParams);
			if (!ar.isFlag()) {
				flag = false;
				msg = ar.getData() + "";
			} else {
				CookiesUtils.updateCookies(context, ar.getCookies());
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		return result;
	}

	public static JSONObject loadTasks(JSONObject params, ActionContext context) {
		JSONObject loginResult = login(params, context);
		if (!loginResult.getBoolean("flag")) {
			return loginResult;
		}
		boolean flag = true;
		String msg = null;
		Object data = null;
		try {
			Map<String, String> cookies = CookiesUtils.getCookies(context);
			ActionResult ar = TaskListPage.load(cookies);
			if (!ar.isFlag()) {
				flag = false;
				msg = ar.getData() + "";
			} else {
				CookiesUtils.updateCookies(context, ar.getCookies());
				data = new JSONArray();
				List<ExpenseTask> tasks = (List<ExpenseTask>) ar.getData();
				for (ExpenseTask t : tasks) {
					((JSONArray) data).add(JSONObject.toJSON(t));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		result.put("data", data);
		return result;
	}

	public static JSONObject loadTask(JSONObject params, ActionContext context) {
		boolean flag = true;
		String msg = null;
		String taskUrl = params.getString("taskUrl");
		String listType=params.getString("listType");
		JSONObject result = new JSONObject();
		try {
			Map<String, String> cookies = CookiesUtils.getCookies(context);
			ActionResult ar = TaskPage.load(taskUrl,listType, cookies);
			if (!ar.isFlag()) {
				flag = false;
				msg = ar.getData() + "";
			} else {
				CookiesUtils.updateCookies(context, ar.getCookies());
				result = (JSONObject) JSONObject.toJSON(ar.getData());
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}

		result.put("flag", flag);
		result.put("msg", msg);

		return result;

	}

	public static JSONObject doTask(JSONObject params, ActionContext context) {
		boolean flag = true;
		String msg = null;
		try {

			JSONObject pageState = (JSONObject) params.get("pageState");
			String taskUrl = params.getString("taskUrl");
				
			Map<String, String> state = new HashMap<String, String>();
			for (String key : pageState.keySet()) {
				state.put(key, pageState.getString(key));
			}
			ActionResult ar = TaskPage.doTask(taskUrl, CookiesUtils.getCookies(context), state);
			if (!ar.isFlag()) {
				flag = false;
				msg = ar.getData() + "";
			} else {
				CookiesUtils.updateCookies(context, ar.getCookies());
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		return result;
	}
	
	/**
	 * 获取图片流
	 * 
	 * @param params
	 * @param context
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws IOException
	 */
	public static JSONObject getImageStream(JSONObject params, ActionContext context) throws SQLException, NamingException, IOException {
		HttpServletResponse response = (HttpServletResponse) context.get(ActionContext.RESPONSE);
		String attaUrl = params.getString("attaUrl");
		String attaName = params.getString("attaName");
		attaName=java.net.URLDecoder.decode(attaName,"utf-8");
		attaUrl=java.net.URLDecoder.decode(attaUrl,"utf-8");
		InputStream ins = ConfigUtil.getImageStream(attaUrl, CookiesUtils.getCookies(context));
		//response.addHeader("Content-Type", "application/octet-stream");
		response.addHeader("Content-Disposition", "attachment; filename=\"" + java.net.URLEncoder.encode(attaName, "UTF-8") + "\"");
		OutputStream out = response.getOutputStream();
		byte[] buffer = new byte[32768 * 8];
        try {
            int read;
            while ((read = ins.read(buffer)) != -1) {
            	out.write(buffer, 0, read);
            }
        } finally {
        	ins.close();
        	out.close();
        }
		return null;
	}


}
