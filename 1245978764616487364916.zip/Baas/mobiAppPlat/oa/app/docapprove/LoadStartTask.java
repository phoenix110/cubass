package mobiAppPlat.oa.app.docapprove;

import java.util.Map;

import mobiAppPlat.oa.app.docapprove.bean.ActionResult;
import mobiAppPlat.oa.app.docapprove.service.StartTaskPage;
import mobiAppPlat.oa.app.docapprove.utils.CookiesUtils;

import com.alibaba.fastjson.JSONObject;
import com.justep.baas.action.ActionContext;

public class LoadStartTask {
	private static final String COOKIE_ID = CookiesUtils.getCookiesID();
	
	//加载（处室收文）流程的（科室登记）环节
	public static JSONObject load(JSONObject params, ActionContext context){
		boolean flag = true;
		String msg = null;
		Object data = null;
		try{
			String id = params.getString("id");
			String type = params.getString("type");
			String status = params.getString("status");
			Map<String, String> cookies = CookiesUtils.getCookies(context,COOKIE_ID);
			ActionResult ar = StartTaskPage.load(id, type, status, cookies);
			if (!ar.isFlag()){
				flag = false;
				msg = ar.getData() + "";
			}else{
				CookiesUtils.updateCookies(context, ar.getCookies(),COOKIE_ID);
				data = ar.getData();
			}
		}catch(Exception e){
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		result.put("data", data);
		return result;
	}
}
