package forNet.net.pages;

import java.util.Map;

import sun.misc.UCEncoder;


import forNet.net.NetServer;
import forNet.net.ReqObj;
import forNet.net.RespObj;
import forNet.net.util.Utils;

public class TaskListPage {
	private static final String TASK_LIST_URL = "http://oatraining.petrochina/task%20portal/UITaskList/TaskList.aspx";
	public static ActionResult load(Map<String, String> cookies){
		ActionResult ar = new ActionResult(true, "");
		ReqObj req = new ReqObj();
		req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept", "Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		//req.addHeader("Accept-Encoding", "gzip, deflate, sdch"); //不压缩
		req.addHeader("Accept-Language", "zh-CN,zh;q=0.8");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		req.addHeader("Host", "oatraining.petrochina");
		req.addHeader("Pragma", "no-cache");
		req.addHeader("Upgrade-Insecure-Requests", "1");
		req.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.4 Safari/537.36");
		req.setMethod("post");
		req.addParam("taskCboPageIndex", "2");
		req.addParam("taskDoneSendCboPageIndex", "1");
		req.addParam("taskDoneReceiveCboPageIndex", "1");
		req.addParam("__EVENTTARGET", "taskCboPageIndex");
		req.addParam("__EVENTARGUMENT", "");
		req.addParam("__LASTFOCUS", "");
		req.addParam("__VIEWSTATE", "/wEPDwULLTE5MDI3MjgwOTYPFhAeGXB0clxkZ19saXVxaW5nMThTc19Vc2VySUQFEHB0clxkZ19saXVxaW5nMTgeEWtleV9jdXJyZW50QWN0aW9uBQlyZWFkeXRhc2seFGtleV9DdXJUYXNrUGFnZUluZGV4BQEzHhxrZXlfQ3VyRG9uZVNlbmRUYXNrUGFnZUluZGV4AgEeH2tleV9DdXJEb25lUmVjZWl2ZVRhc2tQYWdlSW5kZXgCAR4Ua2V5X1Rhc2tDb3VudFByZVBhZ2UCCh4ca2V5X1Rhc2tEb25lU2VuZENvdW50UHJlUGFnZQIFHh9rZXlfVGFza0RvbmVSZWNlaXZlQ291bnRQcmVQYWdlAgUWAgICD2QWGAIDDw8WAh4EVGV4dAUCNDlkZAIFDw8WAh8IBQE1ZGQCBw8PFgQfCAUJ5LiK5LiA6aG1HgdFbmFibGVkZ2RkAgsPEGQQFQUBMQEyATMBNAE1FQUBMQEyATMBNAE1FCsDBWdnZ2dnFgECAmQCDw8PFgIfCAUBOGRkAhEPDxYCHwgFATJkZAITDw8WBB8IBQnkuIrkuIDpobUfCWhkZAIXDxBkEBUCATEBMhUCATEBMhQrAwJnZxYBZmQCGw8PFgIfCAUCMjNkZAIdDw8WAh8IBQE1ZGQCHw8PFgQfCAUJ5LiK5LiA6aG1HwloZGQCIw8QZBAVBQExATIBMwE0ATUVBQExATIBMwE0ATUUKwMFZ2dnZ2cWAWZkZADY79bn8WEbxLOSAAAYRK9sZ4sc");
		req.addParam("__VIEWSTATEGENERATOR", "A8063AC5");
		req.addParam("__EVENTVALIDATION", "/wEWJQKk/tSLDgLgyfGdDALUuqDDCALOueKsDQKAwc3yBgLE6abEDAKn97+nBwL8uNT2BwLFksXnBQLK/e+JCQLL/e+JCQLI/e+JCQLJ/e+JCQLO/e+JCQK3lZLeCwK1hsLZDgKIhJ7mDwK48cr0CAK9q9SxBwK0zqqCAgLls8rgBgLIy6m9BALHpIPTCALGpIPTCAL7j97/DwKvsJK+DAKz1vjgBAKg8uT9CAKktL6IDQKzqPHADAK669iIDQLF5MXxDgLKi++fAgLLi++fAgLIi++fAgLJi++fAgLOi++fAo++vtngl7/xxDHrbc7uBjSrUkoP");
		req.setUrl(TASK_LIST_URL);
		System.out.println("post加上了4");
		RespObj tasks = NetServer.service(req, new TaskListPageCallback());
		ar.addCookies(tasks.getCookies());
		ar.setData(tasks.getResponseBody());
		return ar;
		
	}
}
