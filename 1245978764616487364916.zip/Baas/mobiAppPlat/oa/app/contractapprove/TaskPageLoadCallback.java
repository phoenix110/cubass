package mobiAppPlat.oa.app.contractapprove;

import java.io.InputStream;

import mobiAppPlat.oa.app.contractapprove.beans.Contract;
import mobiAppPlat.oa.app.expenseapprove.beans.TravelExpense;

import org.jsoup.nodes.Document;

import com.alibaba.fastjson.JSONObject;

import forNet.net.HtmlParser;
import forNet.net.RespCallback;
import forNet.net.pages.CheckUserOnline;

public class TaskPageLoadCallback implements RespCallback {

	public Object execute(InputStream body) {

		JSONObject result = new JSONObject();
		Document doc = HtmlParser.parser(body, null);
		//System.out.println("detail:"+doc.html());
		CheckUserOnline.checkOnline(doc);
		Contract contract = new Contract();
		PageUtils.getContractInfo(doc,contract);
		result.put("result", contract);
		return result;
	}

	public static void main(String[] args) {
		InputStream in = HtmlParser.class.getResourceAsStream("/mobiAppPlat/oa/app/contractapprove/content.txt");
		new TaskPageLoadCallback().execute(in);
	}

}
