<?xml version="1.0" encoding="UTF-8"?>
<model>
	<action name="convertLocation" impl="bmap.Api.convertLocation">
		<public name="longitude" type="String" />
		<private name="latitude" type="String" />
	</action>
</model>