package forNet.net;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import mobiAppPlat.oa.app.contractapprove.LoginPage;

import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.DeleteMethod;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.PutMethod;
import org.apache.commons.httpclient.protocol.Protocol;
import org.apache.commons.httpclient.protocol.ProtocolSocketFactory;

import forNet.net.util.Utils;

public class TestSSLServer {
	
	private static HttpClient httpClient = null;
	static {
		ProtocolSocketFactory fcty = new NetSecureProtocolSocketFactory();
		// ProtocolSocketFactory fcty = new SSLProtocolSocketFactory();
		Protocol.registerProtocol("https", new Protocol("https", fcty, 443));
		httpClient = new HttpClient();

	}
	
	
	public static void main(String[] args) {
		//获取登录页面
		//ReqObj reqLogin = new ReqObj();
		//reqLogin.setMethod("get");
		//reqLogin.setUrl("https://cms.petrochina/CMSProduction/Login/Login.aspx?ReturnUrl=%2fCMSProduction%2fDefault.aspx");
		RespObj loginResp =new LoginPage("https://cms.petrochina/CMSProduction/Login/Login.aspx?ReturnUrl=%2fCMSProduction%2fDefault.aspx").getLoginPage(httpClient);
		//执行登录
		ReqObj reqDoLogin = new ReqObj();
		Map<String, String> params = (Map<String, String>)loginResp.getResponseBody();
		reqDoLogin.addHeader("Cookie", Utils.map2String(loginResp.getCookies()));
		reqDoLogin.setUrl("https://cms.petrochina/CMSProduction/Login/Login.aspx?ReturnUrl=%2fCMSProduction%2fDefault.aspx");
		reqDoLogin.setMethod("post");
		Map<String, String> userParams = new HashMap<String, String>();
		//从登录页返回的参数
		userParams.putAll(params);
		//自己设置的参数
		userParams.put("LoginCtr1:Domain", "rbPetrochina");
		userParams.put("LoginCtr1:txtUserID", "ptr\\laijs");
		userParams.put("LoginCtr1:txtPassword", "1qaz2wsx");
		userParams.put("LoginCtr1:Login", "");
		userParams.put("LoginCtr1:hfRemainLoginTime", "");
		userParams.put("LoginCtr1:hfRemainLoginTimes", "");
		Iterator<String> ir = userParams.keySet().iterator();
		while (ir.hasNext()) {
			
			String paramName = String.valueOf(ir.next());
			String paramValue = userParams.get(paramName);
			reqDoLogin.addParam(paramName, paramValue);
		}
		RespObj doLoginResp =service(reqDoLogin);
		
		//获取index页面
		ReqObj reqIndex= new ReqObj();
		System.out.println("index cookie is============:"+Utils.map2String(doLoginResp.getCookies()));
		reqIndex.addHeader("Cookie", Utils.map2String(doLoginResp.getCookies()));
		reqIndex.setMethod("get");
		reqIndex.setUrl("https://cms.petrochina/CMSProduction/Default.aspx");
		RespObj IndexResp =service(reqIndex);
		

		//获取列表页面
		ReqObj reqTaskList= new ReqObj();
		System.out.println("taskList cookie is============:"+Utils.map2String(IndexResp.getCookies()));
		reqTaskList.addHeader("Cookie", Utils.map2String(IndexResp.getCookies()));
		reqTaskList.setMethod("get");
		reqTaskList.setUrl("https://cms.petrochina/CMSProduction/PDA/PersonalTaskList.aspx");
		RespObj taskListResp =service(reqTaskList);
		
		//详细页面
		ReqObj reqDetail= new ReqObj();
		System.out.println("detail cookie is============:"+Utils.map2String(IndexResp.getCookies()));
		//reqDetail.addHeader("Cookie", Utils.map2String(IndexResp.getCookies()));
		reqDetail.addHeader("Referer", "https://cms.petrochina/CMSProduction/Controls/user/CtrReviewAndApproval.aspx?&CaseID=2043472009");
		reqDetail.setMethod("get");
		reqDetail.setUrl("https://cms.petrochina/CMSProduction/CtrDeclaration/CtrInfoView.aspx?OULabel=025&ObjectID=2001578445&AccessMode=ReadOnly&FileMode=None");
		RespObj detailResp =service(reqDetail);
		
		
		
	}

	public static RespObj service(ReqObj req) {
		HttpMethod httpMethod = null;
		try {
			 httpMethod = getHttpMethod(req.getUrl(), req.getMethod());
			
			 //设置头信息
			Map<String, String> headers = req.getHeaders();
			for (String name : headers.keySet()) {
				System.out.println("headname====:"+name);
				System.out.println("headvalue======:"+headers.get(name));
				httpMethod.addRequestHeader(name, headers.get(name));
			}
			
			//post参数设置
			if ((httpMethod instanceof PostMethod) || (httpMethod instanceof PutMethod)) {
				Map<String, String> params = req.getParams();
				if (httpMethod instanceof PostMethod && null != params) {
					NameValuePair[] parametersBody = new NameValuePair[params.size()];
					int index = 0;
					for (String key : params.keySet()) {
						parametersBody[index++] = new NameValuePair(key, params.get(key));
					}
					((PostMethod) httpMethod).setRequestBody(parametersBody);
				}
			 }
			
			int statusCode = httpClient.executeMethod(httpMethod);
			if ((statusCode != HttpStatus.SC_OK) && (statusCode != HttpStatus.SC_MOVED_TEMPORARILY)) {
				throw new RuntimeException("请求" + req.getUrl() + "出错！statusCode: " + statusCode);
			}

			RespObj resp = toRespObj(httpMethod);
			return resp;
		} catch (Exception e) {
			throw new RuntimeException("请求" + req.getUrl() + "出错! " + e.getMessage(), e);
		} finally {
			// 释放连接
			if (httpMethod != null) {
				// httpMethod.releaseConnection();
			}
		}
	}

	private static RespObj toRespObj(HttpMethod httpMethod) {
		RespObj resp = new RespObj();
		Header[] cookies = httpMethod.getResponseHeaders("Set-Cookie");
		if (cookies != null) {
			for (int i = cookies.length - 1; i >= 0; i--) {
				Header cookie = cookies[i];
				if (cookie != null) {
					String value = cookie.getValue();
					String first = value.split(";")[0];
					if (first.contains("=")) {
						String[] items = first.split("=");
						if (items.length == 2) {
							resp.addCookie(items[0], items[1]);
						}
					}

				}
			}
		}
		try {
			System.out.println("indexContent:" + httpMethod.getResponseBodyAsString());
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage() + "", e);
		}
		return resp;
	}

	private static HttpMethod getHttpMethod(String url, String method) {
		if ("delete".equals(method)) {
			return new DeleteMethod(url);

		} else if ("get".equals(method)) {
			return new GetMethod(url);

		} else if ("post".equals(method)) {
			return new PostMethod(url);

		} else if ("put".equals(method)) {
			return new PutMethod(url);

		} else {
			throw new RuntimeException("不支持请求：" + method);
		}
	}
	/*
	String requestHTTPSPage(String mUrl) {
			InputStream ins = null;
			String result = "";
			try {
				ins = context.getAssets().open("app_pay.cer"); //下载的证书放到项目中的assets目录中
				CertificateFactory cerFactory = CertificateFactory
						.getInstance("X.509");
				Certificate cer = cerFactory.generateCertificate(ins);
				KeyStore keyStore = KeyStore.getInstance("PKCS12", "BC");
				keyStore.load(null, null);
				keyStore.setCertificateEntry("trust", cer);

				SSLSocketFactory socketFactory = new SSLSocketFactory(keyStore);
				Scheme sch = new Scheme("https", socketFactory, 443);
				DefaultHttpClient mHttpClient = new DefaultHttpClient();
				mHttpClient.getConnectionManager().getSchemeRegistry()
						.register(sch);

				BufferedReader reader = null;
				try {
					HttpGet request = new HttpGet();
					request.setURI(new URI(mUrl));
					HttpResponse response = mHttpClient.execute(request);
					if (response.getStatusLine().getStatusCode() != 200) {
						request.abort();
						return result;
					}

					reader = new BufferedReader(new InputStreamReader(response
							.getEntity().getContent()));
					StringBuffer buffer = new StringBuffer();
					String line = null;
					while ((line = reader.readLine()) != null) {
						buffer.append(line);
					}
					result = buffer.toString();
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					if (reader != null) {
						reader.close();
					}
				}
			} catch (Exception e) {
				// TODO: handle exception
			} finally {
				try {
					if (ins != null)
						ins.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			return result;
		}*/

}
