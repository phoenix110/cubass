package admin.utils;

import java.util.Hashtable;

import javax.naming.AuthenticationException;
import javax.naming.Context;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

public class ADHelper {
	
	public static int connect(String host, String post, String username, String password) {
		int loginFlag=0;
		DirContext ctx = null;
		Hashtable<String, String> HashEnv = new Hashtable<String, String>();
		HashEnv.put(Context.SECURITY_AUTHENTICATION, "simple"); // LDAP访问安全级别(none,simple,strong)
		HashEnv.put(Context.SECURITY_PRINCIPAL, username); // AD的用户名
		HashEnv.put(Context.SECURITY_CREDENTIALS, password); // AD的密码
		HashEnv.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory"); // LDAP工厂类
		HashEnv.put("com.sun.jndi.ldap.connect.timeout", "3000");// 连接超时设置为3秒
		HashEnv.put(Context.PROVIDER_URL, "ldap://" + host + ":" + post);// 默认端口389
		try {
			ctx = new InitialDirContext(HashEnv);// 初始化上下文
			loginFlag=1;
		} catch (AuthenticationException e) {
			loginFlag=3;
			e.printStackTrace();
		} catch (javax.naming.CommunicationException e) {
			loginFlag=4;
			e.printStackTrace();
		} catch (Exception e) {
			loginFlag=0;
			e.printStackTrace();
		} finally {
			if (null != ctx) {
				try {
					ctx.close();
					ctx = null;
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return loginFlag;
	}
	public static void main(String[] args) {
		connect("10.76.32.4","389","ptr\\laijs","1qaz2wsx");
	}
}
