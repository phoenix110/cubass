package mobiAppPlat.oa.app.expenseapprove.personal;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import mobiAppPlat.oa.system.OASystemInit;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.RequestEntity;
import org.apache.commons.httpclient.methods.multipart.FilePart;
import org.apache.commons.httpclient.methods.multipart.MultipartRequestEntity;
import org.apache.commons.httpclient.methods.multipart.Part;
import org.apache.commons.httpclient.methods.multipart.StringPart;

import forNet.net.NetServer;
import forNet.net.ReqObj;
import forNet.net.RespObj;
import forNet.net.pages.ActionResult;
import forNet.net.util.Utils;

public class TaskPage {
	public static ActionResult load(String taskUrl, String listType, Map<String, String> cookies) {

		ActionResult ar = new ActionResult(true, "");
		ReqObj req = new ReqObj();
		req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept", "Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		// req.addHeader("Accept-Encoding", "gzip, deflate, sdch"); //不压缩
		req.addHeader("Accept-Language", "zh-CN,zh;q=0.8");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		// req.addHeader("Host", "expense.cnpc");
		req.addHeader("Pragma", "no-cache");
		req.addHeader("Upgrade-Insecure-Requests", "1");
		req.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.4 Safari/537.36");
		req.setMethod("get");
		req.setUrl(OASystemInit.sysConfig.get("expenseBaseUrl") + taskUrl);
		RespObj tasks = null;
		// 1.差旅报销单,2-通用报销单(包括福利费)
		if ("1".equals(listType)) {
			tasks = NetServer.service(req, new TaskPageLoadCallback());
		} else if ("2".equals(listType)) {
			tasks = NetServer.service(req, new CommPageLoadCallback());
		}
		ar.addCookies(tasks.getCookies());
		Map<String, Object> body = (Map<String, Object>) tasks.getResponseBody();
		ar.setData(body);
		ar.addCookies(tasks.getCookies());
		return ar;
	}

	public static ActionResult doTask(String taskUrl, Map<String, String> cookies, Map<String, String> params) throws HttpException, IOException {

		HttpClient httpclient = new HttpClient();
		String hostName = OASystemInit.sysConfig.get("expenseBaseUrl") + "/expense/Sheet" + taskUrl.replaceAll("./", "/");
		PostMethod post = new PostMethod(hostName);
		post.setRequestHeader("Accept", "application/x-ms-application, image/jpeg, application/xaml+xml, image/gif, image/pjpeg, application/x-ms-xbap, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*");
		post.setRequestHeader("Accept-Language", "zh-CN,zh;q=0.8");
		post.setRequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/4.0; chromeframe/30.0.1599.69; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.3)");
		post.setRequestHeader("Accept-Encoding", "gzip, deflate");
		post.setRequestHeader("Referer", hostName);
		post.setRequestHeader("Host", "expense.cnpc");
		post.setRequestHeader("Connection", "keep-alive");
		post.setRequestHeader("Cache-Control", "max-age=0");
		post.setRequestHeader("Cookie", Utils.map2String(cookies));

		int i = 0;
		Part[] parts = new Part[params.size()];
		for (String key : params.keySet()) {
			if (key.indexOf("fileUpper") > 0) {
				File file = null;
				parts[i] = new FilePart(key, file);
			} else {
				parts[i] = new StringPart(key, params.get(key), "GB2312");
			}
			i++;
		}
		//post.getParams().setContentCharset("GB2312");
		RequestEntity requestEntity = new MultipartRequestEntity(parts, post.getParams());
		post.setRequestEntity(requestEntity);
		httpclient.executeMethod(post);
		post.releaseConnection();
		ActionResult result = new ActionResult(true, "");
		result.setFlag(true);
		return result;
	}

	public static void main(String[] args) {

	}

}
