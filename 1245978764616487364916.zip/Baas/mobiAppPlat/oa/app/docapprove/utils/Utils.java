package mobiAppPlat.oa.app.docapprove.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

public class Utils {
	
	private final static String CONFIG = "../../../../../oa_url.config.xml";
	
	public static String convertStreamToString(InputStream is) {
		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		StringBuilder sb = new StringBuilder();
		String line = null;
		try {
			while ((line = reader.readLine()) != null) {
				sb.append(line + "/n");
			}
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage()+"", e);
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				
			}
		}
		return sb.toString();
	}
	
	public static String map2String(Map<String, String> map){
		StringBuffer sb = new StringBuffer();
		for (String key : map.keySet()){
			if (sb.length()!=0) sb.append("; ");
			sb.append(key).append("=").append(map.get(key));
		}
		return sb.toString();
	}
	
	public static String getOaUrl(String urlCode){
		String url = "";
		InputStream configFile = Utils.class.getResourceAsStream(CONFIG);
		try{
			SAXReader reader = new SAXReader();
			Document doc = reader.read(configFile);
			Element config = doc.getRootElement();
			url = config.elementTextTrim("ip") + config.elementTextTrim(urlCode);
		}catch(Exception e){
			e.printStackTrace();
		}
		return url;
	}
	public static String getDomainName(){
		String url = "";
		InputStream configFile = Utils.class.getResourceAsStream(CONFIG);
		try{
			SAXReader reader = new SAXReader();
			Document doc = reader.read(configFile);
			Element config = doc.getRootElement();
			url = config.elementTextTrim("ip");
		}catch(Exception e){
			e.printStackTrace();
		}
		return url;
	}
}
