package mobiAppPlat.oa.app.docapprove.dept2.service;

import java.io.InputStream;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import mobiAppPlat.oa.app.docapprove.bean.HtmlParser;
import mobiAppPlat.oa.app.docapprove.bean.RespCallback;
import mobiAppPlat.oa.app.docapprove.service.CheckUserOnline;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.justep.baas.data.ColumnValue;
import com.justep.baas.data.DataType;
import com.justep.baas.data.Row;
import com.justep.baas.data.RowState;
import com.justep.baas.data.Table;
import com.justep.baas.data.Transform;


public class Task2KssbPageLoadCallback implements RespCallback{
	private static final String[] NAMES = new String[]{
		"__VIEWSTATEGENERATOR",
		"__EVENTVALIDATION",
		"ctl00$forward_0",
		"ctl00$forward_1",
		"ctl00$txtforward_0",
		"ctl00$txtforward_1",
		"ctl00$txtfinish_0",
		"ctl00$txtdistribute_0",
		"ctl00$txtsave_0",
		"ctl00$txtstop_0",
		"ctl00$txtprint_0",
		"ReviewStart_01_Current_Ctrl$UsersID",
		"ReviewStart_01_Current_Ctrl$UsersName",
		"ReviewStart_01_Current_Ctrl$DeptSigners",
		"Register_00_History_Ctrl$WordMarkNo",
		"Register_00_History_Ctrl$ReceiveDate",
		"Register_00_History_Ctrl$RegisterDisplayName",
		"Register_00_History_Ctrl$DraftUnit",
		"Register_00_History_Ctrl$SourceType",
		"Register_00_History_Ctrl$SecretLevel",
		"Register_00_History_Ctrl$SecretLimit",
		"Register_00_History_Ctrl$UrgentLevel",
		"Register_00_History_Ctrl$CarrierType",
		"Register_00_History_Ctrl$ReceiveFileNo",
		"Register_00_History_Ctrl$CreateDate",
		"Register_00_History_Ctrl$Amount",
		"Register_00_History_Ctrl$ReceiveType",
		"Register_00_History_Ctrl$FileTitle",
		"Register_00_History_Ctrl$Topic",
		"Register_00_History_Ctrl$GiveMainUnit",
		"Register_00_History_Ctrl$GiveCopyUnit",
		"Register_00_History_Ctrl$Archive",
		"Register_00_History_Ctrl$TimeLimit",
		"Register_00_History_Ctrl$Issue",
		"Register_00_History_Ctrl$ChannelDirectory",
		"Register_00_History_Ctrl$RegisterDeptID",
		"Register_00_History_Ctrl$RegisterDept",
		"Register_00_History_Ctrl$Register",
		"Register_00_History_Ctrl$GiveMainUnitID",
		"Register_00_History_Ctrl$GiveCopyUnitID",
		"Register_00_History_Ctrl$ReceiveTime",
		"Register_00_History_Ctrl$CreateTime",
		"Register_00_History_Ctrl$DocID",
		"Register_00_History_Ctrl$DocWebService",
		"Register_00_History_Ctrl$Accessory",
		"Register_00_History_Ctrl$HeadTemplate",
		"Register_00_History_Ctrl$DrafterIncID",
		"Register_00_History_Ctrl$DrafterIncName",
		"Register_00_History_Ctrl$DrafterDeptID",
		"Register_00_History_Ctrl$DrafterDeptName",
		"Register_00_History_Ctrl$ReceiveRemark",
		
		//补充数据
		"ReviewStart_01_Current_Ctrl$btnItemUp", 
		"ReviewStart_01_Current_Ctrl$btnItemDown",
		"ctl00$finish_0",
		"ctl00$stop_0",
		"__VIEWSTATE"
	};
	
	private static final String[] TASK_COLUMNS = new String[]{
		"__VIEWSTATEGENERATOR",
		"__EVENTVALIDATION",
		"ctl00$forward_0",
		"ctl00$txtforward_0",
		"ctl00$txtforward_1",
		"ctl00$txtfinish_0",
		"ctl00$txtdistribute_0",
		"ctl00$txtsave_0",
		"ctl00$txtstop_0",
		"ctl00$txtprint_0",
		"ReviewStart_01_Current_Ctrl$UsersID",
		"ReviewStart_01_Current_Ctrl$UsersName",
		"ReviewStart_01_Current_Ctrl$DeptSigners",
		"Register_00_History_Ctrl$WordMarkNo",
		"Register_00_History_Ctrl$ReceiveDate",
		"Register_00_History_Ctrl$RegisterDisplayName",
		"Register_00_History_Ctrl$DraftUnit",
		"Register_00_History_Ctrl$SourceType",
		"Register_00_History_Ctrl$SecretLevel",
		"Register_00_History_Ctrl$SecretLimit",
		"Register_00_History_Ctrl$UrgentLevel",
		"Register_00_History_Ctrl$CarrierType",
		"Register_00_History_Ctrl$ReceiveFileNo",
		"Register_00_History_Ctrl$CreateDate",
		"Register_00_History_Ctrl$Amount",
		"Register_00_History_Ctrl$ReceiveType",
		"Register_00_History_Ctrl$FileTitle",
		"Register_00_History_Ctrl$Topic",
		"Register_00_History_Ctrl$GiveMainUnit",
		"Register_00_History_Ctrl$GiveCopyUnit",
		"Register_00_History_Ctrl$Archive",
		"Register_00_History_Ctrl$TimeLimit",
		"Register_00_History_Ctrl$Issue",
		"Register_00_History_Ctrl$ChannelDirectory",
		"Register_00_History_Ctrl$RegisterDeptID",
		"Register_00_History_Ctrl$RegisterDept",
		"Register_00_History_Ctrl$Register",
		"Register_00_History_Ctrl$GiveMainUnitID",
		"Register_00_History_Ctrl$GiveCopyUnitID",
		"Register_00_History_Ctrl$ReceiveTime",
		"Register_00_History_Ctrl$CreateTime",
		"Register_00_History_Ctrl$DocID",
		"Register_00_History_Ctrl$DocWebService",
		"Register_00_History_Ctrl$Accessory",
		"Register_00_History_Ctrl$HeadTemplate",
		"Register_00_History_Ctrl$DrafterIncID",
		"Register_00_History_Ctrl$DrafterIncName",
		"Register_00_History_Ctrl$DrafterDeptID",
		"Register_00_History_Ctrl$DrafterDeptName",
		"Register_00_History_Ctrl$ReceiveRemark",
		
		//补充数据
		"ReviewStart_01_Current_Ctrl$btnItemUp", 
		"ReviewStart_01_Current_Ctrl$btnItemDown",
		"ctl00$finish_0",
		"ctl00$stop_0",
		"__VIEWSTATE"
	}; 
	
	
	public Object execute(InputStream body) {
		
		Document doc = HtmlParser.parser(body, null);
		CheckUserOnline.checkOnline(doc);
		
		Map<String, Object> result = new HashMap<String, Object>();
		Map<String, String> pageState = new HashMap<String, String>();
		result.put("pageState", pageState);
		for (String name : NAMES){
			Elements es = doc.getElementsByAttributeValue("name", name);
			if (es.size()>=1){
				String value = "";
				Element e = es.get(0);
				if (e.tagName().equals("textarea")){
					value = e.text();
				}else{
					value = es.get(0).attr("value");
				}
				
				pageState.put(name, value);
			}
		}
		
		Map<String, String> task = new HashMap<String, String>();
		for (String column : TASK_COLUMNS){
			task.put(column, pageState.get(column));	
		}
		
		//获取workflowFormID
		String onclickStr = doc.getElementsByAttributeValue("name","ReviewStart_01_Current_Ctrl$selectUser").get(0).attr("onclick");
		String onclickStr_child[] = onclickStr.split(",");
		String str = onclickStr_child[onclickStr_child.length-1];
		String workflowFormID = str.split("'")[1];
		pageState.put("workflowFormID", workflowFormID);
		task.put("workflowFormID", workflowFormID);
		
		
		//获取deptID、deptName、incID、incName
		
		String onclickStr2 = doc.getElementsByAttributeValue("name","ctl00$distribute_0").get(0).attr("onclick");
		String onclickStr_child2[] = onclickStr2.split("&");
		String deptIDStr = onclickStr_child2[onclickStr_child2.length-7];
		String deptID = "";
		if (deptIDStr.split("deptID=").length!=0) {
			deptID = deptIDStr.split("deptID=")[1];
		}
		pageState.put("deptID", deptID);
		task.put("deptID", deptID);
		String deptNameStr = onclickStr_child2[onclickStr_child2.length-6];
		String deptName = "";
		if (deptNameStr.split("deptName=").length!=0) {
			deptName = deptNameStr.split("deptName=")[1];
		}
		pageState.put("deptName", deptName);
		task.put("deptName", deptName);
		String incIDStr = onclickStr_child2[onclickStr_child2.length-5];
		String incID = "";
		if (incIDStr.split("incID=").length!=0) {
			incID = incIDStr.split("incID=")[1];
		}
		pageState.put("incID", incID);
		task.put("incID", incID);
		String incNameStr = onclickStr_child2[onclickStr_child2.length-4];
		String incName = "";
		if (incNameStr.split("incName=").length != 0) {
			incName = incNameStr.split("incName=")[1];
		}
		pageState.put("incName", incName);
		task.put("incName", incName);
		
		
		//定义返回附件数据的table对象
		Map<String, DataType> columns = new LinkedHashMap<String, DataType>();
		columns.put("id", DataType.STRING);
		columns.put("name", DataType.STRING);
		columns.put("docName", DataType.STRING);
		Table table = new Table(columns);
		
		//获取附件数据
		Element attachmentTable = doc.getElementById("Register_00_History_Ctrl_FileTableCtrl_dgFile");
		if (null != attachmentTable) {
			Elements attachmentTrs = attachmentTable.children().get(0).children();
			for (Element attachmentTr : attachmentTrs) {
				Element attachmentA = attachmentTr.getElementsByTag("a").get(0);
				
				Map<String, ColumnValue> column = new HashMap<String, ColumnValue>();
				column.put("name", new ColumnValue(attachmentA.html()));
				column.put("id", new ColumnValue(attachmentA.attr("onclick").split("=")[1].split("'")[0]));
				column.put("docName", new ColumnValue(attachmentA.attr("title")));
				Row row = new Row(column, RowState.NEW);
				table.appendRow(row);
			}
		}
		result.put("attachment", Transform.tableToJson(table));
		
		//获取审批记录
		
		JSONArray history = new JSONArray();
		
		Elements historyTables = doc.getElementsByAttributeValueMatching("id", "^ctl.*_DraftTab$");
		for (int i = 0; i < historyTables.size(); i++) {
			Element historyTable = historyTables.get(i);
			Elements trs = historyTable.children().get(0).children();
			//获取子历史记录的标题
			String title = trs.get(0).getElementsByTag("span").get(0).html();
			if (!"科室批办".equals(title) && !"承办".equals(title)) {
				continue;
			}
			//定义子历史记录对象
			JSONObject childHistory = new JSONObject();
			history.add(childHistory);
			
			//定义子历史记录的数据列表
			JSONArray childHistoryDataList = new JSONArray();
			
			childHistory.put("title", title);
			childHistory.put("data", childHistoryDataList);
			
			Elements childHistoryDataTables = trs.get(2).getElementsByTag("table");
			for (int j = 0; j < childHistoryDataTables.size(); j++) {
				JSONObject jsob = new JSONObject();
				
				Element childHistoryDataTable = childHistoryDataTables.get(j);
				String DisplayName = childHistoryDataTable.getElementsByAttributeValueMatching("id","DisplayName$").get(0).html();
				String DeptName = childHistoryDataTable.getElementsByAttributeValueMatching("id","DeptName$").get(0).html();
				String Time = childHistoryDataTable.getElementsByAttributeValueMatching("id","Time$").get(0).html();
				String Idea = childHistoryDataTable.getElementsByAttributeValueMatching("id","Idea$").get(0).html();
				jsob.put("审核人", DisplayName);
				jsob.put("部门", DeptName);
				jsob.put("时间", Time);
				jsob.put("意见", Idea);
				
				childHistoryDataList.add(jsob);
			}
			
		}
		
		result.put("history", history);
		result.put("task", task);
		return result;
	}

}
