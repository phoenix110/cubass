package admin.utils;

import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;

/**
 * 字符串工具类
 * 
 * @author luofei
 * 
 */
public class StringUtil {

	public static boolean isEmpty(String str) {
		if ("".equals(str) || str == null) {
			return true;
		}
		return false;
	}

	public static String getBase64String(InputStream inputStream) {
		sun.misc.BASE64Encoder encoder = new sun.misc.BASE64Encoder();
		byte[] textByte = null;
		System.out.println("inputStream====================:" + inputStream);

		if (inputStream != null) {
			try {
				textByte = new byte[inputStream.available()];
				inputStream.read(textByte);
				inputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if (textByte == null) {
			return "";
		}
		return encoder.encode(textByte);

	}

	public static String string2MD5(String inStr) {
		MessageDigest md5 = null;
		try {
			md5 = MessageDigest.getInstance("MD5");
		} catch (Exception e) {
			System.out.println(e.toString());
			e.printStackTrace();
			return "";
		}
		char[] charArray = inStr.toCharArray();
		byte[] byteArray = new byte[charArray.length];

		for (int i = 0; i < charArray.length; i++)
			byteArray[i] = (byte) charArray[i];
		byte[] md5Bytes = md5.digest(byteArray);
		StringBuffer hexValue = new StringBuffer();
		for (int i = 0; i < md5Bytes.length; i++) {
			int val = ((int) md5Bytes[i]) & 0xff;
			if (val < 16)
				hexValue.append("0");
			hexValue.append(Integer.toHexString(val));
		}
		return hexValue.toString();

	}

	public static String md5(String str) {
		String s = str;
		if (s == null) {
			return "";
		} else {
			String value = null;
			MessageDigest md5 = null;
			try {
				md5 = MessageDigest.getInstance("MD5");
			} catch (NoSuchAlgorithmException ex) {
			}
			sun.misc.BASE64Encoder baseEncoder = new sun.misc.BASE64Encoder();
			try {
				value = baseEncoder.encode(md5.digest(s.getBytes("utf-8")));
			} catch (Exception ex) {
			}
			return value;
		}
	}

	

	public static String getUUID() {
		return java.util.UUID.randomUUID().toString().replaceAll("-", "");
	}
	
	public static String getRandomCode() {
		Random random = new Random();
		int x = random.nextInt(999999);
		x = x+100000;
		return String.valueOf(x);
	}

	public static void main(String[] args) {
		Random random = new Random();
		int x = random.nextInt(899999);
		x = x+100000;
		System.out.println(x);
	}

}
