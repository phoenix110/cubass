package mobiAppPlat.oa.app.contractapprove.beans;

import java.util.List;
import java.util.Map;

/**
 * 
 * @author luofei
 * 
 */
public class Contract {

	/**
	 * 基本信息
	 */
	private Map<String, String> declareInfo;

	/**
	 * 签约依据
	 */
	private List<Map<String, String>> contractBasis;
	
	/**
	 * 项目信息
	 */
	private List<Map<String, String>> projectInfo;
	
	
	/**
	 * 合同相对人
	 */
	private List<Map<String, String>> personInfo;
	

	/**
	 * 合同附件
	 */
	private List<Map<String, String>> attachment;
	

	/**
	 * 合同资料
	 */
	private List<Map<String, String>> document;
	
	/**
	 * 审批流程
	 */
	private List<Map<String, String>> auditFlow;
	
	/**
	 * 审批过程
	 */
	private List<Map<String, String>> auditRecord;


	
	/**
	 * 请求参数
	 */
	private Map<String, String> postParams;

	/**
	 * 请求地址
	 */
	private String postUrl;
	
	
	public Map<String, String> getPostParams() {
		return postParams;
	}

	public void setPostParams(Map<String, String> postParams) {
		this.postParams = postParams;
	}

	public String getPostUrl() {
		return postUrl;
	}

	public void setPostUrl(String postUrl) {
		this.postUrl = postUrl;
	}

	public List<Map<String, String>> getContractBasis() {
		return contractBasis;
	}

	public void setContractBasis(List<Map<String, String>> contractBasis) {
		this.contractBasis = contractBasis;
	}

	public List<Map<String, String>> getProjectInfo() {
		return projectInfo;
	}

	public void setProjectInfo(List<Map<String, String>> projectInfo) {
		this.projectInfo = projectInfo;
	}

	public Map<String, String> getDeclareInfo() {
		return declareInfo;
	}

	public void setDeclareInfo(Map<String, String> declareInfo) {
		this.declareInfo = declareInfo;
	}

	public List<Map<String, String>> getPersonInfo() {
		return personInfo;
	}

	public void setPersonInfo(List<Map<String, String>> personInfo) {
		this.personInfo = personInfo;
	}

	public List<Map<String, String>> getAttachment() {
		return attachment;
	}

	public void setAttachment(List<Map<String, String>> attachment) {
		this.attachment = attachment;
	}

	public List<Map<String, String>> getDocument() {
		return document;
	}

	public void setDocument(List<Map<String, String>> document) {
		this.document = document;
	}

	public List<Map<String, String>> getAuditFlow() {
		return auditFlow;
	}

	public void setAuditFlow(List<Map<String, String>> auditFlow) {
		this.auditFlow = auditFlow;
	}

	public List<Map<String, String>> getAuditRecord() {
		return auditRecord;
	}

	public void setAuditRecord(List<Map<String, String>> auditRecord) {
		this.auditRecord = auditRecord;
	}
}
