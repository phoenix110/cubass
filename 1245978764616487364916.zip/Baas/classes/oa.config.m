<?xml version="1.0" encoding="utf-8"?>

<model xmlns="http://www.justep.com/model">
	<!-- 数据源 -->
	<config name="dsOa" value="dgyt_news" />
	<!-- 门户statrt -->
	<config name="porTalUrl" value="sites/dgcsgs/cbpd/ceshigongsi" />
	<config name="uploadBaseDir" value="D:/attachment/" />
	<config name="portalBaseUrl" value="http://www.dgyt.petrochina" />
	<config name="portalSiteName" value="=www.dgyt.petrochina" />
	<config name="expenseBaseUrl" value="http://expense.cnpc" />
	<config name="isCompress" value="1" />
	<config name="minPixel" value="1000" />
	<!-- 门户end -->
	
	<!-- 报销start -->
	<config name="expenseUserKey"  value="txtUserName" />
	<config name="expensePwdKey"   value="txtPassword" />
	<config name="expenseLoginUrl" value="http://expense.cnpc/Expense/Logon.aspx?ReturnUrl=%2fExpense%2f" />
	<config name="expenseTaskList" value="http://expense.cnpc/Expense/Assignment/AssignmentManagement.aspx" />
	<config name="expenseIndex"    value="http://expense.cnpc/Expense/default.aspx" />
	<!-- 报销end -->
	
	<!-- 合同start
	<config name="contractHost"        value="http://10.27.102.38" />
	<config name="contractBaseUrl"    value="http://10.27.102.38/CMSTrainingV2" />
	<config name="contractLoginUrl"   value="http://10.27.102.38/CMSTrainingV2/Login/Login.aspx?ReturnUrl=%2fCMSTrainingV2%2fDefault.aspx" />
	<config name="contractTaskList"   value="http://10.27.102.38/CMSTrainingV2/PDA/PersonalTaskList.aspx" />
	<config name="contractIndex"      value="http://10.27.102.38/CMSTrainingV2/Default.aspx" />
	<config name="contractDoLogin"    value="http://10.27.102.38/CMSTrainingV2/Login/Login.aspx?ReturnUrl=%2fCMSTrainingV2%2fDefault.aspx" />
	
	 -->
	
	<config name="contractHost"        value="https://cms.petrochina" />
	<config name="contractBaseUrl"    value="https://cms.petrochina/CMSProduction" />
	<config name="contractLoginUrl"   value="https://cms.petrochina/CMSProduction/Login/Login.aspx?ReturnUrl=%2fCMSProduction%2fDefault.aspx" />
	<config name="contractTaskList"   value="https://cms.petrochina/CMSProduction/PDA/PersonalTaskList.aspx" />
	<config name="contractIndex"      value="https://cms.petrochina/CMSProduction/Default.aspx" />
	<config name="contractDoLogin"    value="https://cms.petrochina/CMSProduction/Login/Login.aspx?ReturnUrl=%2fCMSProduction%2fDefault.aspx" />
	
	
	<!-- 合同end -->
	
</model>