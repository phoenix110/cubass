package forNet.net.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Map;

public class Utils {
	public static String convertStreamToString(InputStream is) {
		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		StringBuilder sb = new StringBuilder();
		String line = null;
		try {
			while ((line = reader.readLine()) != null) {
				sb.append(line + "/n");
			}
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage()+"", e);
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				
			}
		}
		return sb.toString();
	}
	
	public static String map2String(Map<String, String> map){
		StringBuffer sb = new StringBuffer();
		for (String key : map.keySet()){
			if (sb.length()!=0) sb.append("; ");
			sb.append(key).append("=").append(map.get(key));
		}
		return sb.toString();
	}
}
