package mobiAppPlat.oa.app.org.servce;

import java.io.InputStream;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import mobiAppPlat.oa.app.docapprove.bean.HtmlParser;
import mobiAppPlat.oa.app.docapprove.bean.RespCallback;

import org.jsoup.nodes.Document;

import com.alibaba.fastjson.JSONArray;
import com.justep.baas.data.ColumnValue;
import com.justep.baas.data.DataType;
import com.justep.baas.data.Row;
import com.justep.baas.data.RowState;
import com.justep.baas.data.Table;
import com.justep.baas.data.Transform;

public class AllOrgPageLoadCallback implements RespCallback{

	/*
	 * 获取根节点数据
	 */
	public Object execute(InputStream body) {
		
		//定义要返回的数据对象
		Map<String, DataType> columns = new LinkedHashMap<String, DataType>();
		columns.put("id", DataType.STRING);
		columns.put("name", DataType.STRING);
		columns.put("parent", DataType.STRING);
		columns.put("type", DataType.STRING);
		columns.put("fid", DataType.STRING);
		Table table = new Table(columns);
		
		//将抓取到的数据转成document对象。
		Document doc = HtmlParser.parser(body, null);
		String treeData = doc.html().split("window.ComponentArt_Storage_TreeView1 = ")[1].split("//]]>")[0].trim();
		JSONArray jsoa = new JSONArray();
		jsoa = (JSONArray) jsoa.parse(treeData);
		for (int i = 0; i < jsoa.size(); i++) {
			JSONArray org = (JSONArray) jsoa.get(i);
			Map<String, ColumnValue> column = new HashMap<String, ColumnValue>();
			if (-1==Integer.parseInt(org.get(1).toString())) {
				column.put("id", new ColumnValue(((JSONArray)((JSONArray)org.get(3)).get(4)).get(1)));
				column.put("name", new ColumnValue(((JSONArray)((JSONArray)org.get(3)).get(6)).get(1)));
				column.put("parent", new ColumnValue(""));
				column.put("type", new ColumnValue(((JSONArray)((JSONArray)org.get(3)).get(3)).get(1)));
				column.put("fid", new ColumnValue(""));
				Row row = new Row(column, RowState.NEW);
				table.appendRow(row);
			}else {
				column.put("id", new ColumnValue(((JSONArray)((JSONArray)org.get(3)).get(4)).get(1)));
				column.put("name", new ColumnValue(((JSONArray)((JSONArray)org.get(3)).get(6)).get(1)));
				column.put("parent", new ColumnValue(((JSONArray)((JSONArray)((JSONArray)jsoa.get(Integer.parseInt(org.get(1).toString()))).get(3)).get(4)).get(1)));
				column.put("type", new ColumnValue(((JSONArray)((JSONArray)org.get(3)).get(3)).get(1)));
				column.put("fid", new ColumnValue(""));
				Row row = new Row(column, RowState.NEW);
				table.appendRow(row);
			}
		}
		
		
		System.out.println(Transform.tableToJson(table));
		
		return Transform.tableToJson(table);
	}
	

}