package mobiAppPlat.oa.app.docapprove.center3.service;

import java.util.Map;

import mobiAppPlat.oa.app.docapprove.bean.ActionResult;
import mobiAppPlat.oa.app.docapprove.bean.NetServer;
import mobiAppPlat.oa.app.docapprove.bean.ReqObj;
import mobiAppPlat.oa.app.docapprove.bean.RespObj;
import mobiAppPlat.oa.app.docapprove.center3.service.Task3ZxldpsPageDoTaskCallback;
import mobiAppPlat.oa.app.docapprove.center3.service.Task3ZxldpsPageLoadCallback;
import mobiAppPlat.oa.app.docapprove.utils.Utils;

public class Task3ZxldpsPage {

	public static ActionResult load(String id, String type, String status, Map<String, String> cookies){
		String url = Utils.getOaUrl("TaskDetailUrl");
		ActionResult ar = new ActionResult(true, "");
		//TODO 当前只支持“人事处处室收文和信息中心科室收文”
//		if (!status.equals("中心领导批示")){
//			throw new RuntimeException("当前方法只支持【中心领导批示】环节！");
//		}
		
		ReqObj req = new ReqObj();
		req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept", "Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		//req.addHeader("Accept-Encoding", "gzip, deflate, sdch"); //不压缩
		req.addHeader("Accept-Language", "zh-CN,zh;q=0.8");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		req.addHeader("Host", "oatraining.petrochina");
		req.addHeader("Pragma", "no-cache");
		req.addHeader("Upgrade-Insecure-Requests", "1");
		req.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.4 Safari/537.36");
		req.setMethod("get");
		req.setUrl(url + id);
		RespObj tasks = NetServer.service(req, new Task3ZxldpsPageLoadCallback());
		ar.addCookies(tasks.getCookies());
		Map<String, Object> body = (Map<String, Object>)tasks.getResponseBody();
		Map<String, String> task = (Map<String, String>)body.get("task");
		task.put("id", id);
		ar.setData(body);
		ar.addCookies(tasks.getCookies());
		return ar;
	}
	
	public static ActionResult doBgsdjTask(String id, Map<String, String> cookies, Map<String, String> params){
		
		String url = Utils.getOaUrl("TaskDetailUrl");
		
		ReqObj req = new ReqObj();
		req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept", "application/x-ms-application, image/jpeg, application/xaml+xml, image/gif, image/pjpeg, application/x-ms-xbap, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*");
		req.addHeader("Accept-Encoding", "gzip, deflate");
		req.addHeader("Accept-Language", "zh-CN");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "Keep-Alive");
		req.addHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
		req.addHeader("Host", "oatraining.petrochina");
		req.addHeader("Origin", "http://oatraining.petrochina");
		req.addHeader("Pragma", "no-cache");
		req.addHeader("Upgrade-Insecure-Requests", "1");
		
		req.addHeader("Referer", url + id);
		req.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.4 Safari/537.36");
		req.setMethod("post");
		req.setUrl(url + id);
		if (!"".equals(params.get("Confirm_01_Current_Ctrl$ReviewIdea"))) {
			params.put("hq_01_Current_Ctrl$SignIdea",params.get("Confirm_01_Current_Ctrl$ReviewIdea"));
		}
		req.getParams().putAll(params);
		
		System.out.println(params);
		
		RespObj resp = NetServer.service(req, new Task3ZxldpsPageDoTaskCallback());
		ActionResult result = new ActionResult(true, resp.getResponseBody());
		result.addCookies(resp.getCookies());
		return result;
	}
}
