package mobiAppPlat.oa.app.docapprove.service;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import mobiAppPlat.oa.app.docapprove.bean.HtmlParser;
import mobiAppPlat.oa.app.docapprove.bean.RespCallback;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class TaskDealPageLoadCallback implements RespCallback {

	public static void main(String[] args) {
		InputStream in = HtmlParser.class.getResourceAsStream("/mobiAppPlat/oa/app/docapprove/taskForm.txt");
		new TaskDealPageLoadCallback().execute(in);
	}

	public Object execute(InputStream body) {
		
		Document doc = HtmlParser.parser(body, null);
		CheckUserOnline.checkOnline(doc);
		Map<String, Object> result = new HashMap<String, Object>();
		Map<String, String> baseInfo = new HashMap<String, String>();
		Map<String, String> attchInfo = new HashMap<String, String>();

		// 附件
		Element attachmentTable = null;
		Elements elements = doc.getElementsByAttributeValueEnding("id", "FileTableCtrl_dgFile");
		if (elements.size() > 0) {
			attachmentTable = elements.get(0);
		}
		if (null != attachmentTable) {
			Elements attachmentTrs = attachmentTable.children().get(0).children();

			for (Element attachmentTr : attachmentTrs) {
				Element attachmentA = attachmentTr.getElementsByTag("a").get(0);
				attchInfo.put("name", attachmentA.html());
				attchInfo.put("id", attachmentA.attr("onclick").split("=")[1].split("'")[0]);
				attchInfo.put("docName", attachmentA.attr("title"));
			}
		}
		result.put("attachment", attchInfo);

		// 基本信息
		elements = doc.getElementsByAttributeValueEnding("id", "BaseInfoTab");
		if (elements.size() > 0) {
			Element e = elements.get(0);
			int i = 0;
			for (Element tr : e.getElementsByTag("tr")) {
				int j = 0;
				for (Element td : tr.getElementsByTag("td")) {
					if (j == 1) {
						if (i == 0) {
							baseInfo.put("docCode", td.html());
						} else if (i == 1) {
							baseInfo.put("docRecvCode", td.html());
						} else if (i == 2) {
							baseInfo.put("docTitle", td.html());
						} else if (i == 3) {
							baseInfo.put("docRecvDate", td.html());
						} else if (i == 4) {
							baseInfo.put("docType", td.html());
						} else if (i == 5) {
							baseInfo.put("docRegister", td.html());
						} else if (i == 6) {
							baseInfo.put("docFromUnit", td.html());
						} else if (i == 7) {
							baseInfo.put("docSendDate", td.html());
						} else if (i == 8) {
							baseInfo.put("carryType", td.html());
						} else if (i == 9) {
							baseInfo.put("mainUnit", td.html());
						}else if (i == 10) {
							baseInfo.put("isFiled", td.html());
						}
					}
					j++;
				}
				i++;
			}
		  }
		baseInfo.put("title", doc.getElementById("ctl01_title").html());
		Elements es = doc.getElementsByAttributeValueEnding("id", "btnOpenDocument");
		if(es.size()>0){
			String  items[] = es.get(0).attr("onclick").split("'");
			baseInfo.put("docId", items[5]);
		}
		result.put("baseInfo", baseInfo);
		return result;
	}

}
