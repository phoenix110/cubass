package mobiAppPlat.oa.app.docapprove;

import java.util.Map;

import mobiAppPlat.oa.app.docapprove.bean.ActionResult;
import mobiAppPlat.oa.app.docapprove.bean.NetServer;
import mobiAppPlat.oa.app.docapprove.bean.ReqObj;
import mobiAppPlat.oa.app.docapprove.bean.RespObj;
import mobiAppPlat.oa.app.docapprove.service.TaskDealPageLoadCallback;
import mobiAppPlat.oa.app.docapprove.utils.Utils;

public class DealTaskPage {
	
	public static ActionResult load(String taskUrl, Map<String, String> cookies){
		String url = Utils.getDomainName()+taskUrl;
		ActionResult ar = new ActionResult(true, "");
		ReqObj req = new ReqObj();
		req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept", "Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		req.addHeader("Accept-Language", "zh-CN,zh;q=0.8");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		req.addHeader("Host", "oatraining.petrochina");
		req.addHeader("Pragma", "no-cache");
		req.addHeader("Upgrade-Insecure-Requests", "1");
		req.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.4 Safari/537.36");
		req.setMethod("get");
		req.setUrl(url);
		RespObj tasks = NetServer.service(req, new TaskDealPageLoadCallback());
		ar.addCookies(tasks.getCookies());
		Map<String, Object> body = (Map<String, Object>)tasks.getResponseBody();
		Map<String, String> task = (Map<String, String>)body.get("task");
		ar.setData(body);
		ar.addCookies(tasks.getCookies());
		return ar;
	}

}
