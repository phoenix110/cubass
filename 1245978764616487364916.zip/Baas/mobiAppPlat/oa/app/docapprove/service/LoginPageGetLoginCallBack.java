package mobiAppPlat.oa.app.docapprove.service;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import mobiAppPlat.oa.app.docapprove.bean.HtmlParser;
import mobiAppPlat.oa.app.docapprove.bean.RespCallback;
import mobiAppPlat.oa.app.docapprove.service.LoginPageGetLoginCallBack;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;


/*
__VIEWSTATE           /wEPDwUKMTE0NTAwNjkxNGRkY88+L/l1ndiZap4Re0gDRnoUgHM=              
__VIEWSTATEGENERATOR  2BF08017                                                          
__EVENTVALIDATION     /wEWBAKurozdBQKG87HkBgK1qbSRCwKC3IeGDD8sl2cAkxki7U/SurMDRt6hS7zL  
txtLogin              ptr\dg_liuqing18                                                  
txtPassword           lq0511                                                            
btnLogin              登录                                                              
*/

public class LoginPageGetLoginCallBack implements RespCallback{
	
	private static final String[] NAMES = new String[]{
		"__VIEWSTATE", "__VIEWSTATEGENERATOR", "__EVENTVALIDATION", "btnLogin"
	};
	public static void main(String[] args){
		InputStream in = HtmlParser.class.getResourceAsStream("/com/justep/net/pages/getLoginPage.txt");
		RespCallback cb = new LoginPageGetLoginCallBack();
		Map<String, String> result = (Map<String, String>)cb.execute(in);
	}

	public Map<String, String> execute(InputStream body) {
		Document doc = HtmlParser.parser(body, null);
		Map<String, String> result = new HashMap<String, String>();
		for (String name : NAMES){
			Element e = doc.getElementById(name);
			if (e != null){
				result.put(name, e.attr("value"));
				System.out.println(name + ":" + e.attr("value"));
			}
		}
		return result;
	}

}
