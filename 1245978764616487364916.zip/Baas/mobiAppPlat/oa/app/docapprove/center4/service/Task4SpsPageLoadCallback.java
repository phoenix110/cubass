package mobiAppPlat.oa.app.docapprove.center4.service;

import java.io.InputStream;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import mobiAppPlat.oa.app.docapprove.bean.HtmlParser;
import mobiAppPlat.oa.app.docapprove.bean.RespCallback;
import mobiAppPlat.oa.app.docapprove.service.CheckUserOnline;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.justep.baas.data.ColumnValue;
import com.justep.baas.data.DataType;
import com.justep.baas.data.Row;
import com.justep.baas.data.RowState;
import com.justep.baas.data.Table;
import com.justep.baas.data.Transform;

public class Task4SpsPageLoadCallback implements RespCallback{
	private static final String[] NAMES = new String[]{
		"__VIEWSTATE",
		"__VIEWSTATEGENERATOR",
		"__EVENTVALIDATION",
		"ctl00$forward_0",
		"ctl00$backwords_0",
		"ctl00$txtforward_0",
		"ctl00$txtbackwords_0",
		"ReviewStart_01_Current_Ctrl_UsersID",
		"ReviewStart_01_Current_Ctrl$UsersName",
		"ctl03$WordMarkNo",
		"ctl03$DraftUnit",
		"ctl03$RegisterDisplayName",
		"ctl03$RegisterPhoneNo",
		"ctl03$ReceiveDate",
		"ctl03$ReceiveFileNo",
		"ctl03$CreateDate",
		"ctl03$Amount",
		"ctl03$FileTitle",
		"ctl03$Topic",
		"ctl03$GiveMainUnit",
		"ctl03$GiveCopyUnit",
		"ctl03$RegisterDeptID",
		"ctl03$RegisterDept",
		"ctl03$Register",
		"ctl03$GiveMainUnitID",
		"ctl03$GiveCopyUnitID",
		"ctl03$ReceiveTime",
		"ctl03$CreateTime",
		"ctl03$DocID",
		"ctl03$DocWebService",
		"ctl03$Accessory",
		"ctl03$HeadTemplate",
		"ctl03$DrafterIncID",
		"ctl03$DrafterIncName",
		"ctl03$DrafterDeptID",
		"ctl03$DrafterDeptName",
		"ctl03$ReceiveRemark",
		
		//当有历史记录的时候需要取如下数据
		"ctl04$WordMarkNo",
		"ctl04$DraftUnit",
		"ctl04$RegisterDisplayName",
		"ctl04$RegisterPhoneNo",
		"ctl04$ReceiveDate",
		"ctl04$ReceiveFileNo",
		"ctl04$CreateDate",
		"ctl04$Amount",
		"ctl04$FileTitle",
		"ctl04$Topic",
		"ctl04$GiveMainUnit",
		"ctl04$GiveCopyUnit",
		"ctl04$RegisterDeptID",
		"ctl04$RegisterDept",
		"ctl04$Register",
		"ctl04$GiveMainUnitID",
		"ctl04$GiveCopyUnitID",
		"ctl04$ReceiveTime",
		"ctl04$CreateTime",
		"ctl04$DocID",
		"ctl04$DocWebService",
		"ctl04$Accessory",
		"ctl04$HeadTemplate",
		"ctl04$DrafterIncID",
		"ctl04$DrafterIncName",
		"ctl04$DrafterDeptID",
		"ctl04$DrafterDeptName",
		"ctl04$ReceiveRemark"
	};
	
	
	public Object execute(InputStream body) {
		Document doc = HtmlParser.parser(body, null);
		
		CheckUserOnline.checkOnline(doc);
		
		Map<String, Object> result = new HashMap<String, Object>();
		Map<String, String> pageState = new HashMap<String, String>();
		result.put("pageState", pageState);
		for (String name : NAMES){
			Elements es = doc.getElementsByAttributeValue("name", name);
			if (es.size()>=1){
				String value = "";
				Element e = es.get(0);
				if (e.tagName().equals("textarea")){
					value = e.text();
				}else{
					value = es.get(0).attr("value");
				}
				
				pageState.put(name, value);
			}
		}
		/*
		 * 判断表单中的数据是带3的还是带4的
		 * 当第一次执行批办环节时，表单中的数据name或id是带3的；当再执行批办环节时，表单中的数据name或id是带4的。
		 */
		if (doc.getElementsByAttributeValue("name", "ctl03$WordMarkNo").size() == 0) {
			pageState.put("type", "4");
		}else {
			pageState.put("type", "3");
		}
		
		Map<String, String> task = new HashMap<String, String>();
		for (String column : NAMES){
			task.put(column, pageState.get(column));	
		}
		task.put("type", pageState.get("type"));
		
		//获取workflowFormID
		String onclickStr = doc.getElementsByAttributeValue("name","ReviewStart_01_Current_Ctrl$selectUser").get(0).attr("onclick");
		String onclickStr_child[] = onclickStr.split(",");
		String str = onclickStr_child[onclickStr_child.length-1];
		String workflowFormID = str.split("'")[1];

		pageState.put("workflowFormID", workflowFormID);
		task.put("workflowFormID", workflowFormID);
		
		
		//定义返回附件数据的table对象
		Map<String, DataType> columns = new LinkedHashMap<String, DataType>();
		columns.put("id", DataType.STRING);
		columns.put("name", DataType.STRING);
		columns.put("docName", DataType.STRING);
		Table table = new Table(columns);
		
		//获取附件数据
		Element attachmentTable1 = doc.getElementById("ctl03_FileTableCtrl_dgFile");
		Element attachmentTable2 = doc.getElementById("ctl04_FileTableCtrl_dgFile");
		if (null != attachmentTable1 || null != attachmentTable2) {
			Element attachmentTable = null;
			if (null != attachmentTable1) {
				attachmentTable = attachmentTable1;
			}
			if (null != attachmentTable2) {
				attachmentTable = attachmentTable2;
			}
			Elements attachmentTrs = attachmentTable.children().get(0).children();
			for (Element attachmentTr : attachmentTrs) {
				Element attachmentA = attachmentTr.getElementsByTag("a").get(0);
				
				Map<String, ColumnValue> column = new HashMap<String, ColumnValue>();
				column.put("name", new ColumnValue(attachmentA.html()));
				column.put("id", new ColumnValue(attachmentA.attr("onclick").split("=")[1].split("'")[0]));
				column.put("docName", new ColumnValue(attachmentA.attr("title")));
				Row row = new Row(column, RowState.NEW);
				table.appendRow(row);
			}
		}
		result.put("attachment", Transform.tableToJson(table));
		
		//获取审批记录数据 
		JSONArray history = new JSONArray();
		
		Elements elements = doc.getElementsByAttributeValueMatching("id", "^ctl.*_barTD$");
		if (elements.size()>0) {
			for (int i = 0; i < elements.size(); i++) {
				Element element = elements.get(i);
				
				Elements element_spans = element.getElementsByTag("span");
				String title = "";
				for(Element element_span : element_spans){
					if (element_span.getElementsByTag("span").size()==1) {
						title = element_span.html();
					}
				}
				
				if (!"总经理办拟办".equals(title) && !"公司领导批示".equals(title)) {
					 continue;
				}
				//定义子历史记录对象
				JSONObject childHistory = new JSONObject();
				history.add(childHistory);
				//定义子历史记录的数据列表
				JSONArray childHistoryDataList = new JSONArray();
				
				childHistory.put("title", title);
				childHistory.put("data", childHistoryDataList);
				
				Element elementTable_parent = element.parent().parent().parent();
				Elements elementTables = elementTable_parent.getElementsByTag("table");
				for (Element elementTable : elementTables) {
					if (elementTable.getElementsByTag("table").size() == 1) {
						JSONObject jsob = new JSONObject();
						String DisplayName = elementTable.getElementsByAttributeValueMatching("id","DisplayName$").get(0).html();
						String DeptName = elementTable.getElementsByAttributeValueMatching("id","DeptName$").get(0).html();
						String Time = elementTable.getElementsByAttributeValueMatching("id","Time$").get(0).html();
						String Idea = elementTable.getElementsByAttributeValueMatching("id","Idea$").get(0).html();
						
						jsob.put("审核人", DisplayName);
						jsob.put("部门", DeptName);
						jsob.put("时间", Time);
						jsob.put("意见", Idea);
						
						childHistoryDataList.add(jsob);
					}
					
				}
				
			}
		}
		
		result.put("history", history);
		result.put("task", task);
		return result;
	}

}
