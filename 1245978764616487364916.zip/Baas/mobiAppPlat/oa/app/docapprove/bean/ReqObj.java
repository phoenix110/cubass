package mobiAppPlat.oa.app.docapprove.bean;

import java.util.HashMap;
import java.util.Map;

public class ReqObj {
	private Map<String, String> params = new HashMap<String, String>();
	private Object postBody = null;
	private String url = "";
	private String method = "get";
	private Map<String, String> headers = new HashMap<String, String>();
	
	public Map<String, String> getHeaders(){
		return headers;
	}
	
	public void addHeader(String name, String value){
		headers.put(name, value);
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public Object getPostBody() {
		return postBody;
	}

	public void setPostBody(Object postBody) {
		this.postBody = postBody;
	}

	public Map<String, String> getParams() {
		return params;
	}

	public void setParams(Map<String, String> params) {
		this.params = params;
	}
	
	public void addParam(String name, String value){
		this.params.put(name, value);
	}
}
