package ticket;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSONObject;
import com.justep.baas.action.ActionContext;

public class CommAction {

	public static JSONObject loadQRcode(JSONObject params, ActionContext context) throws IOException {
		HttpServletResponse response = (HttpServletResponse) context.get(ActionContext.RESPONSE);
		String num = params.getString("num");
		String name = params.getString("name");
		System.out.println("name==========:"+name);
		 QRUtil.writeToStream("https://oa.dgtx.com.cn/x5/UI2/ticket/users.w?name="+name+"&num="+num, response.getOutputStream());
		//QRUtil.writeToStream("http://192.168.1.3:8082/x5/UI2/ticket/users.w?name="+name+"&num="+num, response.getOutputStream());

		return null;
	}

}
