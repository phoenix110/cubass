package forNet.net.pages;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import forNet.net.NetServer;
import forNet.net.ReqObj;
import forNet.net.RespObj;
import forNet.net.util.Utils;

public class LoginPage {
	
	//private static final String LOGIN_URL = "http://oatraining.petrochina/Task%20Portal/Login.aspx?ReturnUrl=%2ftask+portal%2findex.aspx";
	
	private String loginUrl;
	
	 public LoginPage(String loginUrl){
		 this.loginUrl=loginUrl;
	 }
	
	public  ActionResult login(Map<String,String> params){
		ActionResult ar = new ActionResult(true, "");
		try{
			Map<String, String> cookies = new HashMap<String, String>();
			RespObj getLoginPageResult = getLoginPage();
			cookies.putAll(getLoginPageResult.getCookies());

			RespObj loginResult = doLogin(params, cookies, (Map<String, String>)getLoginPageResult.getResponseBody());
			
			cookies.putAll(loginResult.getCookies());
			
			RespObj indexResult = getIndexPage(cookies);
			
			cookies.putAll(indexResult.getCookies());
			
			Map<String, String> data = (Map<String, String>)indexResult.getResponseBody();
			
			if (!"true".equals(data.get("flag"))){
				ar.setFlag(false);
				ar.setData( data.get("msg")) ;
			}else{
				ar.addCookies(cookies);
				System.out.println(ar.getCookies());
			}

		}catch(Exception e){
			e.printStackTrace();
			ar.setFlag(false);
			ar.setData(e.getMessage()) ;
			
		}
		
		return ar;
	}
	
	 
	private  RespObj getLoginPage(){
		ReqObj req = new ReqObj();
		req.addHeader("Accept", "Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		//req.addHeader("Accept-Encoding", "gzip, deflate, sdch"); //不压缩
		req.addHeader("Accept-Language", "zh-CN,zh;q=0.8");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		req.addHeader("Host", "oatraining.petrochina");
		req.addHeader("Pragma", "no-cache");
		req.addHeader("Upgrade-Insecure-Requests", "1");
		req.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.4 Safari/537.36");
		req.setMethod("get");
		req.setUrl(this.loginUrl);
		RespObj result = NetServer.service(req, new LoginPageGetLoginCallBack());
		return result;
	}
	
	private  RespObj getIndexPage(Map<String, String> cookies){
		ReqObj req = new ReqObj();
		req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept", "Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		//req.addHeader("Accept-Encoding", "gzip, deflate, sdch"); //不压缩
		req.addHeader("Accept-Language", "zh-CN,zh;q=0.8");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		req.addHeader("Host", "oatraining.petrochina");
		req.addHeader("Pragma", "no-cache");
		req.addHeader("Upgrade-Insecure-Requests", "1");
		req.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.4 Safari/537.36");
		req.setMethod("get");
		req.setUrl("http://oatraining.petrochina/task%20portal/index.aspx");
		RespObj result = NetServer.service(req, new LoginPageGetIndexCallback());
		return result;
	}
	
	
	
	/*
	 	__VIEWSTATE           /wEPDwUKMTE0NTAwNjkxNGRkY88+L/l1ndiZap4Re0gDRnoUgHM=              
		__VIEWSTATEGENERATOR  2BF08017                                                          
		__EVENTVALIDATION     /wEWBAKurozdBQKG87HkBgK1qbSRCwKC3IeGDD8sl2cAkxki7U/SurMDRt6hS7zL  
		txtLogin              ptr\dg_liuqing18                                                  
		txtPassword           lq0511                                                            
		btnLogin              登录                                                              
	 * 
	 */
	private  RespObj doLogin( Map<String, String> userParams, Map<String, String> cookies, Map<String, String> params){
		ReqObj req = new ReqObj();
		req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		req.addHeader("Accept-Encoding", "gzip, deflate");
		req.addHeader("Accept-Language", "zh-CN,zh;q=0.8");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		req.addHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
		req.addHeader("Host", "oatraining.petrochina");
		req.addHeader("Origin", "http://oatraining.petrochina");
		req.addHeader("Pragma", "no-cache");
		req.addHeader("Upgrade-Insecure-Requests", "1");
		req.addHeader("Referer", this.loginUrl);
		req.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.4 Safari/537.36");
		req.setMethod("post");
		req.setUrl(this.loginUrl);
		if (params != null){
			req.getParams().putAll(params);
		}
		
		Iterator<String> ir =userParams.keySet().iterator();
		while(ir.hasNext()){
			String paramName=String.valueOf(ir.next());
			String paramValue=userParams.get(paramName);
			req.addParam(paramName, paramName);
			req.addParam(paramValue, paramValue);
		}
		
		RespObj result = NetServer.service(req, new LoginPageDoLoginCallback());
		return result;
	}

	
	
}
