package admin.common;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.namespace.QName;
import javax.xml.rpc.ParameterMode;

import org.apache.axis.client.Call;
import org.apache.axis.client.Service;
import org.apache.axis.encoding.XMLType;
import org.apache.commons.lang.StringUtils;

import mobiAppPlat.oa.app.docapprove.bean.ActionResult;
import mobiAppPlat.oa.app.docapprove.bean.NetServer;
import mobiAppPlat.oa.app.docapprove.bean.ReqObj;
import mobiAppPlat.oa.app.docapprove.bean.RespObj;
import mobiAppPlat.oa.app.docapprove.service.LoginPageDoLoginCallback;
import mobiAppPlat.oa.app.docapprove.service.LoginPageGetIndexCallback;
import mobiAppPlat.oa.app.docapprove.service.LoginPageGetLoginCallBack;
import mobiAppPlat.oa.app.docapprove.utils.Utils;

import com.alibaba.fastjson.JSONObject;
import com.justep.baas.action.ActionContext;
import com.justep.baas.data.sql.SQLException;

public class ElDocManager {
	// 打开正文
		public static JSONObject testLoadDoc2(JSONObject params, ActionContext context) throws Exception {
			HttpServletResponse response = (HttpServletResponse) context.get(ActionContext.RESPONSE);
			String docid = params.getString("docID");

			String serviceUrl = Utils.getOaUrl("openDoc");
			Service service = new Service();
			Call call = (Call) service.createCall();// 通过service创建call对象

			call.setTargetEndpointAddress(new java.net.URL(serviceUrl));

			call.addParameter(new QName("http://tempuri.org/", "docID"), XMLType.XSD_STRING, ParameterMode.IN);

			call.setReturnType(XMLType.XSD_STRING); // 返回参数的类型
			call.setUseSOAPAction(true);
			call.setOperationName(new QName("http://tempuri.org/", "GetBlackDocData"));
			call.setSOAPActionURI("http://tempuri.org/GetBlackDocData");

			// 就是要加上要调用的方法Add,不然也会报错
			// Object 数组封装了参数，参数为"This is Test!",调用processService(String arg)
			String ret = (String) call.invoke(new Object[] { docid });
			System.out.println("-" + ret);
			byte[] bt = null;
			sun.misc.BASE64Decoder decoder = new sun.misc.BASE64Decoder();
			bt = decoder.decodeBuffer(ret);
			String uuid = UUID.randomUUID().toString();
			File docFile = new File("D:/pdf/"+uuid+".doc");
			if (!docFile.exists() && docFile.isDirectory())
            {
				docFile.mkdirs();
            }
            FileOutputStream fos2 = new FileOutputStream(docFile);
            BufferedOutputStream bos2 = new BufferedOutputStream(fos2);
            bos2.write(bt);
            fos2.close();
            bos2.close();
			OfficeToPDF wordToPDF = new OfficeToPDF();
			wordToPDF.docToPdf(docFile, new File("D:/pdf/" + uuid + ".pdf"));
			docFile.delete();
			File pdfFile = new File("D:/pdf/" + uuid + ".pdf");
			InputStream inputStream = new FileInputStream(pdfFile);
			String fileNameKey = "filename";
			response.addHeader("Content-Disposition", "inline; " + fileNameKey + "=\"" + uuid + "\"");
			OutputStream out = response.getOutputStream();
			try {
				int read = 0;
				while ((read = inputStream.read()) != -1) {
					out.write(read);
				}
			} finally {
				inputStream.close();
				out.close();
			}
			return null;
		}

	public static JSONObject testLoadDoc1(JSONObject params, ActionContext context) throws ServletException, IOException, SQLException, NamingException, java.sql.SQLException {
		HttpServletResponse response = (HttpServletResponse) context.get(ActionContext.RESPONSE);
		HttpServletRequest request = (HttpServletRequest) context.get(ActionContext.REQUEST);
		String requestUrl = request.getParameter("requestUrl");
		String fileName = request.getParameter("fileName");
		if (fileName == null || fileName.equals("")) {
			fileName = "公文";
		}
		System.out.println("requestUrl-----------------:" + requestUrl);
		response.setHeader("Cache-Control", "pre-check=0, post-check=0, max-age=0");
		// URLConnection urlconnection = null;
		// URL url = null;
		// url = new URL(requestUrl);
		String prefix = requestUrl.substring(requestUrl.lastIndexOf(".") + 1);
		// System.out.println("contentType:"+prefix);
		// urlconnection = (HttpURLConnection) url.openConnection();
		// urlconnection.connect();
		JSONObject jsonObj = loginForCookie(params, context);
		final Map<String, String> COOKIES = (Map<String, String>) jsonObj.get("cookies");
		URL url;
		url = new URL(requestUrl);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.addRequestProperty("Cookie", Utils.map2String(COOKIES));
		conn.addRequestProperty("Accept", "*/*");
		conn.addRequestProperty("Accept-Encoding", "gzip, deflate");
		conn.addRequestProperty("Accept-Language", "zh-CN");
		conn.addRequestProperty("Connection", "keep-alive");
		conn.addRequestProperty("Host", "oa.petrochina");
		conn.addRequestProperty(
				"User-Agent",
				"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/4.0; chromeframe/30.0.1599.69; EmbeddedWB 14.52 from: http://www.bsalsa.com/ EmbeddedWB 14.52; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET CLR 1.1.4322; InfoPath.2; .NET4.0C; .NET4.0E)");

		conn.addRequestProperty(
				"User-Agent",
				"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/4.0; chromeframe/30.0.1599.69; EmbeddedWB 14.52 from: http://www.bsalsa.com/ EmbeddedWB 14.52; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET CLR 1.1.4322; InfoPath.2; .NET4.0C; .NET4.0E)");

		String uuid = UUID.randomUUID().toString();
		File newFile = new File("D:/pdf/" + uuid + "." + prefix);
		InputStream ins = conn.getInputStream();
		FileOutputStream fout = new FileOutputStream(newFile);
		int tmpi = 0;
		while ((tmpi = ins.read()) != -1) {
			fout.write(tmpi);
		}
		fout.close();
		ins.close();
		File docFile = new File("D:/pdf/" + uuid + "." + prefix);
		if (prefix.equals("doc")) {
			OfficeToPDF wordToPDF = new OfficeToPDF();
			wordToPDF.docToPdf(docFile, new File("D:/pdf/" + uuid + ".pdf"));
			docFile.delete();
		}
		File pdfFile = new File("D:/pdf/" + uuid + ".pdf");
		InputStream inputStream = new FileInputStream(pdfFile);
		String fileNameKey = "filename";
		response.addHeader("Content-Disposition", "inline; " + fileNameKey + "=\"" + fileName + "\"");
		OutputStream out = response.getOutputStream();
		try {
			int read = 0;
			while ((read = inputStream.read()) != -1) {
				out.write(read);
			}
		} finally {
			inputStream.close();
			out.close();
		}
		return null;
	}

	public static JSONObject loginForCookie(JSONObject params, ActionContext context) {
		boolean flag = true;
		String msg = null;
		ActionResult ar = null;
		try {
			String USERNAME = params.getString("loginName"); // (String)request.getAttribute("loginName");
			String PASSWORD = params.getString("password");
			if (StringUtils.isEmpty(USERNAME) || StringUtils.isEmpty(PASSWORD)) {
				throw new RuntimeException("用户名或密码为空，请重新登录");
			}
			ar = login(USERNAME, PASSWORD);
			if (!ar.isFlag()) {
				flag = false;
				msg = ar.getData() + "";
			} else {
				// CookiesUtils.updateCookies(context,
				// ar.getCookies(),COOKIE_ID);
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			msg = e.getMessage();
		}
		JSONObject result = new JSONObject();
		result.put("flag", flag);
		result.put("msg", msg);
		result.put("cookies", ar.getCookies());
		return result;
	}

	public static ActionResult login(String username, String password) {
		ActionResult ar = new ActionResult(true, "");
		try {
			Map<String, String> cookies = new HashMap<String, String>();
			RespObj getLoginPageResult = getLoginPage();
			cookies.putAll(getLoginPageResult.getCookies());

			RespObj loginResult = doLogin(username, password, cookies, (Map<String, String>) getLoginPageResult.getResponseBody());
			// System.out.println("登陆成功，登陆人："+USERNAME);
			cookies.putAll(loginResult.getCookies());
			RespObj indexResult = getIndexPage(cookies);
			cookies.putAll(indexResult.getCookies());
			// ActionResult arNew = getTasksList(cookies);
			// cookies.putAll(arNew.getCookies());

			Map<String, String> data = (Map<String, String>) indexResult.getResponseBody();

			if (!"true".equals(data.get("flag"))) {
				ar.setFlag(false);
				ar.setData(data.get("msg"));
			} else {
				ar.addCookies(cookies);
			}

		} catch (Exception e) {
			e.printStackTrace();
			ar.setFlag(false);
			ar.setData(e.getMessage());

		}
		return ar;
	}

	private static RespObj doLogin(String username, String password, Map<String, String> cookies, Map<String, String> params) {
		ReqObj req = new ReqObj();
		req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		req.addHeader("Accept-Encoding", "gzip, deflate");
		req.addHeader("Accept-Language", "zh-CN,zh;q=0.8");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		req.addHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
		req.addHeader("Host", "oa.petrochina");
		req.addHeader("Origin", "http://oa.petrochina");
		req.addHeader("Pragma", "no-cache");
		req.addHeader("Upgrade-Insecure-Requests", "1");
		req.addHeader("Referer", "http://oa.petrochina/Task%20Portal/Login.aspx?ReturnUrl=%2ftask+portal%2findex.aspx");
		req.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.4 Safari/537.36");
		req.setMethod("post");
		req.setUrl("http://oa.petrochina/Task%20Portal/Login.aspx?ReturnUrl=%2ftask+portal%2findex.aspx");
		if (params != null) {
			req.getParams().putAll(params);
		}
		req.addParam("txtLogin", username);
		req.addParam("txtPassword", password);

		RespObj result = NetServer.service(req, new LoginPageDoLoginCallback());
		return result;
	}

	private static RespObj getIndexPage(Map<String, String> cookies) {
		ReqObj req = new ReqObj();
		req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept", "Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		// req.addHeader("Accept-Encoding", "gzip, deflate, sdch"); //不压缩
		req.addHeader("Accept-Language", "zh-CN,zh;q=0.8");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		req.addHeader("Host", "oatraining.petrochina");
		req.addHeader("Pragma", "no-cache");
		req.addHeader("Upgrade-Insecure-Requests", "1");
		req.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.4 Safari/537.36");
		req.setMethod("get");
		req.setUrl("http://oa.petrochina/task%20portal/index.aspx");
		RespObj result = NetServer.service(req, new LoginPageGetIndexCallback());
		return result;
	}

	private static RespObj getLoginPage() {
		ReqObj req = new ReqObj();
		req.addHeader("Accept", "Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		// req.addHeader("Accept-Encoding", "gzip, deflate, sdch"); //不压缩
		req.addHeader("Accept-Language", "zh-CN,zh;q=0.8");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		req.addHeader("Host", "oatraining.petrochina");
		req.addHeader("Pragma", "no-cache");
		req.addHeader("Upgrade-Insecure-Requests", "1");
		req.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.4 Safari/537.36");
		req.setMethod("get");
		req.setUrl("http://oa.petrochina/Task%20Portal/Login.aspx?ReturnUrl=%2ftask+portal%2findex.aspx");
		RespObj result = NetServer.service(req, new LoginPageGetLoginCallBack());
		return result;
	}

}
