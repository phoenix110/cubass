package mobiAppPlat.oa.app.org.servce;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import mobiAppPlat.oa.app.docapprove.bean.HtmlParser;
import mobiAppPlat.oa.app.docapprove.bean.RespCallback;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class AllPersonOrgFirstPageLoadCallback implements RespCallback{

	/*
	 * 获取根节点数据
	 */
	public Object execute(InputStream body) {
		
		//定义要返回的数据对象
		Map<String, Object>  map = new HashMap<String, Object>();
		
		//将抓取到的数据转成document对象。
		Document doc = HtmlParser.parser(body, null);
		
		Map<String, Object>  orgMap = new HashMap<String, Object>();
		//抓取根节点的名称
		Element txtUserDeptName = doc.getElementById("txtUserIncName");
		if ("textarea".equals(txtUserDeptName.tagName())) {
			map.put(txtUserDeptName.text(), orgMap);
		}else {
			map.put(txtUserDeptName.attr("value"), orgMap);
		}
		//抓取根节点的ID
		Element txtUserDeptID = doc.getElementById("txtUserIncID");
		if ("textarea".equals(txtUserDeptID.tagName())) {
			orgMap.put(txtUserDeptID.text(), "");
		}else {
			orgMap.put(txtUserDeptID.attr("value"), "机构");
		}
		
		return map;
	}
	

}