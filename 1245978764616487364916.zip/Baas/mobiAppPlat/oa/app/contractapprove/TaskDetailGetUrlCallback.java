package mobiAppPlat.oa.app.contractapprove;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import forNet.net.HtmlParser;
import forNet.net.RespCallback;

public class TaskDetailGetUrlCallback implements RespCallback {

	public Object execute(InputStream body) {
		String flag = "true";
		Document doc = HtmlParser.parser(body, null);
		String msg = doc.getElementById("ifWorkArea").attr("src");
		Map<String, String> result = new HashMap<String, String>();
		result.putAll(PageUtils.getPostInfo(doc));
		result.put("flag", flag);
		result.put("postSrc", msg);
		return result;
	}

}
