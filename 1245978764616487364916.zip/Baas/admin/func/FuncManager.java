package admin.func;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import com.alibaba.fastjson.JSONObject;
import com.justep.baas.action.ActionContext;
import com.justep.baas.data.DataUtils;
import com.justep.baas.data.Row;
import com.justep.baas.data.Table;

/**
 * 功能管理
 * 
 * @author luofei
 */
public class FuncManager {

	
	
	/**
	 * 更新组织
	 * @param params
	 * @param context
	 * @return
	 * @throws NamingException
	 * @throws SQLException
	 */
	public static JSONObject updateFunc(JSONObject params, ActionContext context) throws SQLException, NamingException {
		JSONObject jsonObj = new JSONObject();
		Connection conn = context.getConnection("x5Sys");
		String funcId = params.getString("funcId");
		
		String sql = "select * from SA_OPFunction where sFID like ?  order by sID asc";
		List<Object> sqlParams = new ArrayList<Object>();
		sqlParams.add("%"+funcId+"%");
		Table table = DataUtils.queryData(conn, sql, sqlParams, null, null, null);
		List<Row> rows = table.getRows();
		String updateSql="update SA_OPFunction set  sFCode=?, sFName=? where sID=?";
		PreparedStatement stmt =null;
		for (Row row : rows) {
			stmt=conn.prepareStatement(updateSql);
			String parentId=row.getString("sParent");
			Row  parent= new FuncManager().getParent(conn,parentId);
			//根节点
			if(parent==null){
				stmt.setString(1, "/"+row.getString("sCode"));
				stmt.setString(2, "/"+row.getString("sName"));
			}else{
				stmt.setString(1, parent.getString("sFCode")+"/"+row.getString("sCode"));
				stmt.setString(2, parent.getString("sFName")+"/"+row.getString("sName"));
			}
			stmt.setString(3, row.getString("sID"));
			stmt.execute();
		}
		return jsonObj;
	  }
	
	/**
	 * 获取父组织
	 * @param conn
	 * @param orgId
	 * @return
	 */
	  private  Row  getParent(Connection conn,String orgId){
		List<Object> sqlParams = new ArrayList<Object>();
		sqlParams.add(orgId);
		String sql = "select * from SA_OPFunction where sID =?";
		Table table = DataUtils.queryData(conn, sql, sqlParams, null, null, null);
		if(table.getRows().size()>0){
			return table.getRows().get(0);
		}
		return null;
		
	}
	
	/**
	 * 删除功能
	 * 
	 * @param params
	 * @param context
	 * @return
	 * @throws NamingException
	 * @throws SQLException
	 */
	public static JSONObject deleteFunc(JSONObject params, ActionContext context) throws SQLException, NamingException {
		JSONObject jsonObj = new JSONObject();
		Connection conn = context.getConnection("x5Sys");
		String funId = params.getString("funId");
		String sql = "select * from SA_OPFunction where sFID like ?";
		List<Object> sqlParams = new ArrayList<Object>();
		sqlParams.add("%"+funId+"%");
		Table table = DataUtils.queryData(conn, sql, sqlParams, null, null, null);
		List<Row> rows = table.getRows();
		for (Row row : rows) {
			new FuncManager().deleteRelation(conn, row.getString("sID"));
		}
		// 删除功能信息
		String deleteSql = "delete from SA_OPFunction where sFID like ?";
		PreparedStatement stmt = conn.prepareStatement(deleteSql);
		stmt.setString(1, "%"+funId+"%");
		stmt.execute();

		return jsonObj;
	}

	/**
	 * 删除权限的关联对象
	 * 
	 * @param conn
	 * @param orgId
	 * @throws SQLException
	 */
	private void deleteRelation(Connection conn, String funcId) throws SQLException {
		// 删除角色权限信息
		String deleteSql = "delete from SA_OPPermission where sPermissionRoleID=?";
		PreparedStatement stmt = conn.prepareStatement(deleteSql);
		stmt.setString(1, funcId);
		stmt.execute();
		if (stmt != null) {
			stmt.close();
		}
	}

}
