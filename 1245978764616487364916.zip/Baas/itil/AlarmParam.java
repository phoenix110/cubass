package itil;

import itil.AlarmCondition;

public class AlarmParam {

	private String userId;
	private AlarmCondition condition;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public AlarmCondition getCondition() {
		return condition;
	}

	public void setCondition(AlarmCondition condition) {
		this.condition = condition;
	}

}
