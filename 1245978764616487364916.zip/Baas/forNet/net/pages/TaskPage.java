package forNet.net.pages;

import java.util.Map;

import forNet.net.NetServer;
import forNet.net.ReqObj;
import forNet.net.RespObj;
import forNet.net.util.Utils;

public class TaskPage {
	private final static String BASE_URL = "http://oatraining.petrochina/Task%20Portal/UITaskPage/TaskForm.aspx?ID=";
	public static ActionResult load(String id, String type, String status, Map<String, String> cookies){
		ActionResult ar = new ActionResult(true, "");
		//TODO 当前只支持“人事处处室发文”
		if (!type.equals("人事处处室发文") || !status.equals("处室审核")){
			throw new RuntimeException("当前只支持  “人事处处室发文” 的  “处室审核”  功能");
		}
		
		ReqObj req = new ReqObj();
		req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept", "Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		//req.addHeader("Accept-Encoding", "gzip, deflate, sdch"); //不压缩
		req.addHeader("Accept-Language", "zh-CN,zh;q=0.8");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		req.addHeader("Host", "oatraining.petrochina");
		req.addHeader("Pragma", "no-cache");
		req.addHeader("Upgrade-Insecure-Requests", "1");
		req.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.4 Safari/537.36");
		req.setMethod("get");
		req.setUrl(BASE_URL + id);
		RespObj tasks = NetServer.service(req, new TaskPageLoadCallback());
		ar.addCookies(tasks.getCookies());
		Map<String, Object> body = (Map<String, Object>)tasks.getResponseBody();
		Map<String, String> task = (Map<String, String>)body.get("task");
		task.put("id", id);
		ar.setData(body);
		ar.addCookies(tasks.getCookies());
		return ar;
	}
	

	public static ActionResult doTask(String id, String ReviewIdea, Map<String, String> cookies, Map<String, String> params){
		ReqObj req = new ReqObj();
		req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		//req.addHeader("Accept-Encoding", "gzip, deflate");
		req.addHeader("Accept-Language", "zh-CN,zh;q=0.8");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		req.addHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
		req.addHeader("Host", "oatraining.petrochina");
		req.addHeader("Origin", "http://oatraining.petrochina");
		req.addHeader("Pragma", "no-cache");
		req.addHeader("Upgrade-Insecure-Requests", "1");
		
		req.addHeader("Referer", BASE_URL + id);
		req.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.4 Safari/537.36");
		req.setMethod("post");
		req.setUrl(BASE_URL + id);
		if (params != null){
			req.getParams().putAll(params);
		}
		
		if (ReviewIdea==null || ReviewIdea.trim().equals("")){
			throw new RuntimeException("审核意见不能为空");
		}
		req.addParam("Audit_00_Current_Ctrl$ReviewIdea", ReviewIdea);
		
		RespObj resp = NetServer.service(req, new TaskPageDoTaskCallback());
		ActionResult result = new ActionResult(true, resp.getResponseBody());
		result.addCookies(resp.getCookies());
		return result;
	}

}
