package mobiAppPlat.oa.app.docapprove.service;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import mobiAppPlat.oa.app.docapprove.bean.HtmlParser;
import mobiAppPlat.oa.app.docapprove.bean.RespCallback;
import mobiAppPlat.oa.app.docapprove.bean.Task;
import mobiAppPlat.oa.app.docapprove.service.CheckUserOnline;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class TaskListPageCallback implements RespCallback {
	

	private static final String statusList = "待收公文,科室登记,科室送办,科室批办,承办,办公室登记,办公室拟办,中心领导批示,公司领导批示," + "处室登记,处室送办,处室批办";

	private String listType;

	public TaskListPageCallback() {
	}

	public TaskListPageCallback(String listType) {
		this.listType = listType;
	}

	public Object execute(InputStream body) {

		Map<String, Object> pageSate = new HashMap<String, Object>();
		List<Task> taskList = new ArrayList<Task>();
		List<Task> dealTaskList = new ArrayList<Task>();
		Document doc = HtmlParser.parser(body, null);
		CheckUserOnline.checkOnline(doc);
		//System.out.println("================="+this.listType);
		pageSate.put("__VIEWSTATE", doc.getElementById("__VIEWSTATE")==null?"/wEPDwULLTE5MDI3MjgwOTYPFhAeGXB0clxkZ19saXVxaW5nMThTc19Vc2VySUQFEHB0clxkZ19saXVxaW5nMTgeEWtleV9jdXJyZW50QWN0aW9uBQlyZWFkeXRhc2seFGtleV9DdXJUYXNrUGFnZUluZGV4BQEzHhxrZXlfQ3VyRG9uZVNlbmRUYXNrUGFnZUluZGV4AgEeH2tleV9DdXJEb25lUmVjZWl2ZVRhc2tQYWdlSW5kZXgCAR4Ua2V5X1Rhc2tDb3VudFByZVBhZ2UCCh4ca2V5X1Rhc2tEb25lU2VuZENvdW50UHJlUGFnZQIFHh9rZXlfVGFza0RvbmVSZWNlaXZlQ291bnRQcmVQYWdlAgUWAgICD2QWGAIDDw8WAh4EVGV4dAUCNDlkZAIFDw8WAh8IBQE1ZGQCBw8PFgQfCAUJ5LiK5LiA6aG1HgdFbmFibGVkZ2RkAgsPEGQQFQUBMQEyATMBNAE1FQUBMQEyATMBNAE1FCsDBWdnZ2dnFgECAmQCDw8PFgIfCAUBOGRkAhEPDxYCHwgFATJkZAITDw8WBB8IBQnkuIrkuIDpobUfCWhkZAIXDxBkEBUCATEBMhUCATEBMhQrAwJnZxYBZmQCGw8PFgIfCAUCMjNkZAIdDw8WAh8IBQE1ZGQCHw8PFgQfCAUJ5LiK5LiA6aG1HwloZGQCIw8QZBAVBQExATIBMwE0ATUVBQExATIBMwE0ATUUKwMFZ2dnZ2cWAWZkZADY79bn8WEbxLOSAAAYRK9sZ4sc":doc.getElementById("__VIEWSTATE").val());
		pageSate.put("__EVENTVALIDATION", doc.getElementById("__EVENTVALIDATION")==null?"/wEWJQKk/tSLDgLgyfGdDALUuqDDCALOueKsDQKAwc3yBgLE6abEDAKn97+nBwL8uNT2BwLFksXnBQLK/e+JCQLL/e+JCQLI/e+JCQLJ/e+JCQLO/e+JCQK3lZLeCwK1hsLZDgKIhJ7mDwK48cr0CAK9q9SxBwK0zqqCAgLls8rgBgLIy6m9BALHpIPTCALGpIPTCAL7j97/DwKvsJK+DAKz1vjgBAKg8uT9CAKktL6IDQKzqPHADAK669iIDQLF5MXxDgLKi++fAgLLi++fAgLIi++fAgLJi++fAgLOi++fAo++vtngl7/xxDHrbc7uBjSrUkoP":doc.getElementById("__EVENTVALIDATION").val());
		// 待办
		if ("1".equals(listType)) {
			Element e = doc.getElementById("tabTask");
			if (e != null) {
				int i = 0;
				for (Element tr : e.getElementsByTag("tr")) {

					if (i++ == 0)
						continue; // 忽略表头
					Elements tds = tr.getElementsByTag("td");
					String[] workFlow = tds.last().child(0).attr("onclick").split("=");
					// if (tds.size() > 6 &&
					// statusList.indexOf(tds.get(5).text())<0) {
					// continue;
					// }

					Task task = new Task();
					task.wordFlowId = workFlow[1].replaceAll("\\'\\)", "");
					Elements es = tr.getElementsByTag("a");
					if (es.size() == 1) {
						String click = es.get(0).attr("onclick");
						task.name = es.get(0).text();
						if ((click != null) && click.contains("'")) {
							String[] items = click.split("'");
							if (items.length >= 3) {
								task.detailUrl = items[1].replaceAll("\\.\\.", "");
								task.id = items[1].split("=")[1];
							}
						}
					}
					if (task.id == null || "发文".indexOf(task.name) > 0)
						continue;

					if (tds.size() > 6) {
						task.type = tds.get(3).text();
						task.time = tds.get(4).text();
						task.status = tds.get(5).text();
					}
					task.listType = "1";
					taskList.add(task);
				}
			}
		} else {
			// 经办
			Element e = doc.getElementById("receiveDoneTab");
			if (e != null) {
				int i = 0;
				for (Element tr : e.getElementsByTag("tr")) {
					if (i++ == 0)
						continue; // 忽略表头
					Elements tds = tr.getElementsByTag("td");

					Task task = new Task();
					Elements es = tr.getElementsByTag("a");
					if (es.size() == 1) {
						String click = es.get(0).attr("onclick");
						task.name = es.get(0).text();
						if ((click != null) && click.contains("'")) {
							String[] items = click.split("'");
							if (items.length >= 3) {
								task.detailUrl = "/task%20portal" + items[1].replaceAll("\\.\\.", "");
								task.id = items[1].split("=")[1];
							}
						}
					}
					if (task.id == null)
						continue;
					if (tds.size() > 6) {
						task.type = tds.get(5).text();
						task.time = tds.get(2).text();
						task.status = tds.get(6).text();
					}
					task.listType = "2";
					dealTaskList.add(task);
				}
			}
		}
		String taskLiskCount = doc.getElementById("taskCurCount") == null ? "0" : doc.getElementById("taskCurCount").html();
		String dealTaskLiskCount = doc.getElementById("taskDoneReceiveCount") == null ? "0" : doc.getElementById("taskDoneReceiveCount").html();

		pageSate.put("taskList", taskList);
		pageSate.put("dealTaskList", dealTaskList);
		pageSate.put("taskLiskCount", taskLiskCount);
		pageSate.put("dealTaskLiskCount", dealTaskLiskCount);

		Elements e = doc.getElementsByTag("script").eq(0);
		for (Element element : e) {
			String html = element.html();
			String[] data = html.split("\"");
			if (data.length > 1) {
				String detailUrl = "/task%20portal" + data[1].replaceAll("\\.\\.", "").replaceAll("ShowNotReadDistributeFileFrame.aspx", "ShowNotReadDistributeFile.aspx");
				pageSate.put("circulationQryUrl", detailUrl);
			} else {
				pageSate.put("circulationQryUrl", "noCirculationDoc");
			}

		}
		//System.out.println(pageSate);
		return pageSate;
	}

	private static String getUrl(Element tr) {

		return null;

	}

}
