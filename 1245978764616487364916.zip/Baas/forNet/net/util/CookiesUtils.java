package forNet.net.util;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.justep.baas.action.ActionContext;

public class CookiesUtils {
	private static final String COOKIE_ID = "server.wrapper.cookie";
	public static void updateCookies(ActionContext ac, Map<String, String> cookies){
		if (cookies == null) return;
		HttpServletRequest request = (HttpServletRequest)ac.get(ActionContext.REQUEST);
		HttpSession session = request.getSession(true);
		Map<String, String> container = (Map<String, String>)session.getAttribute(COOKIE_ID); 
		if (container == null){
			container = new ConcurrentHashMap<String, String>();
			session.setAttribute(COOKIE_ID, container);
		}
		container.putAll(cookies);
	}
	
	public static Map<String, String> getCookies(ActionContext ac){
		HttpServletRequest request = (HttpServletRequest)ac.get(ActionContext.REQUEST);
		HttpSession session = request.getSession(true);
		Map<String, String> container = (Map<String, String>)session.getAttribute(COOKIE_ID); 
		if (container == null){
			container = new ConcurrentHashMap<String, String>();
		}
		return container;
	}
}
