package mobiAppPlat.oa.app.docapprove.service;

import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import mobiAppPlat.oa.app.docapprove.bean.HtmlParser;
import mobiAppPlat.oa.app.docapprove.bean.RespCallback;
import mobiAppPlat.oa.app.docapprove.service.CheckUserOnline;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.select.Elements;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

public class StartTaskPageLoadCallback implements RespCallback{

	private static final String[] COLUMNS = new String[]{
		"文件编号",
		"拟稿日期",
		"主送单位",
		"成文日期",
		"文件标题",
		"备注"
	};
	private static final String[] NAMES = new String[]{
		"__VIEWSTATE",
		"__VIEWSTATEGENERATOR",
		"__EVENTVALIDATION",
		"OA_feedBackCtrl_$ReceiverIdea",
		"OA_feedBackCtrl_$WorkFlowType",
		"btnKickOff"
	};
	
	public Object execute(InputStream body) {
		Map<String, Object> result = new HashMap<String, Object>();
		Document doc = HtmlParser.parser(body, null);
		CheckUserOnline.checkOnline(doc);
		
		JSONArray jsoa = new JSONArray();
		
		//获取 可选 收文类型 范围
		Elements select = doc.getElementsByAttributeValue("name", "OA_feedBackCtrl_$WorkFlowType");
		if (select.size()>0) {
			Elements options= select.get(0).getElementsByTag("option");
			for (int i = 0; i < options.size(); i++) {
				JSONObject jsob = new JSONObject();
				Element option = options.get(i);
				jsob.put("id", option.attr("value"));
				jsob.put("name", option.text());
				jsoa.add(jsob);
			}
		}
		//获取标题
		String workFlowTitle = "";
		Elements workFlowTitles = doc.getElementsByAttributeValue("id", "ctl00_title");
		if (workFlowTitles.size()>0) {
			if ("textarea".equals(workFlowTitles.get(0).tagName())||"span".equals(workFlowTitles.get(0).tagName())) {
				workFlowTitle = workFlowTitles.get(0).text();
			}else {
				workFlowTitle = workFlowTitles.get(0).attr("value");
			}
		}
		//获取表单数据
		Map<String, String> task = new HashMap<String, String>();
		task.put("workFlowTitle", workFlowTitle);
		Elements table = doc.getElementsByAttributeValue("id", "ctl01_BaseInfoTab");
		Element tbody = table.get(0).child(0);
		List<Node> trs = tbody.childNodes();
		for(String column : COLUMNS){
			for (int i = 0; i < trs.size(); i++) {
				Node tr = trs.get(i);
				if (null != tr) {
					List<Node> tds = tr.childNodes();
					if (tds.size()>0) {
						Node td = tds.get(1);
						String tdText = td.childNodes().get(0).toString();
						if (tdText.indexOf(column)>=0) {
							task.put(column, tds.get(2).childNodes().get(0).toString());
						}
					}
				}
			}
			if (null == task.get(column)) {
				task.put(column, "");
			}
		}
		//获取启动流程需提交的数据
		Map<String, String> pageState = new HashMap<String, String>();
		for (String name : NAMES){
			Elements es = doc.getElementsByAttributeValue("name", name);
			if (es.size()>=1){
				String value = "";
				Element e = es.get(0);
				if (e.tagName().equals("textarea")){
					value = e.text();
				}else{
					value = es.get(0).attr("value");
				}
				
				pageState.put(name, value);
			}
		}
		
		//获取审核核稿数据 
		JSONArray history = new JSONArray();
		
		Elements elements = doc.getElementsByAttributeValueMatching("id", "^ctl02_ctl.*_ReviewRepeater_ctl00_ReviewName$");
		if (elements.size()>0) {
			for (int i = 0; i < elements.size(); i++) {
				Element element = elements.get(i);
				Element elementTable = element.parent().parent().parent();
				JSONObject jsob = new JSONObject();
				Element ReviewName = elementTable.getElementsByAttributeValueMatching("id","ReviewName$").get(0);
				jsob.put("ReviewName", null == ReviewName ? "":ReviewName.html());
				Element ReviewIdea = elementTable.getElementsByAttributeValueMatching("id","ReviewIdea$").get(0);
				jsob.put("ReviewIdea", null == ReviewIdea ? "":ReviewIdea.html());
				Element ReviewerDisplayName = elementTable.getElementsByAttributeValueMatching("id","ReviewerDisplayName$").get(0);
				jsob.put("ReviewerDisplayName", null == ReviewerDisplayName ? "":ReviewerDisplayName.html());
				Element ReviewerDeptName = elementTable.getElementsByAttributeValueMatching("id","ReviewerDeptName$").get(0);
				jsob.put("ReviewerDeptName", null == ReviewerDeptName ? "":ReviewerDeptName.html());
				Element ReviewTime = elementTable.getElementsByAttributeValueMatching("id","ReviewTime$").get(0);
				jsob.put("ReviewTime", null == ReviewTime ? "":ReviewTime.html());
				history.add(jsob);
			}
		}
		
		result.put("history", history);
		result.put("pageState", pageState);
		result.put("task", task);
		result.put("workFlowType", jsoa);
		return result;
	}
	
	

}
