package itil;

import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class StringUtils {
	
	public static String getFileName(String filePath){
		if(isEmpty(filePath)){
			return null;
		}
		return filePath.substring(filePath.lastIndexOf("/")+1);
	}
	
	public static String getSuffix(String fileName){
		if(isEmpty(fileName)){
			return ".png";
		}
		return "."+fileName.substring(fileName.lastIndexOf(".")+1);
	}
	
	public static boolean isEmpty(String str){
		if("".equals(str)||null==str||"undefined".equals(str)){
			return true;
		}
		return false;
	}
	public static String getBase64String(InputStream inputStream) {
		sun.misc.BASE64Encoder encoder = new sun.misc.BASE64Encoder();
		byte[] textByte = null;
		if (inputStream != null) {
			try {
				textByte = new byte[inputStream.available()];
				inputStream.read(textByte);
				inputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if (textByte == null) {
			return "";
		}
		return encoder.encode(textByte);

	}

	public static String string2MD5(String inStr) {
		MessageDigest md5 = null;
		try {
			md5 = MessageDigest.getInstance("MD5");
		} catch (Exception e) {
			System.out.println(e.toString());
			e.printStackTrace();
			return "";
		}
		char[] charArray = inStr.toCharArray();
		byte[] byteArray = new byte[charArray.length];

		for (int i = 0; i < charArray.length; i++)
			byteArray[i] = (byte) charArray[i];
		byte[] md5Bytes = md5.digest(byteArray);
		StringBuffer hexValue = new StringBuffer();
		for (int i = 0; i < md5Bytes.length; i++) {
			int val = ((int) md5Bytes[i]) & 0xff;
			if (val < 16)
				hexValue.append("0");
			hexValue.append(Integer.toHexString(val));
		}
		return hexValue.toString();

	}

	public static String md5(String str) {
		String s = str;
		if (s == null) {
			return "";
		} else {
			String value = null;
			MessageDigest md5 = null;
			try {
				md5 = MessageDigest.getInstance("MD5");
			} catch (NoSuchAlgorithmException ex) {
			}
			sun.misc.BASE64Encoder baseEncoder = new sun.misc.BASE64Encoder();
			try {
				value = baseEncoder.encode(md5.digest(s.getBytes("utf-8")));
			} catch (Exception ex) {
			}
			return value;
		}
	}
	
	public static int[] randomCommon(int min, int max, int n){  
	    if (n > (max - min + 1) || max < min) {  
	           return null;  
	       }  
	    int[] result = new int[n];  
	    int count = 0;  
	    while(count < n) {  
	        int num = (int) (Math.random() * (max - min)) + min;  
	        boolean flag = true;  
	        for (int j = 0; j < n; j++) {  
	            if(num == result[j]){  
	                flag = false;  
	                break;  
	            }  
	        }  
	        if(flag){  
	            result[count] = num;  
	            count++;  
	        }  
	    }  
	    return result;  
	}

	

	public static String getUUID() {
		return java.util.UUID.randomUUID().toString().replaceAll("-", "");
	}
	
	public static String getDateStr() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		return sdf.format(new Date());
	}
	public static void main(String[] args) {
		int[] a =  randomCommon(1,35,33);
		for(int i=0;i<a.length;i++){
			System.out.println(a[i]);
		}
	}

}
