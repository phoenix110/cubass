package admin.role;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.naming.NamingException;

import com.alibaba.fastjson.JSONObject;
import com.justep.baas.action.ActionContext;

/**
 * 角色管理
 * @author luofei
 *
 */
public class RoleManager {
	

	/**
	 * 删除组织
	 * 
	 * @param params
	 * @param context
	 * @return
	 * @throws NamingException
	 * @throws SQLException
	 */
	public static JSONObject deleteRole(JSONObject params, ActionContext context) throws SQLException, NamingException {
		JSONObject jsonObj = new JSONObject();
		Connection conn = context.getConnection("x5Sys");
		String roleId = params.getString("roleId");
		/*
		String sql = "select * from SA_OPOrg where sFID like '%?%'";
		List<Object> sqlParams = new ArrayList<Object>();
		sqlParams.add(roleId);
		Table table = DataUtils.queryData(conn, sql, sqlParams, null, null, null);
		List<Row> rows = table.getRows();
		for (Row row : rows) {
			new RoleManager().deleteRelation(conn, row.getString("sID"));
		}
		*/
		
		//删除角色的权限信息
		new RoleManager().deleteRelation(conn, roleId);
		// 删除角色信息
		String deleteSql = "delete from SA_OPRole where sID=?";
		PreparedStatement stmt = conn.prepareStatement(deleteSql);
		stmt.setString(1, roleId);
		stmt.execute();

		return jsonObj;
	}

	/**
	 * 删除角色的关联对象
	 * 
	 * @param conn
	 * @param orgId
	 * @throws SQLException
	 */
	private void deleteRelation(Connection conn, String roleId) throws SQLException {
		// 删除角色权限信息
		String deleteSql = "delete from SA_OPPermission where sPermissionRoleID=?";
		PreparedStatement stmt = conn.prepareStatement(deleteSql);
		stmt.setString(1, roleId);
		stmt.execute();
		deleteSql ="delete from SA_OPAuthorize where sAuthorizeRoleID=?";
		stmt = conn.prepareStatement(deleteSql);
		stmt.setString(1, roleId);
		stmt.execute();
		if (stmt != null) {
			stmt.close();
		}
	}

}
