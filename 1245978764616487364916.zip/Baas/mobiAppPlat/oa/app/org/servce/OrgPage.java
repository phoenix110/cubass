package mobiAppPlat.oa.app.org.servce;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;

import mobiAppPlat.oa.app.docapprove.bean.ActionResult;
import mobiAppPlat.oa.app.docapprove.bean.NetServer;
import mobiAppPlat.oa.app.docapprove.bean.ReqObj;
import mobiAppPlat.oa.app.docapprove.bean.RespObj;
import mobiAppPlat.oa.app.docapprove.utils.Utils;
import mobiAppPlat.oa.app.org.servce.AllPersonDeptFirstPageLoadCallback;
import mobiAppPlat.oa.app.org.servce.PersonPageLoadCallback;

public class OrgPage {
	public static ActionResult loadDeptPerson(Map<String, String> cookies,String type,JSONObject paramsData) throws UnsupportedEncodingException{
		
		String url = "";
		if ("cy".equals(type)) {
			url += Utils.getOaUrl("circulationUrl");
			url += "?";
			url += "workflowID="+paramsData.getString("workflowID");
			url += "&";
			url += "userID="+paramsData.getString("userID");
			url += "&";
			url += "title="+paramsData.getString("title");
			url += "&";
			url += "deptID=&deptName=&incID=&incName=&roleName=&IsShowBar=1&workflowformid=dgyt_rsccsswxr";
		}else if ("cbr".equals(type)) {
			url += Utils.getOaUrl("contractorsUrl");
			url += "?";
			url += "userID="+paramsData.getString("userID");
			url += "&";
			url += "roleName="+paramsData.getString("roleName");
			url += "&";
			url += "selectSignerID=";
			url += "&";
			url += "giveName="+paramsData.getString("giveName");
			url += "&";
			url += "workflowFormID="+paramsData.getString("workflowFormID");
		}else if ("selectStepUser".equals(type)) {
			url += Utils.getOaUrl("selectStepUser");
			url += "?";
			url += "UserID="+paramsData.getString("userID");
			url += "&";
			url += "RoleName="+paramsData.getString("roleName");
			url += "&";
			url += "RoleLevel="+paramsData.getString("roleLevel");
			url += "&";
			url += "WorkflowFormID="+paramsData.getString("workflowFormID");
		}
		
		ActionResult ar = new ActionResult(true, "");
		ReqObj req = new ReqObj();
		req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept", "*/*");
		req.addHeader("Accept-Language", "zh-CN");
		req.addHeader("Connection", "keep-alive");
		req.addHeader("Host", "oatraining.petrochina");
		req.addHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.3; WOW64; Trident/7.0; .NET4.0E; .NET4.0C; .NET CLR 3.5.30729; .NET CLR 2.0.50727; .NET CLR 3.0.30729; InfoPath.2; Tablet PC 2.0; LCJB)");
		req.setMethod("get");
		req.setUrl(url);
		RespObj tasks = NetServer.service(req, new PersonPageLoadCallback());
		ar.addCookies(tasks.getCookies());
		ar.setData(tasks.getResponseBody());
		return ar;
		
	}
	public static ActionResult loadAllPerson(Map<String, String> cookies,Integer count,String type,JSONObject paramsData) throws UnsupportedEncodingException{
		
		
		ActionResult ar = new ActionResult(true, "");
		ReqObj req = new ReqObj();
		req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept", "*/*");
		req.addHeader("Accept-Language", "zh-CN");
		req.addHeader("Connection", "keep-alive");
		req.addHeader("Host", "oatraining.petrochina");
		req.addHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.3; WOW64; Trident/7.0; .NET4.0E; .NET4.0C; .NET CLR 3.5.30729; .NET CLR 2.0.50727; .NET CLR 3.0.30729; InfoPath.2; Tablet PC 2.0; LCJB)");
		req.setMethod("get");
		String url = "";
		RespObj tasks = null;
		
		Map<String, Object> result = new HashMap<String, Object>();
		Map<String, Object> map = new HashMap<String, Object>();
		Map<String, Object> orgType = new HashMap<String, Object>();
		if (count == 0) {
			if ("dept".equals(type)) {
//				url += Utils.getOaUrl("selectAllPersonFirst");
//				url += "?";
//				url += "workflowID="+paramsData.getString("workflowID");
//				url += "&";
//				url += "userID="+paramsData.getString("userID");
//				url += "&";
//				url += "title="+paramsData.getString("title");
//				url += "&";
//				url += "deptID=&deptName=&incID=&incName=&roleName=";
				
				url += Utils.getOaUrl("selectAllPersonFirst");
				url += "?";
				url += "workflowID="+paramsData.getString("workflowID");
				url += "&";
				url += "userID="+paramsData.getString("userID");
				url += "&";
				url += "title="+paramsData.getString("title");
				url += "&";
				url += "deptID=" + paramsData.getString("deptID");
				url += "&";
				url += "deptName=" +paramsData.getString("deptName");
				url += "&";
				url += "incID=" +paramsData.getString("incID");
				url += "&";
				url += "incName=" +paramsData.getString("incName");
				url += "&roleName=";
				url += "&workflowformid="+paramsData.getString("workflowformid");
				req.setUrl(url);
				tasks = NetServer.service(req, new AllPersonDeptFirstPageLoadCallback());
			}else {
				url += Utils.getOaUrl("selectAllPersonFirst");
				url += "?";
				url += "workflowID="+paramsData.getString("workflowID");
				url += "&";
				url += "userID="+paramsData.getString("userID");
				url += "&";
				url += "title="+paramsData.getString("title");
				url += "&";
				url += "deptID=&deptName=&incID=&incName=&roleName=&rdoInc=true&rdoDept=false&txtValue=0";
				req.setUrl(url);
				tasks = NetServer.service(req, new AllPersonOrgFirstPageLoadCallback());
			}
			if (null != tasks.getResponseBody()) {
				orgType = getOrgType(tasks.getResponseBody());
				map = updateTask(tasks.getResponseBody(), "");
			}
//			&IsShowBar=1&workflowformid=dgyt_rsccsswxr
		}else {
			if ("dept".equals(type)) {
				url += Utils.getOaUrl("selectAllPersonOther");
				url += "?random=888&mode=OrgAndUser&bShowNoEffectOrg=False&bOrgCheckBox=True&rolename=&userposition=";
				url += "&";
				url += "workflowID="+paramsData.getString("workflowID");
				url += "&";
				url += "OrgID="+paramsData.getString("OrgID");
				req.setUrl(url);
				tasks = NetServer.service(req, new AllPersonDeptOtherPageLoadCallback());
			}else {
				url += Utils.getOaUrl("selectAllPersonOther");
				url += "?random=888&mode=OrgAndUser&bShowNoEffectOrg=False&bOrgCheckBox=True&rolename=&userposition=";
				url += "&";
				url += "workflowID="+paramsData.getString("workflowID");
				url += "&";
				url += "OrgID="+paramsData.getString("OrgID");
				req.setUrl(url);
				tasks = NetServer.service(req, new AllPersonOrgOtherPageLoadCallback());
			}
			if (null != tasks.getResponseBody()) {
				orgType = getOrgType(tasks.getResponseBody());
				map = updateTask(tasks.getResponseBody(), paramsData.getString("OrgID"));
			}
		}
		result.put("data", map);
		result.put("orgType", orgType);
		ar.addCookies(tasks.getCookies());
		ar.setData(result);
		return ar;
		
	}
	
	//获取每个节点的组织类型。
	public static Map<String, Object> getOrgType(Object task){
		Map<String, Object> map = (Map<String, Object>) task;
		Map<String, Object> orgType = new HashMap<String, Object>();
		for(String key : map.keySet()){
			Map<String, Object> orgMap = (Map<String, Object>) map.get(key);
			for (String orgMapKey : orgMap.keySet()) {
				orgType.put(orgMapKey, orgMap.get(orgMapKey));
			}
		}
		return orgType;
		
	}
	
	//赋值父ID，更新并获取集合
	public static Map<String, Object> updateTask(Object task,String orgID){
		Map<String, Object> map = (Map<String, Object>) task;
		for (String key : map.keySet()) {
			Map<String, Object> orgMap = (Map<String, Object>) map.get(key);
			for (String orgMapKey : orgMap.keySet()) {
				orgMap.put(orgMapKey, orgID);
			}
			
		}
		return map;
		
	}
	
	
	public static ActionResult loadAllOrg(Map<String, String> cookies,JSONObject paramsData) throws UnsupportedEncodingException{
		
		String url = "";
		url += Utils.getOaUrl("selectAllOrg");
		url += "?deptNameCtrl=Register_00_Current_Ctrl_GiveMainUnit&deptIDCtrl=Register_00_Current_Ctrl_GiveMainUnitID&excludeDeptIDCtrl=Register_00_Current_Ctrl_GiveCopyUnitID&";
		url += "deptID="+paramsData.getString("deptID");
		url += "&";
		url += "workflowID="+paramsData.getString("workflowID");
		url += "&";
		url += "giveName="+paramsData.getString("giveName");
		url += "&";
		url += "giveType="+paramsData.getString("giveType");
		
		ActionResult ar = new ActionResult(true, "");
		ReqObj req = new ReqObj();
		req.addHeader("Cookie", Utils.map2String(cookies));
		req.addHeader("Accept", "Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		//req.addHeader("Accept-Encoding", "gzip, deflate, sdch"); //不压缩
		req.addHeader("Accept-Language", "zh-CN,zh;q=0.8");
		req.addHeader("Cache-Control", "no-cache");
		req.addHeader("Connection", "keep-alive");
		req.addHeader("Host", "oatraining.petrochina");
		req.addHeader("Pragma", "no-cache");
		req.addHeader("Upgrade-Insecure-Requests", "1");
		req.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.4 Safari/537.36");
		req.setMethod("get");
		req.setUrl(url);
		RespObj tasks = null;
		
		tasks = NetServer.service(req, new AllOrgPageLoadCallback());
		ar.addCookies(tasks.getCookies());
		ar.setData(tasks.getResponseBody());
		return ar;
		
	}
}
