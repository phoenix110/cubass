package mobiAppPlat.oa.app.contractapprove;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import mobiAppPlat.oa.app.docapprove.service.CheckUserOnline;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import forNet.net.HtmlParser;
import forNet.net.RespCallback;

public class TaskListDoReturnCallback implements RespCallback {

	public Object execute(InputStream body) {
		String flag = "true";
		String msg = "";
		Document doc = HtmlParser.parser(body, null);
		CheckUserOnline.checkOnline(doc);
		Map<String, String> result = PageUtils.getDoReturnPostInfo(doc);
		result.put("flag", flag);
		result.put("msg", msg);
		return result;
	}

}
