package mobiAppPlat.oa.app.expenseapprove.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import mobiAppPlat.oa.app.expenseapprove.beans.TravelExpense;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class PageUtils {

	// 获取基本信息
	public static void getBaseInfo(Document doc, TravelExpense travelExpense) {
		
		Map<String, String> valueMap = new HashMap<String, String>();
		valueMap.put("t_lblAim", doc.getElementById("t_lblAim").html());
		valueMap.put("t_lblPurpose", doc.getElementById("t_lblPurpose").html());
		valueMap.put("t_lAttachmentCount",    doc.getElementById("t_lAttachmentCount").html());
		
		valueMap.put("lblTotalSum", doc.getElementById("lblTotalSum").html());
		valueMap.put("txtLastestSum", doc.getElementById("txtLastestSum").html());
		valueMap.put("lblSheetCode", doc.getElementById("lblSheetCode").html().replaceAll("单据编号：", ""));
		valueMap.put("lBudgetName", doc.getElementById("CtrOUBudgetTree1_lBudgetName").html());
		travelExpense.setBaseInfo(valueMap);
	}

	//获取自购交通费
	public static void getFee2(Document doc, TravelExpense travelExpense) {
		
		List<Map<String, String>> dataList = new ArrayList<Map<String, String>>();
		Element element = doc.getElementById("tblTrip");
		int i = 1;
		for (Element data : element.getElementsByAttributeValueContaining("id", "lblTUserID")) {
			Map<String, String> valueMap = new HashMap<String, String>();
			String start = "t_rptTrip_ctl0" + i + "_";
			valueMap.put("lblTUserID", data.html());
			valueMap.put("lblBunk", doc.getElementById(start + "lblBunk").html());
			valueMap.put("lblBeginPoint", doc.getElementById(start + "lblBeginPoint").html());
			valueMap.put("lblEndPoint", doc.getElementById(start + "lblEndPoint").html());
			valueMap.put("lblBeginDate", doc.getElementById(start + "lblBeginDate").html());
			valueMap.put("lblEndDate", doc.getElementById(start + "lblEndDate").html());
			valueMap.put("lblPrice", doc.getElementById(start + "lblPrice").html());
			valueMap.put("lblBillAmount", doc.getElementById(start + "lblBillAmount").html());
			valueMap.put("lblSum", doc.getElementById(start + "lblSum").html());
			valueMap.put("lblIsDenied", doc.getElementById(start + "lblIsDenied").html());
			valueMap.put("lblApproveSum", doc.getElementById(start + "lblApproveSum").html());
			valueMap.put("lblDenyUserName", doc.getElementById(start + "lblDenyUserName").html());
			valueMap.put("lblBillAmountCanceled", doc.getElementById(start + "lblBillAmountCanceled").html());
			valueMap.put("lblAmountCanceled", doc.getElementById(start + "lblAmountCanceled").html());
			valueMap.put("lValueAddedTaxApprove", doc.getElementById(start + "lValueAddedTaxApprove").html());
			valueMap.put("lblRemarkCanceled", doc.getElementById(start + "lblRemarkCanceled").html());
			dataList.add(valueMap);
			i++;
		}
		travelExpense.setTrafficExpense(dataList);
	
	 }

	// 获取住宿费
	public static void getFee3(Document doc, TravelExpense travelExpense) {

		List<Map<String, String>> dataList = new ArrayList<Map<String, String>>();
		Element element = doc.getElementById("tblLodging");
		int i = 1;
		for (Element data : element.getElementsByAttributeValueContaining("id", "lblTUserID")) {
			Map<String, String> valueMap = new HashMap<String, String>();
			String start = "t_rptLodging_ctl0" + i + "_";
			valueMap.put("lblTUserID", data.html());
			valueMap.put("lblCity", doc.getElementById(start + "lblCity").html());
			valueMap.put("lblHotel", doc.getElementById(start + "lblHotel").html());
			valueMap.put("lblRegionType", doc.getElementById(start + "lblRegionType").html());
			valueMap.put("lblDays", doc.getElementById(start + "lblDays").html());
			valueMap.put("lblAmount", doc.getElementById(start + "lblAmount").html());
			valueMap.put("txtAmountStd", doc.getElementById(start + "txtAmountStd").val());
			valueMap.put("lblIsDenied", doc.getElementById(start + "lblIsDenied").html());
			valueMap.put("lblRemarkCanceled", doc.getElementById(start + "lblRemarkCanceled").val());
			valueMap.put("lblIsDeniedOverStd", doc.getElementById(start + "lblIsDeniedOverStd").html());
			valueMap.put("lblDenyUserName", doc.getElementById(start + "lblDenyUserName").html());
			dataList.add(valueMap);
			i++;
		}
		travelExpense.setHotelExpense(dataList);

	}

	// 获取其他费用
	public static void getFee4(Document doc, TravelExpense travelExpense) {
		List<Map<String, String>> dataList = new ArrayList<Map<String, String>>();
		Element element = doc.getElementById("tblOther");
		int i = 1;
		for (Element data : element.getElementsByAttributeValueContaining("id", "lblTUserID")) {
			Map<String, String> valueMap = new HashMap<String, String>();
			String start = "t_rptOther_ctl0" + i + "_";
			valueMap.put("lblTUserID", data.html());
			valueMap.put("lblExpenseType", doc.getElementById(start + "lblExpenseType")==null?"":doc.getElementById(start + "lblExpenseType").html());
			valueMap.put("lblPrice", doc.getElementById(start + "lblPrice")==null?"":doc.getElementById(start + "lblPrice").html());
			valueMap.put("lblBillAmount", doc.getElementById(start + "lblBillAmount")==null?"":doc.getElementById(start + "lblBillAmount").html());
			valueMap.put("lblSum", doc.getElementById(start + "lblSum")==null?"":doc.getElementById(start + "lblSum").html());
			valueMap.put("lblIsDenied", doc.getElementById(start + "lblIsDenied")==null?"":doc.getElementById(start + "lblIsDenied").html());
			valueMap.put("lblApproveSum", doc.getElementById(start + "lblApproveSum")==null?"":doc.getElementById(start + "lblApproveSum").html());
			valueMap.put("lblDenyUserName", doc.getElementById(start + "lblDenyUserName")==null?"":doc.getElementById(start + "lblDenyUserName").html());
			valueMap.put("lblBillAmountCanceled", doc.getElementById(start + "lblBillAmountCanceled")==null?"":doc.getElementById(start + "lblBillAmountCanceled").html());
			valueMap.put("lblAmountCanceled", doc.getElementById(start + "lblAmountCanceled")==null?"":doc.getElementById(start + "lblAmountCanceled").html());
			valueMap.put("lValueAddedTaxApprove", doc.getElementById(start + "lValueAddedTaxApprove")==null?"":doc.getElementById(start + "lValueAddedTaxApprove").html());
			valueMap.put("lblRemarkCanceled", doc.getElementById(start + "lblRemarkCanceled")==null?"":doc.getElementById(start + "lblRemarkCanceled").html());
			dataList.add(valueMap);
			i++;
		}
		travelExpense.setOtherExpense(dataList);

	}

	// 获取补助情况
	public static void getFee5(Document doc, TravelExpense travelExpense) {

		List<Map<String, String>> dataList = new ArrayList<Map<String, String>>();
		Element element = doc.getElementById("tblSubsidy");
		int i = 1;
		for (Element data : element.getElementsByAttributeValueContaining("id", "lblUserName")) {
			Map<String, String> valueMap = new HashMap<String, String>();
			String start = "t_rptSubsidy_ctl0" + i + "_";
			valueMap.put("lblUserName", data.html());
			valueMap.put("lblTripDays", doc.getElementById(start + "lblTripDays").html());
			valueMap.put("lblTripSubsidy", doc.getElementById(start + "lblTripSubsidy").html());
			valueMap.put("lblSum", doc.getElementById(start + "lblSum").html());
			dataList.add(valueMap);
			i++;
		}
		travelExpense.setSupplyExpense(dataList);

	}

	// 获取人员信息
	public static void getFee1(Document doc, TravelExpense travelExpense) {
		List<Map<String, String>> dataList = new ArrayList<Map<String, String>>();
		Element element = doc.getElementById("t_grdUsers");
		int i = 2;
		for (Element data : element.getElementsByAttributeValueContaining("name", "txtCostObject")) {
			Map<String, String> valueMap = new HashMap<String, String>();
			String start = "t_grdUsers_ctl0" + i + "_";
			valueMap.put("txtCostObject", data.attr("value"));
			valueMap.put("txtuserName", doc.getElementById(start + "Label6").html());
			dataList.add(valueMap);
			i++;
		}
		travelExpense.setExpenseUser(dataList);
	}

	// 获取审批信息
	public static void getReviewIdea(Document doc, TravelExpense travelExpense) {
		List<Map<String, String>> dataList = new ArrayList<Map<String, String>>();
		Element element = doc.getElementById("CtrHistoryComments1_GridHistoryComments");
		for (Element tr : element.getElementsByTag("tr")) {
			Map<String, String> valueMap = new HashMap<String, String>();
			int i = 0;
			for (Element td : tr.getElementsByTag("td")) {
				if (i == 0) {
					valueMap.put("txtBussApplyName", td.html());
				} else if (i == 1) {
					valueMap.put("txtBussApplyUserName", td.getElementsByTag("a").html());
				} else if (i == 2) {
					valueMap.put("txtBussApplyResult", "&nbsp;".equals(td.html()) ? "" : td.html());
				} else if (i == 3) {
					valueMap.put("txtBussApplyIdea", "&nbsp;".equals(td.html()) ? "" : td.html());
				} else if (i == 4) {
					valueMap.put("txtBussApplyTime", td.html());
				}
				i++;
			}
			dataList.add(valueMap);
		}
		travelExpense.setReviewIdea(dataList);
	}

	// 获取POST信息
	public static void getPostInfo(Document doc, TravelExpense travelExpense) {
		Map<String, String> paramMap = new HashMap<String, String>();
		Element form = doc.getElementById("aspnetForm");
		for (Element element : form.getElementsByTag("input")) {
			if("submit".equals(element.attr("type"))||"image".equals(element.attr("type"))){
				continue;
			}
			if(element.attr("name").indexOf("btn")<0 &&!"disabled".equals(element.attr("disabled"))){
				if("checkbox".equals(element.attr("type"))){
					if("checked".equals(element.attr("checked"))){
						paramMap.put(element.attr("name"), "on");
					}
				}else{
					paramMap.put(element.attr("name"), element.attr("value"));
				}
			}
			
		}
		// select
		for (Element element : form.getElementsByTag("select")) {
			Elements options = element.children();
			if(!"disabled".equals(element.attr("disabled"))){
				for (Element option : options) {
					int i=0;
					if ("selected".equals(option.attr("selected"))) {
						paramMap.put(element.attr("name"), option.attr("value"));
						break;
					}else{
						if(i==0){
							paramMap.put(element.attr("name"), option.attr("value"));
							//break;
						}
						
					}
					i++;
				}
			}
		
		}
		// textarea
		for (Element element : form.getElementsByTag("textarea")) {
			if(element.attr("name").indexOf("btn")<0){
				paramMap.put(element.attr("name"), element.text());
			}
			//paramMap.put(element.attr("name"), element.text());
		}
		
		paramMap.put("txtSubmitTimes", "1");
		
		paramMap.remove("BtnReturn");
		paramMap.remove("btnReviewAgree");
		paramMap.remove("btnReviewDisAgree");
		paramMap.remove("");

		//System.out.println("paramMap:"+paramMap);
		travelExpense.setPostParams(paramMap);
	}

}
