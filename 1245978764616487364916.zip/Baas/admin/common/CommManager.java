package admin.common;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletResponse;

import admin.utils.StringUtil;
import admin.utils.SystemConfigUtil;
import admin.utils.SystemInit;

import com.alibaba.fastjson.JSONObject;
import com.justep.baas.action.ActionContext;
import com.justep.baas.data.DataUtils;
import com.justep.baas.data.Row;
import com.justep.baas.data.Table;

public class CommManager {
	/**
	 * 获取数据字典名称
	 * 
	 * @param params
	 * @param context
	 * @return
	 */
	public static JSONObject getDictName(JSONObject params, ActionContext context) {
		HttpServletResponse response = (HttpServletResponse) context.get(ActionContext.RESPONSE);
		// 字典组编码
		String groupCode = params.getString("groupCode");
		// 字典编码
		String typeCode = params.getString("typeCode");
		String typeName = "";
		try {
			Connection conn = context.getConnection(SystemInit.sysConfig.get("dsSys"));
			String sql = "select b.name from sa_type_group a ,t_s_type b where a.id=b.groupId and a.groupCode=? and b.value=?";
			PreparedStatement preparedStatement = conn.prepareStatement(sql);
			preparedStatement.setString(1, groupCode);
			preparedStatement.setString(2, typeCode);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				typeName = rs.getString("name");
			}
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("name", typeName);
			DataUtils.writeJsonToResponse(response, jsonObj);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static JSONObject getUserNameById(JSONObject params, ActionContext context) {
		HttpServletResponse response = (HttpServletResponse) context.get(ActionContext.RESPONSE);
		// 字典组编码
		String userId = params.getString("userId");
		String userName = "";
		try {
			Connection conn = context.getConnection(SystemInit.sysConfig.get("dsSys"));
			String sql = "select sName from SA_OPPerson where sID=?";
			PreparedStatement preparedStatement = conn.prepareStatement(sql);
			preparedStatement.setString(1, userId);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				userName = rs.getString("sName");
			}
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("userName", userName);
			DataUtils.writeJsonToResponse(response, jsonObj);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 判断某个值是否重复
	 * 
	 * @param params
	 * @param context
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 * @throws IOException
	 */
	public static JSONObject duplicate(JSONObject params, ActionContext context) throws SQLException, NamingException, IOException {

		HttpServletResponse response = (HttpServletResponse) context.get(ActionContext.RESPONSE);
		// 表名
		String tableName = params.getString("tableName");
		// 字典编码
		String condition = params.getString("condition");
		String id = params.getString("id");
		String idColumnName = params.getString("idColumnName");
		Connection conn = context.getConnection(SystemInit.sysConfig.get("dsSys"));
		String sql = "select count(1) count from " + tableName + " where " + condition;
		if (!StringUtil.isEmpty(id)) {
			sql = sql + " and " + idColumnName + "!='" + id + "'";
		}
		Table table = DataUtils.queryData(conn, sql, null, null, null, null);
		JSONObject jsonObj = new JSONObject();
		List<Row> rows = table.getRows();
		if (rows.size() > 0) {
			Row row = rows.get(0);
			Long count = Long.valueOf(String.valueOf(row.getValue("count")));
			if (count > 0) {
				jsonObj.put("flag", "1");
			} else {
				jsonObj.put("flag", "0");
			}
		} else {
			jsonObj.put("flag", "0");
		}
		DataUtils.writeJsonToResponse(response, jsonObj);

		return null;
	}
    /**
     * 刷新系统配置缓存
     * @param params
     * @param context
     * @return
     */
	public static JSONObject refreshConfigMem(JSONObject params, ActionContext context) {
		String sCode=params.getString("sCode");
		String sValue=params.getString("sValue");
		SystemInit.sysConfig.put(sCode, sValue);
		return null;
	}

}
