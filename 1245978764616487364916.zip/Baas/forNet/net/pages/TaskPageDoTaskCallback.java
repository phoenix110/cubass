package forNet.net.pages;

import java.io.InputStream;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import forNet.net.HtmlParser;
import forNet.net.RespCallback;

public class TaskPageDoTaskCallback implements RespCallback {

	public Object execute(InputStream body) {
		Document doc = HtmlParser.parser(body, null);
		//System.out.println(doc.toString());
		CheckUserOnline.checkOnline(doc);

		for (Element e : doc.getElementsByAttributeValue("color", "red")){
			if (e.text().contains("审核意见不能为空")){
				throw new RuntimeException("审核意见不能为空");
			}
		}
		/*
		for (Element e : doc.getElementsByTag("title")){
			//如果回到任务表单，表示审批失败
			if (e.text().equals("任务表单")){
				throw new RuntimeException("审批失败！原因未知");
			}
		}
		*/
		return null;
	}

}
