package itil;

import itil.AlarmCondition;
import itil.AlarmParam;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.justep.baas.action.ActionContext;

public class NetServer {
	public static final String BASE_URL = "http://10.76.1.31:8890/itsm";
	public static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
	public static OkHttpClient client = null;
	public static final Map<String, String> serviceMap = new HashMap<String, String>();

	static {
		client = new OkHttpClient();
		// 告警 列表
		serviceMap.put("1", "/rest/api/v2/arbiter/alerts/query");
		// 告警详情
		serviceMap.put("2", "/rest/api/v2/arbiter/alerts");
		// 获取工单表单布局接口
		serviceMap.put("3", "/rest/api/v2/itsm/tickets/form");
		// 工单创建接口
		serviceMap.put("4", "/rest/api/v2/itsm/tickets/create");
		// 待办工单查询接口
		serviceMap.put("5", "/rest/api/v2/itsm/tickets/query/onhand");
		// 待办工单详情接口
		serviceMap.put("6", "/rest/api/v2/itsm/tickets");
		// 工单处理接口
		serviceMap.put("7", "/rest/api/v2/itsm/tickets/progressing");
		// 上传附件接口
		serviceMap.put("8", "/rest/api/v2/itsm/attach/upload");
		// 用户权限
		serviceMap.put("9", "/rest/api/v2/itsm/tickets/permission");
		// 字典接口
		serviceMap.put("10", "/rest/api/v2/itsm/tickets/dict");
		//工单起始信息
		serviceMap.put("11", "/rest/api/v2/itsm/tickets/start");
		//是否有创建工单的权限
		serviceMap.put("12", "/rest/api/v2/itsm/tickets/permission");
		

	}

	public static JSONObject queryAlarm(JSONObject params, ActionContext context) throws Exception {
		AlarmCondition condition = new AlarmCondition();
		String serviceId = params.getString("serviceId");
		Integer pageSize = params.getInteger("pageSize");
		Integer curPage = params.getInteger("curPage");
		//condition.setId(params.getString("id"));
		condition.setType(params.getString("type"));
		condition.setServerity(params.getString("serverity"));
		condition.setProcess(params.getInteger("process"));
		AlarmParam alarmParam = new AlarmParam();
		alarmParam.setUserId(params.getString("userId"));
		alarmParam.setCondition(condition);
		JSONObject json = JSONObject.parseObject(JSONObject.toJSONString(alarmParam));
		JSONObject cond =(JSONObject)json.get("condition");
		cond.put("page.pageSise", pageSize);
		cond.put("page.curPage", curPage);
		json.put("condition", cond);
		String postParams = json.toJSONString();
		//System.out.println("======postParams======"+postParams);
		
		RequestBody body = RequestBody.create(JSON, postParams);
		Request.Builder requestBuilder = new Request.Builder().url(BASE_URL + serviceMap.get(serviceId));
		requestBuilder.method("POST", body);
		requestBuilder.addHeader("Content-Type", "application/json");
		requestBuilder.addHeader("Accept", "application/json; charset=utf-8");
		requestBuilder.addHeader("sysCode", "COSS");
		Request request = requestBuilder.build();
		ResponseBody resp = null;
		String content = "";
		try {
			Response response = client.newCall(request).execute();
			resp = response.body();
			content = resp.string();
			//System.out.println("===========content==========" + content);

		} catch (Exception e) {
			e.printStackTrace();
		}
		if (content.indexOf("DOCTYPE HTML PUBLIC") >= 0) {
			return JSONObject.parseObject("{result:{\"success\":false}}");
		}
		return JSONObject.parseObject(content);
	}

	public static JSONObject alarmForm(JSONObject params, ActionContext context) throws Exception {
		String serviceId = params.getString("serviceId");
		String userId = params.getString("userId");
		String id = params.getString("id");
		String url=BASE_URL + serviceMap.get(serviceId) + "?id=" + id + "&userId=" + userId;
		//System.out.println(url);
		Request.Builder requestBuilder = new Request.Builder().url(url);
		requestBuilder.addHeader("Content-Type", "application/json");
		requestBuilder.addHeader("Accept", "application/json; charset=utf-8");
		requestBuilder.addHeader("sysCode", "COSS");
		Request request = requestBuilder.build();
		ResponseBody resp = null;
		String content = "";
		try {
			Response response = client.newCall(request).execute();
			resp = response.body();
			content = resp.string();
			//System.out.println("===========content==========" + content);

		} catch (Exception e) {
			e.printStackTrace();
		}
		if (content.indexOf("DOCTYPE HTML PUBLIC") >= 0) {
			return JSONObject.parseObject("{result:{\"success\":false}}");
		}
		return JSONObject.parseObject(content);
	}

	public static JSONObject queryWorkOrder(JSONObject params, ActionContext context) throws Exception {
		String serviceId = params.getString("serviceId");
		String userId = params.getString("userId");
		//System.out.println("======================" + userId);
		String moduleId = params.getString("moduleId");
		String querykey = params.getString("querykey");
		String url = BASE_URL + serviceMap.get(serviceId) + "?";
		if (!"".equals(userId)) {
			url = url + "userId=" + userId;
		}
		if (!"".equals(moduleId)) {
			url = url + "&moduleId=" + moduleId;
		}
		if (!"".equals(querykey) && null != querykey) {
			url = url + "&key=" + querykey;
		}
		System.out.println(url);
		Request.Builder requestBuilder = new Request.Builder().url(url);
		requestBuilder.addHeader("Content-Type", "application/json");
		requestBuilder.addHeader("Accept", "application/json; charset=utf-8");
		requestBuilder.addHeader("sysCode", "COSS");
		Request request = requestBuilder.build();
		ResponseBody resp = null;
		String content = "";
		try {
			Response response = client.newCall(request).execute();
			resp = response.body();
			content = resp.string();
			System.out.println("===========content==========" + content);

		} catch (Exception e) {
			e.printStackTrace();
		}
		if (content.indexOf("DOCTYPE HTML PUBLIC") >= 0) {
			return JSONObject.parseObject("{result:{\"success\":false}}");
		}
		return JSONObject.parseObject(content);
	}

	public static JSONObject loadWorkOrder(JSONObject params, ActionContext context) throws Exception {
		String serviceId = params.getString("serviceId");
		String userId = params.getString("userId");
		String taskId = params.getString("taskId");
		String dataonly = params.getString("dataonly");
		String url = BASE_URL + serviceMap.get(serviceId) + "?";
		if (!"".equals(userId)) {
			url = url + "userId=" + userId;
		}
		if (!"".equals(taskId)) {
			url = url + "&taskId=" + taskId;
		}
		if (!"".equals(dataonly) && null != dataonly) {
			url = url + "&dataonly=" + dataonly;
		}
		System.out.println(url);
		Request.Builder requestBuilder = new Request.Builder().url(url);
		requestBuilder.addHeader("Content-Type", "application/json");
		requestBuilder.addHeader("Accept", "application/json; charset=utf-8");
		requestBuilder.addHeader("sysCode", "COSS");
		Request request = requestBuilder.build();
		ResponseBody resp = null;
		String content = "";
		try {
			Response response = client.newCall(request).execute();
			resp = response.body();
			content = resp.string();
			//System.out.println("===========content==========" + content);

		} catch (Exception e) {
			e.printStackTrace();
		}
		if (content.indexOf("DOCTYPE HTML PUBLIC") >= 0) {
			return JSONObject.parseObject("{result:{\"success\":false}}");
		}
		return JSONObject.parseObject(content);
	}

	public static JSONObject createWorkOrder(JSONObject params, ActionContext context) throws Exception {
		String serviceId = params.getString("serviceId");
		String postParams = params.getString("postParams");
		RequestBody body = RequestBody.create(JSON, postParams);

		System.out.println("===========URL==========" + BASE_URL + serviceMap.get(serviceId));
		//System.out.println("===========postParams==========" + postParams);
		Request.Builder requestBuilder = new Request.Builder().url(BASE_URL + serviceMap.get(serviceId));
		requestBuilder.method("POST", body);
		requestBuilder.addHeader("Content-Type", "application/json");
		requestBuilder.addHeader("Accept", "application/json; charset=utf-8");
		requestBuilder.addHeader("sysCode", "COSS");
		Request request = requestBuilder.build();
		ResponseBody resp = null;
		String content = "";
		try {
			Response response = client.newCall(request).execute();
			resp = response.body();
			content = resp.string();
			System.out.println("===========content==========" + content);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (content.indexOf("DOCTYPE HTML PUBLIC") >= 0) {
			return JSONObject.parseObject("{result:{\"success\":false,\"message\":\"接口处理异常\"}}");
		}
		return JSONObject.parseObject(content);
	}
	
	public static JSONObject loadStartInfo(JSONObject params, ActionContext context) throws Exception {
		String serviceId = params.getString("serviceId");
		String userId = params.getString("userId");
		String moduleId = params.getString("moduleId");
		String processName = params.getString("processName");
		
		String url = BASE_URL + serviceMap.get(serviceId) + "?";
		if (!"".equals(userId)) {
			url = url + "userId=" + userId;
		}
		if (!"".equals(moduleId)) {
			url = url + "&moduleId=" + moduleId;
		}
		if (!"".equals(processName) && null != processName) {
			url = url + "&processName=" + processName;
		}
		System.out.println(url);
		Request.Builder requestBuilder = new Request.Builder().url(url);
		requestBuilder.addHeader("Content-Type", "application/json");
		requestBuilder.addHeader("Accept", "application/json; charset=utf-8");
		requestBuilder.addHeader("sysCode", "COSS");
		Request request = requestBuilder.build();
		ResponseBody resp = null;
		String content = "";
		try {
			Response response = client.newCall(request).execute();
			resp = response.body();
			content = resp.string();
			//System.out.println("===========content==========" + content);

		} catch (Exception e) {
			e.printStackTrace();
		}
		if (content.indexOf("DOCTYPE HTML PUBLIC") >= 0) {
			return JSONObject.parseObject("{result:{\"success\":false,\"msg\":\"接口访问异常\"}}");
		}
		return JSONObject.parseObject(content);
	}
	
	public static JSONObject loadPermissions(JSONObject params, ActionContext context) throws Exception {
		String serviceId = params.getString("serviceId");
		String userId = params.getString("userId");
		String moduleId = params.getString("moduleId");
		String processName = params.getString("processName");
		String url = BASE_URL + serviceMap.get(serviceId) + "?";
		if (!"".equals(userId)) {
			url = url + "userId=" + userId;
		}
		if (!"".equals(moduleId)) {
			url = url + "&moduleId=" + moduleId;
		}
		if (!"".equals(processName)) {
			url = url + "&processName=" + processName;
		}
		
		Request.Builder requestBuilder = new Request.Builder().url(url);
		requestBuilder.addHeader("Content-Type", "application/json");
		requestBuilder.addHeader("Accept", "application/json; charset=utf-8");
		requestBuilder.addHeader("sysCode", "COSS");
		Request request = requestBuilder.build();
		ResponseBody resp = null;
		String content = "";
		try {
			Response response = client.newCall(request).execute();
			resp = response.body();
			content = resp.string();
			//System.out.println("===========content==========" + content);

		} catch (Exception e) {
			e.printStackTrace();
		}
		if (content.indexOf("DOCTYPE HTML PUBLIC") >= 0) {
			return JSONObject.parseObject("{result:{\"success\":false}}");
		}
		return JSONObject.parseObject(content);
	}
	
	public static JSONObject loadDicts(JSONObject params, ActionContext context) throws Exception {
		String serviceId = params.getString("serviceId");
		String dsBusinessName = params.getString("dsBusinessName");
		String url = BASE_URL + serviceMap.get(serviceId) + "?";
		if (!"".equals(dsBusinessName)) {
			url = url + "&dsBusinessName=" + dsBusinessName;
		}
		
		System.out.println(url);
		Request.Builder requestBuilder = new Request.Builder().url(url);
		requestBuilder.addHeader("Content-Type", "application/json");
		requestBuilder.addHeader("Accept", "application/json; charset=utf-8");
		requestBuilder.addHeader("sysCode", "COSS");
		Request request = requestBuilder.build();
		ResponseBody resp = null;
		String content = "";
		try {
			Response response = client.newCall(request).execute();
			resp = response.body();
			content = resp.string();
			//System.out.println("===========content==========" + content);

		} catch (Exception e) {
			e.printStackTrace();
		}
		if (content.indexOf("DOCTYPE HTML PUBLIC") >= 0) {
			return JSONObject.parseObject("{result:{\"success\":false}}");
		}
		return JSONObject.parseObject(content);
	}

	public static void main(String[] args) {

		AlarmCondition condition = new AlarmCondition();
		String serviceId = "1";
		Integer pageSize =20;
		Integer curPage = 0;
		//condition.setId("");
		condition.setType("");
		condition.setServerity("");
		condition.setProcess(0);
		AlarmParam alarmParam = new AlarmParam();
		alarmParam.setUserId("admin");
		alarmParam.setCondition(condition);
		JSONObject json = JSONObject.parseObject(JSONObject.toJSONString(alarmParam));
		JSONObject cond =(JSONObject)json.get("condition");
		cond.put("page.pageSise", pageSize);
		cond.put("page.curPage", curPage);
		json.put("condition", cond);
		String postParams = json.toJSONString();
		//System.out.println("======postParams======"+postParams);
		
		RequestBody body = RequestBody.create(JSON, postParams);
		Request.Builder requestBuilder = new Request.Builder().url(BASE_URL + serviceMap.get(serviceId));
		requestBuilder.method("POST", body);
		requestBuilder.addHeader("Content-Type", "application/json");
		requestBuilder.addHeader("Accept", "application/json; charset=utf-8");
		requestBuilder.addHeader("sysCode", "COSS");
		Request request = requestBuilder.build();
		ResponseBody resp = null;
		String content = "";
		try {
			Response response = client.newCall(request).execute();
			resp = response.body();
			content = resp.string();
			//System.out.println("===========content==========" + content);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
