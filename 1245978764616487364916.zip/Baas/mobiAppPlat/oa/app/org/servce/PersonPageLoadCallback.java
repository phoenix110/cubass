package mobiAppPlat.oa.app.org.servce;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import mobiAppPlat.oa.app.docapprove.bean.HtmlParser;
import mobiAppPlat.oa.app.docapprove.bean.RespCallback;

public class PersonPageLoadCallback implements RespCallback{

	public Object execute(InputStream body) {
		
		//定义要返回的数据对象
		Map<String, Object>  map = new HashMap<String, Object>();
		
		//将抓取到的数据转成document对象。
		Document doc = HtmlParser.parser(body, null);
		
		//从抓取的数据中根据id获取整个树。
		Element treeview = doc.getElementById("userTreeView");
		//获取树种的所有div标签
		Elements divs = treeview.getElementsByTag("div");
		//遍历div标签只需要获取第一个div标签的内容
		if (divs.size()>1) {
			Element div = divs.get(1);
			map = getTreeData(div, map);
		}
		return map;
	}
	
	//用递归的方式获取树的数据集合
	public  Map<String, Object> getTreeData(Element div,Map<String, Object> map){
		if ("div".equals(div.tagName())) {
			Elements childElements = div.children();
			for (int i = 0; i < childElements.size(); i++) {
				Element childElement = childElements.get(i);
				map = getTreeData(childElement,map);
			}
		}else {
			Elements tds = div.getElementsByTag("td");
			Map<String, String> orgMap = new HashMap<String, String>();
			String href = tds.get(tds.size()-1).getElementsByTag("a").get(0).attr("href");
			String fid = href.substring(53, href.length()-2);
			if (tds.size()>0) {
				String[] fidList = fid.split("\\\\\\\\");
				
				//获取组织或人员id
				String id = fidList[fidList.length-1].replaceAll("\\*\\|\\*","\\\\");
				//获取组织或人员的parentID
				String parent = "";
				if (fidList.length>1) {
					parent = fidList[fidList.length-2];
				}
				orgMap.put(id, parent);
				//获取组织人员名称
				map.put(tds.get(tds.size()-1).text(), orgMap);
			}
		}
		return map;
		
	}

}
