package mobiAppPlat.oa.app.contractapprove;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.jsoup.nodes.Document;

import forNet.net.HtmlParser;
import forNet.net.RespCallback;
import forNet.net.pages.CheckUserOnline;

public class LoginPageGetIndexCallback implements RespCallback {

	public Object execute(InputStream body) {
		String flag = "true";
		String msg = "";
		Document doc = HtmlParser.parser(body, null);
		//System.out.println("indexHtml:"+doc.html());
		CheckUserOnline.checkOnline(doc);
		/*
		for (Element e : doc.getElementsByTag("a")) {
			String href = e.attr("href");
			if (href.endsWith("default.aspx")) {
				flag = "true";
			} else {
				flag = "false";
				msg = "未知错误";
			}
			break;
		}*/

		Map<String, String> result = new HashMap<String, String>();
		result.put("flag", flag);
		result.put("msg", msg);
		return result;
	}

}
