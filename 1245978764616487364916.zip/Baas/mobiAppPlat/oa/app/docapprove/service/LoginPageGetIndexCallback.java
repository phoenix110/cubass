package mobiAppPlat.oa.app.docapprove.service;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import mobiAppPlat.oa.app.docapprove.bean.HtmlParser;
import mobiAppPlat.oa.app.docapprove.bean.RespCallback;
import mobiAppPlat.oa.app.docapprove.service.CheckUserOnline;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;


public class LoginPageGetIndexCallback implements RespCallback {

	public Object execute(InputStream body) {
		String flag = "true";
		String msg = "";
		Document doc = HtmlParser.parser(body, null);
		CheckUserOnline.checkOnline(doc);
		for (Element e : doc.getElementsByTag("a")) {
			String href = e.attr("href");
			if (href.endsWith("index.aspx")) {
				flag = "true";
			} else {
				flag = "false";
				msg = "未知错误";
			}
			break;
		}

		Map<String, String> result = new HashMap<String, String>();
		result.put("flag", flag);
		result.put("msg", msg);
		return result;
	}

}
